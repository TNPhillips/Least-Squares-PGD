/*
 * PGDLSQ.h
 *
 *  Created on: 19 Apr 2013
 *      Author: plog
 */

#ifndef PGDLSQ_H_
#define PGDLSQ_H_

#include "PGD.h"
#include <gmd.h>
#include <lavd.h>
#include <iostream>
#include "Polylib.h"
#include <math.h>
#include <laslv.h>
#include "blaspp.h"
#include <blas1pp.h>
#include "arrays.h"

using namespace std;
using namespace polylib;

double del1 = 0.05;

//True Solutions (For Calculating Error):
double Slsqusol(double x, double y) {
	//return -sin(2*PI*x)*cos(2*PI*y);
	//return (cos(2*PI*x)-1)*sin(2*PI*y);
	return sin(2*PI*x)*cos(2*PI*y);
}

double Slsqvsol(double x, double y) {
	//return cos(2*PI*x)*sin(2*PI*y);
	//return (1-cos(2*PI*y))*sin(2*PI*x);
	return cos(2*PI*x)*sin(2*PI*y);
}

double Slsqwsol(double x, double y) {
	//return -4*PI*sin(2*PI*x)*sin(2*PI*y);
	return 2*PI*cos(2*PI*x)*(1-cos(2*PI*y))+2*PI*cos(2*PI*y)*(1-cos(2*PI*x));
}

double Slsqpsol(double x, double y) {
	//return sin(PI*x*y);
	return sin(PI*x)*sin(PI*y);
}

void uvwptrue(Arr& u2, Arr& v2, Arr& w2, Arr& p2) {
	for (int i=0; i<N+1; i++) {
		for (int j=0; j<N+1; j++) {
			for (int k=1; k<=Kx; k++) {
				for (int l=1; l<=Ky; l++) {
					u2(i,j,k-1,l-1)=Slsqusol(xx(k-1,i),yy(l-1,j));
					v2(i,j,k-1,l-1)=Slsqvsol(xx(k-1,i),yy(l-1,j));
					w2(i,j,k-1,l-1)=Slsqwsol(xx(k-1,i),yy(l-1,j));
					p2(i,j,k-1,l-1)=Slsqpsol(xx(k-1,i),yy(l-1,j));
				}
			}
		}
	}
}

void Xuvptrue(Arr& u2, Arr& v2, Arr& p2) {
	for (int i=0; i<N+1; i++) {
		for (int j=0; j<N+1; j++) {
			for (int k=1; k<=Kx; k++) {
				for (int l=1; l<=Ky; l++) {
					u2(i,j,k-1,l-1)=Slsqusol(xx(k-1,i),yy(l-1,j));
					v2(i,j,k-1,l-1)=Slsqvsol(xx(k-1,i),yy(l-1,j));
					p2(i,j,k-1,l-1)=Slsqpsol(xx(k-1,i),yy(l-1,j));
				}
			}
		}
	}
}


// Right hand side functions:
double Slsqfct1(double x, double y) {
	return 0;
	//return 8*PI*PI*sin(2*PI*x)*cos(2*PI*y)+PI*cos(PI*x)*sin(PI*y);
	//return PI*y*cos(PI*x*y)+4*PI*PI*sin(2*PI*y)*(2*cos(2*PI*x)-1);
	//return PI*cos(PI*x)*sin(PI*y)+4*PI*PI*sin(2*PI*y)*(2*cos(2*PI*x)-1);

}

double Slsqfct2(double x, double y) {
	return 0;
	//return Slsqfct1(y,x);
	//return PI*x*cos(PI*x*y)-4*PI*PI*sin(2*PI*x)*(2*cos(2*PI*y)-1);
	//return PI*cos(PI*y)*sin(PI*x)-4*PI*PI*sin(2*PI*x)*(2*cos(2*PI*y)-1);

}
//---------------------------


// Boundary conditions
double SlsqbcuN(double x) {
	//return -sin(2*PI*x);
	//return (1-pow(x,20))*(1-pow(x,20));
	//return 0;
	//return sin(2*PI*x);
	double dd = bx - ax;
	if ((x<=dd*(0.5-del1)) && (x>=dd*(-0.5+del1))) {
		return 1;
	}
	else if (x>=dd*(0.5-del1)) {
		return 0.5*(1+cos((PI/(dd*del1))*(x-dd*(0.5-del1))));
	}
	else {
		return 0.5*(1+cos((PI/(dd*del1))*(x+dd*(0.5-del1))));
	}
}

double SlsqbcuE(double x) {
	return 0;
}

double SlsqbcuS(double x) {
	//return -sin(2*PI*x);
	//return sin(2*PI*x);
	return 0;
}

double SlsqbcuW(double x) {
	return 0;
}

double SlsqbcvN(double x) {
	return 0;
}

double SlsqbcvE(double x) {
	//return sin(2*PI*x);
	return 0;
}

double SlsqbcvS(double x) {
	return 0;
}

double SlsqbcvW(double x) {
	//return sin(2*PI*x);
	return 0;
}

// X Boundary Conditions

double XSlsqbcV1N(double x) {
	//return -10*pow(x,9);
	//return 0;
	//return -40*pow(x,19)*(1-pow(x,20));
	double dd = bx - ax;
	if ((x<=dd*(0.5-del1)) && (x>=dd*(-0.5+del1))) {
		return 0;
	}
	else if (x>=dd*(0.5-del1)) {
		return -(PI/(2*dd*del1))*sin((PI/(dd*del1))*(x-dd*(0.5-del1)));
	}
	else {
		return -(PI/(2*dd*del1))*sin((PI/(dd*del1))*(x+dd*(0.5-del1)));
	}
	//return 2*PI*cos(2*PI*x);

}

double XSlsqbcV1E(double x) { //Dummy bc
	//return -5*(x+1);
	return 0;
}

double XSlsqbcV1S(double x) {
	return 0;
	//return 2*PI*cos(2*PI*x);
}

double XSlsqbcV1W(double x) { //Dummy bc
	//return 5*(x+1);
	return 0;
}

double XSlsqbcV2N(double x) { //Dummy bc
	return 0;
}

double XSlsqbcV2E(double x) {
	return 0;
}

double XSlsqbcV2S(double x) { //Dummy bc
	return 0;
}

double XSlsqbcV2W(double x) {
	return 0;
}

double XSlsqbcV3N(double x) {
	return 0;
}

double XSlsqbcV3E(double x) { //Dummy bc
	return 0;
}

double XSlsqbcV3S(double x) {
	return 0;
}

double XSlsqbcV3W(double x) { //Dummy bc
	return 0;
}

double XSlsqbcV4N(double x) { //Dummy bc
	return 0;
}

double XSlsqbcV4E(double x) {
	return 0;
}

double XSlsqbcV4S(double x) { //Dummy bc
	return 0;
}

double XSlsqbcV4W(double x) {
	return 0;
}


//------------------------------------


void Slsqsolve(Arr& A, Arr& B, Arr& C, Arr& E, Arr& F, Arr& G, Arr& H, Arr& L, Arr& ru, Arr& rv, Arr& rw, Arr& rp, Arr& f1, Arr& f2, Arr& f3, Arr& f4) {

	int K = f1.size();

	LaGenMatDouble whole(4*(K-1),4*(K-1));

	LaVectorDouble f1234(4*(K-1)), uvwp(4*(K-1));

	whole = 0;
	f1234 = 0;
	uvwp = 0;

	for (int i=0; i<K-2; i++) {
		f1234(i) = f1(i+1);
		f1234(i+K-2) = f2(i+1);
		for (int j=0; j<K-2; j++) {
			whole(i,j) = A(i+1,j+1);
			whole(i,j+K-2) = B(i+1,j+1);
			whole(i+K-2,j) = B(j+1,i+1);
			whole(i+K-2,j+K-2) = E(i+1,j+1);
		}
		for (int j=0; j<K; j++) {
			whole(i,j+2*(K-2)) = C(i+1,j);
			whole(i+K-2,j+2*(K-2)) = F(i+1,j);
		}
	}

	for (int i=0; i<K; i++) {
		f1234(i+2*(K-2)) = f3(i);
		f1234(i+3*K-4) = f4(i);
		for (int j=0; j<K; j++) {
			whole(i+2*(K-2),j+2*(K-2)) = G(i,j);
			whole(i+2*(K-2),j+3*K-4) = H(i,j);
			whole(i+3*K-4,j+2*(K-2)) = H(j,i);
			whole(i+3*K-4,j+3*K-4) = L(i,j);
		}
		for (int j=0; j<K-2; j++) {
			whole(i+2*(K-2),j) = C(j+1,i);
			whole(i+2*(K-2),j+K-2) = F(j+1,i);
		}
	}

	//minres(whole,uvwp,f1234);

	LaLinearSolve(whole,uvwp,f1234);


	for (int i=0; i<K-2; i++) {
		ru(i+1) = uvwp(i);
		rv(i+1) = uvwp(i+K-2);
	}

	for (int i=0; i<K; i++) {
		rw(i) = uvwp(i+2*(K-2));
		rp(i) = uvwp(i+3*K-4);
	}


}

void SXlsqsolve(Arr& A, Arr& B, Arr& C, Arr& E, Arr& F, Arr& G, Arr& H, Arr& KK, Arr& L, Arr& M, Arr& NN, Arr& P, Arr& Q, Arr& R, Arr& S, Arr& T, Arr& U, Arr& V, Arr& W, Arr& ru, Arr& rv, Arr& rp, Arr& rV1, Arr& rV2, Arr& rV3, Arr& rV4, Arr& f1, Arr& f2, Arr& f3, Arr& f4, Arr& f5, Arr& f6, Arr& f7) {

	int K = f1.size();

	LaGenMatDouble whole(7*K-8,7*K-8);

	LaVectorDouble f1234567(7*K-8), uvpV1234(7*K-8);

	whole = 0;
	f1234567 = 0;
	uvpV1234 = 0;

	if(xory) {


		for (int i=0; i<K-2; i++) {
			f1234567(i) = f1(i+1);
			f1234567(i+K-2) = f2(i+1);
			f1234567(i+3*K-4) = f4(i+1);
			f1234567(i+5*K-6) = f6(i+1);
			for (int j=0; j<K-2; j++) {
				whole(i,j) = A(i+1,j+1);
				whole(i,j+K-2) = B(i+1,j+1);
				whole(i+K-2,j) = B(j+1,i+1);
				whole(i+K-2,j+K-2) = F(i+1,j+1);
				whole(i+3*K-4,j+3*K-4) = Q(i+1,j+1);
				whole(i+5*K-6,j+5*K-6) = U(i+1,j+1);

				whole(i,j+3*K-4) = C(i+1,j+1);
				whole(i+3*K-4,j) = C(j+1,i+1);
				whole(i+K-2,j+5*K-6) = G(i+1,j+1);
				whole(i+5*K-6,j+K-2) = G(j+1,i+1);
			}
			for (int j=0; j<K; j++) {
				whole(i,j+4*K-6) = E(i+1,j);
				whole(j+4*K-6,i) = E(i+1,j);
				whole(i+K-2,j+6*K-8) = H(i+1,j);
				whole(j+6*K-8,i+K-2) = H(i+1,j);
				whole(i+3*K-4,j+2*K-4) = L(j,i+1);
				whole(j+2*K-4,i+3*K-4) = L(j,i+1);
				whole(i+3*K-4,j+4*K-6) = R(i+1,j);
				whole(j+4*K-4,i+3*K-4) = R(i+1,j);
				whole(i+3*K-4,j+6*K-8) = S(i+1,j);
				whole(j+6*K-8,i+3*K-4) = S(i+1,j);
				whole(i+5*K-6,j+2*K-4) = NN(j,i+1);
				whole(j+2*K-4,i+5*K-6) = NN(j,i+1);
				whole(i+5*K-6,j+6*K-8) = V(i+1,j);
				whole(j+6*K-8,i+5*K-6) = V(i+1,j);
			}
		}

		for (int i=0; i<K; i++) {
			f1234567(i+2*K-4) = f3(i);
			f1234567(i+4*K-6) = f5(i);
			f1234567(i+6*K-8) = f7(i);

			for (int j=0; j<K; j++) {
				whole(i+2*K-4,j+2*K-4) = KK(i,j);
				whole(i+2*K-4,j+4*K-6) = M(i,j);
				whole(i+2*K-4,j+6*K-8) = P(i,j);
				whole(i+4*K-6,j+4*K-6) = T(i,j);
				whole(i+6*K-8,j+6*K-8) = W(i,j);

				whole(i+4*K-6,j+2*K-4) = M(j,i);
				whole(i+6*K-8,j+2*K-4) = P(j,i);

			}

		}

	}
	else {
		for (int i=0; i<K-2; i++) {
			f1234567(i) = f1(i+1);
			f1234567(i+K-2) = f2(i+1);
			f1234567(i+4*K-4) = f5(i+1);
			f1234567(i+6*K-6) = f7(i+1);
			for (int j=0; j<K-2; j++) {
				whole(i,j) = A(i+1,j+1);
				whole(i,j+K-2) = B(i+1,j+1);
				whole(i+K-2,j) = B(j+1,i+1);
				whole(i+K-2,j+K-2) = F(i+1,j+1);
				whole(i+4*K-4,j+4*K-4) = T(i+1,j+1);
				whole(i+6*K-6,j+6*K-6) = W(i+1,j+1);

				whole(i,j+4*K-4) = E(i+1,j+1);
				whole(i+4*K-4,j) = E(j+1,i+1);
				whole(i+K-2,j+6*K-6) = H(i+1,j+1);
				whole(i+6*K-6,j+K-2) = H(j+1,i+1);
			}
			for (int j=0; j<K; j++) {
				whole(i,j+3*K-4) = C(i+1,j);
				whole(j+3*K-4,i) = C(i+1,j);
				whole(i+K-2,j+5*K-6) = G(i+1,j);
				whole(j+5*K-6,i+K-2) = G(i+1,j);
				whole(i+4*K-4,j+2*K-4) = M(j,i+1);
				whole(j+2*K-4,i+4*K-4) = M(j,i+1);
				whole(i+4*K-4,j+3*K-4) = R(j,i+1);
				whole(j+3*K-4,i+4*K-4) = R(j,i+1);
				whole(i+6*K-6,j+2*K-4) = P(j,i+1);
				whole(j+2*K-4,i+6*K-6) = P(j,i+1);
				whole(i+6*K-6,j+3*K-4) = S(j,i+1);
				whole(j+3*K-4,i+6*K-6) = S(j,i+1);
				whole(i+6*K-6,j+5*K-6) = V(j,i+1);
				whole(j+5*K-6,i+6*K-6) = V(j,i+1);
			}
		}

		for (int i=0; i<K; i++) {
			f1234567(i+2*K-4) = f3(i);
			f1234567(i+3*K-4) = f4(i);
			f1234567(i+5*K-6) = f6(i);
			for (int j=0; j<K; j++) {
				whole(i+2*K-4,j+2*K-4) = KK(i,j);
				whole(i+2*K-4,j+3*K-4) = L(i,j);
				whole(i+2*K-4,j+5*K-6) = NN(i,j);
				whole(i+3*K-4,j+3*K-4) = Q(i,j);
				whole(i+5*K-6,j+5*K-6) = U(i,j);

				whole(i+3*K-4,j+2*K-4) = L(j,i);
				whole(i+5*K-6,j+2*K-4) = NN(j,i);

			}

		}

	}



	//minres(whole,uvwp,f1234);

	LaLinearSolve(whole,uvpV1234,f1234567);



	if(xory) {
		for (int i=0; i<K-2; i++) {
			ru(i+1) = uvpV1234(i);
			rv(i+1) = uvpV1234(i+K-2);
			rV1(i+1) = uvpV1234(i+3*K-4);
			rV3(i+1) = uvpV1234(i+5*K-6);
		}

		for (int i=0; i<K; i++) {
			rp(i) = uvpV1234(i+2*K-4);
			rV2(i) = uvpV1234(i+4*K-6);
			rV4(i) = uvpV1234(i+6*K-8);
		}
	}
	else {
		for (int i=0; i<K-2; i++) {
			ru(i+1) = uvpV1234(i);
			rv(i+1) = uvpV1234(i+K-2);
			rV2(i+1) = uvpV1234(i+4*K-4);
			rV4(i+1) = uvpV1234(i+6*K-6);
		}

		for (int i=0; i<K; i++) {
			rp(i) = uvpV1234(i+2*K-4);
			rV1(i) = uvpV1234(i+3*K-4);
			rV3(i) = uvpV1234(i+5*K-6);
		}
	}


}

void SXlsqsolvep(Arr& A, Arr& B, Arr& C, Arr& E, Arr& F, Arr& G, Arr& H, Arr& KK, Arr& L, Arr& M, Arr& NN, Arr& P, Arr& Q, Arr& R, Arr& S, Arr& T, Arr& U, Arr& V, Arr& W, Arr& ru, Arr& rv, Arr& rp, Arr& rV1, Arr& rV2, Arr& rV3, Arr& rV4, Arr& f1, Arr& f2, Arr& f3, Arr& f4, Arr& f5, Arr& f6, Arr& f7) {

	int K = f1.size();

	LaGenMatDouble whole(7*K-9,7*K-9);

	LaVectorDouble f1234567(7*K-9), uvpV1234(7*K-9);

	whole = 0;
	f1234567 = 0;
	uvpV1234 = 0;

	if(xory) {


		for (int i=0; i<K-2; i++) {
			f1234567(i) = f1(i+1);
			f1234567(i+K-2) = f2(i+1);
			f1234567(i+3*K-5) = f4(i+1);
			f1234567(i+5*K-7) = f6(i+1);
			for (int j=0; j<K-2; j++) {
				whole(i,j) = A(i+1,j+1);
				whole(i,j+K-2) = B(i+1,j+1);
				whole(i+K-2,j) = B(j+1,i+1);
				whole(i+K-2,j+K-2) = F(i+1,j+1);
				whole(i+3*K-5,j+3*K-5) = Q(i+1,j+1);
				whole(i+5*K-7,j+5*K-7) = U(i+1,j+1);

				whole(i,j+3*K-5) = C(i+1,j+1);
				whole(i+3*K-5,j) = C(j+1,i+1);
				whole(i+K-2,j+5*K-7) = G(i+1,j+1);
				whole(i+5*K-7,j+K-2) = G(j+1,i+1);
			}
			for (int j=0; j<K; j++) {
				whole(i,j+4*K-7) = E(i+1,j);
				whole(j+4*K-7,i) = E(i+1,j);
				whole(i+K-2,j+6*K-9) = H(i+1,j);
				whole(j+6*K-9,i+K-2) = H(i+1,j);

				whole(i+3*K-5,j+4*K-7) = R(i+1,j);
				whole(j+4*K-5,i+3*K-5) = R(i+1,j);
				whole(i+3*K-5,j+6*K-9) = S(i+1,j);
				whole(j+6*K-9,i+3*K-5) = S(i+1,j);

				whole(i+5*K-7,j+6*K-9) = V(i+1,j);
				whole(j+6*K-9,i+5*K-7) = V(i+1,j);
			}

			for (int j=0; j<K-1; j++) {
				whole(i+3*K-5,j+2*K-4) = L(j+1,i+1);
				whole(j+2*K-4,i+3*K-5) = L(j+1,i+1);
				whole(i+5*K-7,j+2*K-4) = NN(j+1,i+1);
				whole(j+2*K-4,i+5*K-7) = NN(j+1,i+1);
			}
		}

		for (int i=0; i<K; i++) {
			f1234567(i+4*K-7) = f5(i);
			f1234567(i+6*K-9) = f7(i);

			for (int j=0; j<K; j++) {

				whole(i+4*K-7,j+4*K-7) = T(i,j);
				whole(i+6*K-9,j+6*K-9) = W(i,j);

			}

			for (int j=0; j<K-1; j++) {
				whole(j+2*K-4,i+4*K-7) = M(j+1,i);
				whole(j+2*K-4,i+6*K-9) = P(j+1,i);
				whole(i+4*K-7,j+2*K-4) = M(j+1,i);
				whole(i+6*K-9,j+2*K-4) = P(j+1,i);
			}

		}

		for (int i=0; i<K-1; i++) {
			f1234567(i+2*K-4) = f3(i);
			for (int j=0; j<K-1; j++) {
				whole(i+2*K-4,j+2*K-4) = KK(i+1,j+1);
			}
		}

	}
	else {
		for (int i=0; i<K-2; i++) {
			f1234567(i) = f1(i+1);
			f1234567(i+K-2) = f2(i+1);
			f1234567(i+4*K-5) = f5(i+1);
			f1234567(i+6*K-7) = f7(i+1);
			for (int j=0; j<K-2; j++) {
				whole(i,j) = A(i+1,j+1);
				whole(i,j+K-2) = B(i+1,j+1);
				whole(i+K-2,j) = B(j+1,i+1);
				whole(i+K-2,j+K-2) = F(i+1,j+1);
				whole(i+4*K-5,j+4*K-5) = T(i+1,j+1);
				whole(i+6*K-7,j+6*K-7) = W(i+1,j+1);

				whole(i,j+4*K-5) = E(i+1,j+1);
				whole(i+4*K-5,j) = E(j+1,i+1);
				whole(i+K-2,j+6*K-7) = H(i+1,j+1);
				whole(i+6*K-7,j+K-2) = H(j+1,i+1);
			}
			for (int j=0; j<K; j++) {
				whole(i,j+3*K-5) = C(i+1,j);
				whole(j+3*K-5,i) = C(i+1,j);
				whole(i+K-2,j+5*K-7) = G(i+1,j);
				whole(j+5*K-7,i+K-2) = G(i+1,j);

				whole(i+4*K-5,j+3*K-5) = R(j,i+1);
				whole(j+3*K-5,i+4*K-5) = R(j,i+1);

				whole(i+6*K-7,j+3*K-5) = S(j,i+1);
				whole(j+3*K-5,i+6*K-7) = S(j,i+1);
				whole(i+6*K-7,j+5*K-7) = V(j,i+1);
				whole(j+5*K-7,i+6*K-7) = V(j,i+1);
			}
			for (int j=0; j<K-1; j++) {
				whole(i+4*K-5,j+2*K-4) = M(j+1,i+1);
				whole(j+2*K-4,i+4*K-5) = M(j+1,i+1);
				whole(i+6*K-7,j+2*K-4) = P(j+1,i+1);
				whole(j+2*K-4,i+6*K-7) = P(j+1,i+1);
			}
		}

		for (int i=0; i<K; i++) {
			f1234567(i+2*K-4) = f3(i);
			f1234567(i+3*K-5) = f4(i);
			f1234567(i+5*K-7) = f6(i);
			for (int j=0; j<K; j++) {
				whole(i+2*K-4,j+2*K-4) = KK(i,j);

				whole(i+3*K-5,j+3*K-5) = Q(i,j);
				whole(i+5*K-7,j+5*K-7) = U(i,j);



			}
			for (int j=0; j<K-1; j++) {
				whole(j+2*K-4,i+3*K-5) = L(j+1,i);
				whole(i+3*K-5,j+2*K-4) = L(j+1,i);
				whole(j+2*K-4,i+5*K-7) = NN(j+1,i);
				whole(i+5*K-7,j+2*K-4) = NN(j+1,i);
			}

		}

	}



	//minres(whole,uvwp,f1234);

	LaLinearSolve(whole,uvpV1234,f1234567);



	if(xory) {
		for (int i=0; i<K-2; i++) {
			ru(i+1) = uvpV1234(i);
			rv(i+1) = uvpV1234(i+K-2);
			rV1(i+1) = uvpV1234(i+3*K-5);
			rV3(i+1) = uvpV1234(i+5*K-7);
		}

		for (int i=0; i<K; i++) {
			rV2(i) = uvpV1234(i+4*K-7);
			rV4(i) = uvpV1234(i+6*K-9);
		}
		for (int i=0; i<K-1; i++) {
			rp(i+1) = uvpV1234(i+2*K-4);
			// hi
		}
	}
	else {
		for (int i=0; i<K-2; i++) {
			ru(i+1) = uvpV1234(i);
			rv(i+1) = uvpV1234(i+K-2);
			rV2(i+1) = uvpV1234(i+4*K-5);
			rV4(i+1) = uvpV1234(i+6*K-7);
		}

		for (int i=0; i<K; i++) {
			rV1(i) = uvpV1234(i+3*K-5);
			rV3(i) = uvpV1234(i+5*K-7);
		}
		for (int i=0; i<K-1; i++) {
			rp(i+1) = uvpV1234(i+2*K-4);
		}
	}


}



//Generates tensors for least-squares Stokes PGD
void Slsqtensors(Arr& A, Arr& B, Arr& C, Arr& E, Arr& F, Arr& G, Arr& H, Arr& L, Arr& L0) {


	Arr Axx(N+1,N+1,N+1,N+1);
	Arr Axy(N+1,N+1,N+1,N+1);
	Arr Ayx(N+1,N+1,N+1,N+1);
	Arr Ayy(N+1,N+1,N+1,N+1);
	Arr Bx(N+1,N+1,N+1,N+1);
	Arr By(N+1,N+1,N+1,N+1);
	Arr Cc(N+1,N+1,N+1,N+1);
	Arr ll(N+1,N+1,N+1,N+1);


	Arr S1(N+1,N+1);
	Arr kron(N+1,N+1);

	for (int i=0; i<N+1; i++) {
		kron(i,i)=1; //Kronecker Delta
	}

	for (int i=0; i<N+1; i++) {
		for (int j=0; j<N+1; j++) {
			for (int k=0; k<N+1; k++) {
				S1(i,j) += w(k)*D(k,i)*D(k,j);
			}
		}
	}

	for(int i=0; i<N+1; i++) {
		for(int n=0; n<N+1; n++) {
			for(int m=0; m<N+1; m++) {
				for(int l=0; l<N+1; l++) {
					Axx(i,n,m,l) = (dy/dx)*w(n)*kron(n,l)*S1(i,m);
					Axy(i,n,m,l) = w(m)*w(n)*D(m,i)*D(n,l);
					Ayx(i,n,m,l) = w(i)*w(l)*D(i,m)*D(l,n);
					Ayy(i,n,m,l) = (dx/dy)*w(i)*kron(i,m)*S1(n,l);
					Bx(i,n,m,l) = (dy/2)*w(i)*w(n)*D(i,m)*kron(n,l);
					By(i,n,m,l) = (dx/2)*w(i)*w(n)*D(n,l)*kron(i,m);
					Cc(i,n,m,l) = (dx*dy/4)*w(i)*w(n)*kron(i,m)*kron(n,l);
					ll(i,n,m,l) = (dx*dx*dy*dy/16)*w(i)*w(n)*w(m)*w(l);

					A(i,n,m,l) = Axx(i,n,m,l)+Ayy(i,n,m,l);
					B(i,n,m,l) = -Axy(i,n,m,l)+Ayx(i,n,m,l);
					C(i,n,m,l) = By(i,n,m,l);
					E(i,n,m,l) = Ayy(i,n,m,l)+Axx(i,n,m,l);
					F(i,n,m,l) = -Bx(i,n,m,l);
					G(i,n,m,l) = hh*hh*(Axx(i,n,m,l)+Ayy(i,n,m,l))+Cc(i,n,m,l);
					H(i,n,m,l) = hh*hh*(Axy(i,n,m,l)-Ayx(i,n,m,l));
					L(i,n,m,l) = hh*hh*(Axx(i,n,m,l)+Ayy(i,n,m,l));
					L0(i,n,m,l) = ting*ll(i,n,m,l);

				}
			}
		}
	}
}

void SXlsqtensors(Arr& A, Arr& B, Arr& CG, Arr& EH, Arr& F, Arr& K, Arr& L, Arr& M, Arr& NN, Arr& P, Arr& QW, Arr& RV, Arr& S, Arr& TU, Arr& K0) {


	Arr Axx(N+1,N+1,N+1,N+1);
	Arr Axy(N+1,N+1,N+1,N+1);
	Arr Ayx(N+1,N+1,N+1,N+1);
	Arr Ayy(N+1,N+1,N+1,N+1);
	Arr Bx(N+1,N+1,N+1,N+1);
	Arr By(N+1,N+1,N+1,N+1);
	Arr Cc(N+1,N+1,N+1,N+1);
	Arr ll(N+1,N+1,N+1,N+1);


	Arr S1(N+1,N+1);
	Arr kron(N+1,N+1);

	for (int i=0; i<N+1; i++) {
		kron(i,i)=1; //Kronecker Delta
	}

	for (int i=0; i<N+1; i++) {
		for (int j=0; j<N+1; j++) {
			for (int k=0; k<N+1; k++) {
				S1(i,j) += w(k)*D(k,i)*D(k,j);
			}
		}
	}

	for(int i=0; i<N+1; i++) {
		for(int n=0; n<N+1; n++) {
			for(int m=0; m<N+1; m++) {
				for(int l=0; l<N+1; l++) {
					Axx(i,n,m,l) = (dy/dx)*w(n)*kron(n,l)*S1(i,m);
					Axy(i,n,m,l) = w(m)*w(n)*D(m,i)*D(n,l);
					Ayx(i,n,m,l) = w(i)*w(l)*D(i,m)*D(l,n);
					Ayy(i,n,m,l) = (dx/dy)*w(i)*kron(i,m)*S1(n,l);
					Bx(i,n,m,l) = (dy/2)*w(i)*w(n)*D(i,m)*kron(n,l);
					By(i,n,m,l) = (dx/2)*w(i)*w(n)*D(n,l)*kron(i,m);
					Cc(i,n,m,l) = (dx*dy/4)*w(i)*w(n)*kron(i,m)*kron(n,l);
					ll(i,n,m,l) = (dx*dx*dy*dy/16)*w(i)*w(n)*w(m)*w(l);

					A(i,n,m,l) = 2*Axx(i,n,m,l)+Ayy(i,n,m,l);
					B(i,n,m,l) = Ayx(i,n,m,l);
					CG(i,n,m,l) = -Bx(i,n,m,l);
					EH(i,n,m,l) = -By(i,n,m,l);
					F(i,n,m,l) = Axx(i,n,m,l)+2*Ayy(i,n,m,l);
					K(i,n,m,l) = Axx(i,n,m,l)+Ayy(i,n,m,l);
					K0(i,n,m,l) = ting*ll(i,n,m,l);
					L(i,n,m,l) = -Axx(i,n,m,l);
					M(i,n,m,l) = -Ayx(i,n,m,l);
					NN(i,n,m,l) = -Axy(i,n,m,l);
					P(i,n,m,l) = -Ayy(i,n,m,l);
					QW(i,n,m,l) = 2*Axx(i,n,m,l)+2*Ayy(i,n,m,l)+Cc(i,n,m,l);
					RV(i,n,m,l) = Ayx(i,n,m,l)-Axy(i,n,m,l);
					S(i,n,m,l) = Axx(i,n,m,l)+Ayy(i,n,m,l);
					TU(i,n,m,l) = Axx(i,n,m,l)+Ayy(i,n,m,l)+Cc(i,n,m,l);

				}
			}
		}
	}
}

void SlsqRHS(Arr& g1, Arr& g2) {

	Arr RHS1(N+1,N+1,Kx,Ky), RHS2(N+1,N+1,Kx,Ky);

	g1=0;
	g2=0;
	for (int i=0; i<N+1; i++) {
		for (int n=0; n<N+1; n++) {
			for (int k=1; k<=Kx; k++) {
				for (int l=1; l<=Ky; l++) {
					RHS1(i,n,k-1,l-1) = Slsqfct1(xx(k-1,i),yy(l-1,n));
					RHS2(i,n,k-1,l-1) = Slsqfct2(xx(k-1,i),yy(l-1,n));
				}
			}
		}
	}

	for (int i=0; i<N+1; i++) {
		for (int n=0; n<N+1; n++) {
			for (int k=1; k<=Kx; k++) {
				for (int l=1; l<=Ky; l++) {
					for(int p=0; p<N+1; p++) {
						g1(i,n,k-1,l-1) += hh*hh*(-(dy/2)*w(n)*w(p)*D(p,i)*RHS2(p,n,k-1,l-1)+(dx/2)*w(i)*w(p)*D(p,n)*RHS1(i,p,k-1,l-1));
						g2(i,n,k-1,l-1) += hh*hh*((dy/2)*w(n)*w(p)*D(p,i)*RHS1(p,n,k-1,l-1)+(dx/2)*w(i)*w(p)*D(p,n)*RHS2(i,p,k-1,l-1));
					}
				}
			}
		}

	}


}

void SXlsqRHS(Arr& g1, Arr& g2, Arr& g3, Arr& g4, Arr& g5) {

	Arr RHS1(N+1,N+1,Kx,Ky), RHS2(N+1,N+1,Kx,Ky);

	g1=0;
	g2=0;
	g3=0;
	g4=0;
	g5=0;
	for (int i=0; i<N+1; i++) {
		for (int n=0; n<N+1; n++) {
			for (int k=1; k<=Kx; k++) {
				for (int l=1; l<=Ky; l++) {
					RHS1(i,n,k-1,l-1) = Slsqfct1(xx(k-1,i),yy(l-1,n));
					RHS2(i,n,k-1,l-1) = Slsqfct2(xx(k-1,i),yy(l-1,n));
				}
			}
		}
	}

	for (int i=0; i<N+1; i++) {
		for (int n=0; n<N+1; n++) {
			for (int k=1; k<=Kx; k++) {
				for (int l=1; l<=Ky; l++) {
					for(int p=0; p<N+1; p++) {
						g1(i,n,k-1,l-1) += (dy/2)*w(n)*w(p)*D(p,i)*RHS1(p,n,k-1,l-1)+(dx/2)*w(i)*w(p)*D(p,n)*RHS2(i,p,k-1,l-1);
						g2(i,n,k-1,l-1) += -(dy/2)*w(n)*w(p)*D(p,i)*RHS1(p,n,k-1,l-1);
						g3(i,n,k-1,l-1) += -(dx/2)*w(i)*w(p)*D(p,n)*RHS1(i,p,k-1,l-1);
						g4(i,n,k-1,l-1) += -(dy/2)*w(n)*w(p)*D(p,i)*RHS2(p,n,k-1,l-1);
						g5(i,n,k-1,l-1) += -(dx/2)*w(i)*w(p)*D(p,n)*RHS2(i,p,k-1,l-1);
					}
				}
			}
		}

	}


}

void Streamfct(Arr& X, Arr& Y, Arr& Stream) {

	Arr hinp(N+1,N+1,N+1);

	double * xnp, * legd, * xi, * legf;

	xnp=new double[(N+1)*(N+1)];
	legd=new double[(N+1)*(N+1)];
	xi=new double[N+1];
	legf=new double[N+1];

	for (int n=0; n<N+1; n++) {
		xi[n]=z(n);
		for (int p=0; p<N+1; p++) {
			xnp[n*(N+1)+p]=-1+((z(n)+1)*(z(p)+1))/2;
		}
	}

	jacobd((N+1)*(N+1),xnp,legd,N,0,0);
	jacobf(N+1,xi,legf,N,0,0);


	for (int i=0; i<N+1; i++) {
		for (int n=0; n<N+1; n++) {
			for (int p=0; p<N+1; p++) {
				hinp(i,n,p) = ((1-xnp[n*(N+1)+p]*xnp[n*(N+1)+p])*legd[n*(N+1)+p])/(N*(N+1)*legf[i]*(z(i)-xnp[n*(N+1)+p]));

				if (hinp(i,n,p) != hinp(i,n,p)) {
					hinp(i,n,p)=1;
				}
				if (hinp(i,n,p)>100) {
					hinp(i,n,p)=1;
				}
				if (hinp(i,n,p)<-100) {
					hinp(i,n,p)=1;
				}

				if (abs(hinp(i,n,p))>10) {
					cout << i << " " << n << " " << p << endl;
				}


			}
		}
	}

	delete[] xnp;
	delete[] legd;
	delete[] xi;
	delete[] legf;


	Stream=0;
	double S1, S2;
	for (int n=0; n<N+1; n++) {
		for (int kx=1; kx<=Kx; kx++) {
			for (int m=0; m<N+1; m++) {
				for (int ky=1; ky<=Ky; ky++) {
					for (int j=0; j<J; j++) {
						S1=0;
						S2=0;
						for (int k=1; k<=kx-1; k++) {
							for (int i=0; i<N+1; i++) {
								S1 += (dx/2)*w(i)*X(j,i,k-1);
							}
						}

						for (int i=0; i<N+1; i++) {
							for (int p=0; p<N+1; p++) {
								S2 += (dx*(z(n)+1)/4)*X(j,i,kx-1)*w(p)*hinp(i,n,p);
							}
						}
						Stream(n,m,kx-1,ky-1) -= Y(j,m,ky-1)*(S1+S2);

					}
				}
			}
		}
	}

}






#endif /* PGDLSQ_H_ */
