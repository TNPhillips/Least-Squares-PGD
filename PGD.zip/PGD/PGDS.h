/*
 * PGDS.h
 *
 *  Created on: 27 Mar 2013
 *      Author: plog
 */

#ifndef PGDS_H_
#define PGDS_H_

#include "PGD.h"
#include <gmd.h>
#include <lavd.h>
#include <iostream>
#include "Polylib.h"
#include <math.h>
#include <laslv.h>
#include "blaspp.h"
#include <blas1pp.h>
#include "arrays.h"

using namespace std;
using namespace polylib;

Arr PMx, PMy; //Pressure-mass matrices

Arr h_0, h_N; //Interior basis functions at endpoints

//True solution of u for Stokes---------------------------------------
double Ssolu(double x, double y) {
	//return sin(PI*((1-pow(x,2))*(1-pow(y,2))));
	//return sin(PI*x)*sin(PI*y);
	//return cos(2*PI*x)*sin(2*PI*y)-sin(2*PI*y);
	return sin(2*PI*y)*(cos(2*PI*x)-1);
	//return 0;
}

//True solution of v for Stokes---------------------------------------
double Ssolv(double x, double y) {
	//return ((1-pow(x,2))*(1-pow(y,2)));
	//return sin(PI*x)*sin(PI*y);
	//return sin(2*PI*x)-sin(2*PI*x)*cos(2*PI*y);
	//return 0;
	return -sin(2*PI*x)*(cos(2*PI*y)-1);
}

//True solution of p for Stokes---------------------------------------
double Ssolp(double x, double y) {
	//return sin(x*y);
	return sin(PI*x*y);
}

//RHS of first part of Stokes-----------------------------------------
double Sfct1(double x, double y) {
	//return y*cos(x*y);
	//return 2*pow(PI,2)*sin(PI*x)*sin(PI*y)+y*cos(x*y);
	//return 2*pow(PI,2)*sin(PI*x)*sin(PI*y);
	//return PI*y*cos(PI*x*y)+8*PI*PI*cos(2*PI*x)*sin(2*PI*y)-4*PI*PI*sin(2*PI*y);
	return PI*y*cos(PI*x*y)+4*PI*PI*sin(2*PI*y)*(2*cos(2*PI*x)-1);
}

//RHS of second part of Stokes----------------------------------------
double Sfct2(double x, double y) {
	//return x*cos(x*y);
	//return 2*pow(PI,2)*sin(PI*x)*sin(PI*y)+x*cos(y*x);
	//return 2*pow(PI,2)*sin(PI*x)*sin(PI*y);
	//return PI*x*cos(PI*x*y)-8*PI*PI*sin(2*PI*x)*cos(2*PI*y)+4*PI*PI*sin(2*PI*x);
	return PI*x*cos(PI*x*y)-4*PI*PI*sin(2*PI*x)*(2*cos(2*PI*y)-1);
}




// Boundary conditions
double SbcuN(double x) {
	//return -sin(2*PI*x);
	//return 1-pow(x,80);
	return 0;
}

double SbcuE(double x) {
	return 0;
}

double SbcuS(double x) {
	//return -sin(2*PI*x);
	return 0;
}

double SbcuW(double x) {
	return 0;
}

double SbcvN(double x) {
	return 0;
}

double SbcvE(double x) {
	//return sin(2*PI*x);
	return 0;
}

double SbcvS(double x) {
	return 0;
}

double SbcvW(double x) {
	//return sin(2*PI*x);
	return 0;
}

void SsetRHS(Arr& RHS1, Arr& RHS2) {

for (int i=0; i<N+1; i++) {
	for (int j=0; j<N+1; j++) {
		for (int k=1; k<=Kx; k++) {
			for (int l=1; l<=Ky; l++) {
				RHS1(i,j,k-1,l-1)=Sfct1(xx(k-1,i),yy(l-1,j));
				RHS2(i,j,k-1,l-1)=Sfct2(xx(k-1,i),yy(l-1,j));
			}
		}
	}
}
}








//Pressure-Mass matrix for block preconditioner
void pmmatrix() {
	PMx.resize((N-1)*Kx,(N-1)*Kx);
	PMy.resize((N-1)*Ky,(N-1)*Ky);

	for (int i=1; i<N; i++) {
		for (int j=1; j<N; j++) {
			for(int k=1; k<=Kx; k++) {
				PMx((k-1)*(N-1)+(i-1),(k-1)*(N-1)+(i-1))=(dx/2)*w(i);
				PMx((k-1)*(N-1)+(i-1),(k-1)*(N-1)+(j-1))+=(dx/2)*w(0)*(h_0(i)*h_0(j)+h_N(i)*h_N(j));
			}
			for(int k=1; k<=Ky; k++) {
				PMy((k-1)*(N-1)+(i-1),(k-1)*(N-1)+(i-1))=(dy/2)*w(i);
				PMy((k-1)*(N-1)+(i-1),(k-1)*(N-1)+(j-1))+=(dy/2)*w(0)*(h_0(i)*h_0(j)+h_N(i)*h_N(j));
			}
		}
	}
}

//Preconditioned minres
void minres2(LaGenMatDouble M, LaGenMatDouble A, LaVectorDouble& u, LaVectorDouble f) {

	double H = u.size();


	LaVectorDouble v0(H), v1(H), w0(H), w1(H), z0(H), z1(H);
	double gam0, gam1, eta, s0, s1, c0, c1, d1, a0, a1, a2, a3;

	v0=0;
	w0=0;
	w1=0;
	z0=0;

	gam0=1;

	u=1; //Initial guess

	v1=f-A*u;

	LaLinearSolve(M,z1,v1);

	gam1=sqrt(Blas_Dot_Prod(z1,v1));
	eta=gam1;

	s0=0;
	s1=0;
	c0=1;
	c1=1;

	LaVectorDouble vt, wt;


	while (fabs(eta)>1e-14){

		Blas_Scale(1./gam1,z1);

		d1=Blas_Dot_Prod(A*z1,z1);

		vt=v1;
		v1=A*z1-(d1/gam1)*v1-(gam1/gam0)*v0;
		v0=vt;

		z0=z1;
		LaLinearSolve(M,z1,v1);

		gam0=gam1;
		gam1=sqrt(Blas_Dot_Prod(z1,v1));



		a0=c1*d1-c0*s1*gam0;
		a1=sqrt(a0*a0+gam1*gam1);
		a2=s1*d1+c0*c1*gam0;
		a3=s0*gam0;

		c0=c1;
		c1=a0/a1;

		s0=s1;
		s1=gam1/a1;


		wt=w1;
		w1=(1./a1)*z0-(a3/a1)*w0-(a2/a1)*w1;
		w0=wt;

		u=u+c1*eta*w1;

		eta=-s1*eta;


	}


}

//Linear solver for Global system using block preconditioner
void trimglobal2(Arr& A, Arr& B, Arr& C, Arr& E, Arr& F, Arr& ru, Arr& rv, Arr& rp, Arr& f1, Arr& f2, Arr& f3) {
	int H = f1.size()-2;
	int K = f3.size();

	LaGenMatDouble whole(2*H+K,2*H+K), precon(2*H+K,2*H+K);
	LaVectorDouble f123(2*H+K), uvp(2*H+K);

	whole=0;
	precon=0;
	f123 =0;

	for(int i=0; i<H; i++) {
		precon(i,i)=A(i+1,i+1);
		precon(i+H,i+H)=C(i+1,i+1);
		for(int j=0; j<H; j++) {
			whole(i,j)=A(i+1,j+1);
			whole(i+H,j+H)=C(i+1,j+1);
		}
		for(int j=0; j<K; j++) {
			whole(i,j+2*H)=B(i+1,j);
			whole(i+H,j+2*H)=E(i+1,j);
		}
	}

	for(int i=0; i<K; i++) {
		if(xory) {
			precon(i+2*H,i+2*H)=PMx(i,i);
		}
		else {
			precon(i+2*H,i+2*H)=PMy(i,i);
		}
		for(int j=0; j<K; j++) {
			/*if(xory) {
				precon(i+2*H,j+2*H)=PMx(i,j);
			}
			else {
				precon(i+2*H,j+2*H)=PMy(i,j);
			}*/
			whole(i+2*H,j+2*H)=F(i,j);
		}
		for(int j=0; j<H; j++) {
			whole(i+2*H,j)=B(j+1,i);
			whole(i+2*H,j+H)=E(j+1,i);
		}
	}

	for(int i=0; i<H; i++) {
		f123(i)=f1(i+1);
		f123(i+H)=f2(i+1);
	}

	for(int i=0; i<K; i++) {
		f123(i+2*H)=f3(i);
	}

	precon=0;
	for(int i=0; i<2*H+K; i++) {
		precon(i,i)=1;
	}

	/*cout << B << endl;

	cout << E << endl;

	cout << whole << endl;

	abort();*/

	//minres2(precon,whole,uvp,f123);

	LaLinearSolve(whole,uvp,f123);


	for(int i=0; i<H; i++) {
		ru(i+1)=uvp(i);
		rv(i+1)=uvp(i+H);
	}
	for(int i=0; i<K; i++) {
		rp(i)=uvp(i+2*H);
	}

}

void uvp2true(Arr& u2, Arr& v2, Arr& p2) {

	for (int i=0; i<N+1; i++) {
		for (int j=0; j<N+1; j++) {
			for (int k=1; k<=Kx; k++) {
				for (int l=1; l<=Ky; l++) {
					u2(i,j,k-1,l-1)=Ssolu(xx(k-1,i),yy(l-1,j)); // RHS of equation
					v2(i,j,k-1,l-1)=Ssolv(xx(k-1,i),yy(l-1,j));
					p2(i,j,k-1,l-1)=Ssolp(xx(k-1,i),yy(l-1,j));
				}
			}
		}
	}
}

//b-tensors in Stokes equations (with x and y derivatives)
void PGDb(Arr& B1, Arr& B2) {

	Arr kron(N+1,N+1);

	for (int i=0; i<N+1; i++) {
		kron(i,i)=1; //Kronecker Delta
	}


	for(int i=1; i<N; i++) {
		for(int n=1; n<N; n++) {
			for(int m=0; m<N+1; m++) {
				for(int l=0; l<N+1; l++) {
					B1(i-1,n-1,m,l) = -(dy/2)*(w(i)*D(i,m)+w(0)*D(0,m)*h_0(i-1)+w(N)*D(N,m)*h_N(i-1))*(w(n)*kron(n,l)+w(0)*kron(0,l)*h_0(n-1)+w(N)*kron(N,l)*h_N(n-1));
					B2(i-1,n-1,m,l) = -(dx/2)*(w(i)*kron(i,m)+w(0)*kron(0,m)*h_0(i-1)+w(N)*kron(N,m)*h_N(i-1))*(w(n)*D(n,l)+w(0)*D(0,l)*h_0(n-1)+w(N)*D(N,l)*h_N(n-1));
				}
			}
		}
	}


}

//Tensor associated with implicit zero mean pressure implementation
void PGDc(Arr& C) {

	const double mu = 0;


	for(int i=1; i<N; i++) {
		for(int n=1; n<N; n++) {
			for(int m=1; m<N; m++) {
				for(int l=1; l<N; l++) {
					C(i-1,n-1,m-1,l-1) = (mu*dx*dx*dy*dy/16)*(w(i)+w(0)*h_0(i-1)+w(N)*h_N(i-1))*(w(n)+w(0)*h_0(n-1)+w(N)*h_N(n-1))*(w(m)+w(0)*h_0(m-1)+w(N)*h_N(m-1))*(w(l)+w(0)*h_0(l-1)+w(N)*h_N(l-1));
				}
			}
		}
	}
}

void bsetr(Arr& tenBx, Arr& rsuk, Arr& rspk, Arr& Xuk, Arr& Yuk, Arr& Xpk, Arr& Ypk, Arr& B, Arr& a2, Arr& c1) {

	Arr Brs1(N-1,N+1,N+1), Brs2(N-1,N-1,N+1);

	for (int i=0; i<N-1; i++) {
		for (int n=0; n<N-1; n++) {
			for (int l=0; l<N+1; l++) {
				for (int m=0; m<N+1; m++) {
					Brs1(n,m,l) += rspk(i)*tenBx(i,n,m,l);
					Brs2(i,n,l) += rsuk(m)*tenBx(i,n,m,l);
				}
			}
		}
	}

	B=0;
	for (int n=0; n<N-1; n++) {
		for (int l=0; l<N+1; l++) {
			for (int i=0; i<N-1; i++) {
				B(l,n) += rspk(i)*Brs2(i,n,l);
			}
		}
	}

	a2=0;
	for (int j=1; j<=Dim; j++) {
		for (int l=0; l<N+1; l++) {
			for (int i=0; i<N-1; i++) {
				for (int n=0; n<N-1; n++) {
					a2(l) += Xpk(j-1,i)*Ypk(j-1,n)*Brs2(i,n,l);
				}
			}
		}
	}

	c1=0;
	for (int j=1; j<=Dim; j++) {
		for (int l=0; l<N+1; l++) {
			for (int i=0; i<N-1; i++) {
				for (int n=0; n<N+1; n++) {
					c1(i) += Xuk(j-1,n)*Yuk(j-1,l)*Brs1(i,n,l);
				}
			}
		}
	}

}

void bsets(Arr& tenBx, Arr& rsuk, Arr& rspk, Arr& Xuk, Arr& Yuk, Arr& Xpk, Arr& Ypk, Arr& B, Arr& a2, Arr& c1) {

	Arr Brs1(N-1,N+1,N+1), Brs2(N-1,N-1,N+1);

	for (int i=0; i<N-1; i++) {
		for (int n=0; n<N-1; n++) {
			for (int l=0; l<N+1; l++) {
				for (int m=0; m<N+1; m++) {
					Brs1(i,m,l) += rspk(n)*tenBx(i,n,m,l);
					Brs2(i,n,m) += rsuk(l)*tenBx(i,n,m,l);
				}
			}
		}
	}

	B=0;
	for (int n=0; n<N-1; n++) {
		for (int l=0; l<N+1; l++) {
			for (int i=0; i<N-1; i++) {
				B(l,i) += rspk(n)*Brs2(i,n,l);
			}
		}
	}

	a2=0;
	for (int j=1; j<=Dim; j++) {
		for (int l=0; l<N+1; l++) {
			for (int i=0; i<N-1; i++) {
				for (int n=0; n<N-1; n++) {
					a2(l) += Xpk(j-1,i)*Ypk(j-1,n)*Brs2(i,n,l);
				}
			}
		}
	}

	c1=0;
	for (int j=1; j<=Dim; j++) {
		for (int l=0; l<N+1; l++) {
			for (int i=0; i<N-1; i++) {
				for (int n=0; n<N+1; n++) {
					c1(i) += Xuk(j-1,n)*Yuk(j-1,l)*Brs1(i,n,l);
				}
			}
		}
	}

}

void bysetr(Arr& tenBy, Arr& rsvk, Arr& rspk, Arr& Xvk, Arr& Yvk, Arr& Xpk, Arr& Ypk, Arr& E, Arr& b2, Arr& c2) {

	Arr Brs1(N+1,N+1,N-1), Brs2(N+1,N-1,N-1);

	for (int i=0; i<N+1; i++) {
		for (int n=0; n<N+1; n++) {
			for (int l=0; l<N-1; l++) {
				for (int m=0; m<N-1; m++) {
					Brs1(i,n,l) += rspk(m)*tenBy(i,n,m,l);
					Brs2(n,m,l) += rsvk(i)*tenBy(i,n,m,l);
				}
			}
		}
	}

	E=0;
	for (int n=0; n<N-1; n++) {
		for (int l=0; l<N-1; l++) {
			for (int i=0; i<N+1; i++) {
				E(i,l) += rspk(n)*Brs2(i,n,l);
			}
		}
	}

	b2=0;
	for (int j=1; j<=Dim; j++) {
		for (int l=0; l<N-1; l++) {
			for (int i=0; i<N+1; i++) {
				for (int n=0; n<N-1; n++) {
					b2(i) += Xpk(j-1,n)*Ypk(j-1,l)*Brs2(i,n,l);
				}
			}
		}
	}

	c2=0;
	for (int j=1; j<=Dim; j++) {
		for (int l=0; l<N-1; l++) {
			for (int i=0; i<N+1; i++) {
				for (int n=0; n<N+1; n++) {
					c2(l) += Xvk(j-1,i)*Yvk(j-1,n)*Brs1(i,n,l);
				}
			}
		}
	}
}

void bysets(Arr& tenBy, Arr& rsvk, Arr& rspk, Arr& Xvk, Arr& Yvk, Arr& Xpk, Arr& Ypk, Arr& E, Arr& b2, Arr& c2) {

	Arr Brs1(N+1,N+1,N-1), Brs2(N+1,N-1,N-1);

	for (int i=0; i<N+1; i++) {
		for (int n=0; n<N+1; n++) {
			for (int l=0; l<N-1; l++) {
				for (int m=0; m<N-1; m++) {
					Brs1(i,n,m) += rspk(l)*tenBy(i,n,m,l);
					Brs2(i,m,l) += rsvk(n)*tenBy(i,n,m,l);
				}
			}
		}
	}

	E=0;
	for (int n=0; n<N-1; n++) {
		for (int l=0; l<N-1; l++) {
			for (int i=0; i<N+1; i++) {
				E(i,n) += rspk(l)*Brs2(i,n,l);
			}
		}
	}

	b2=0;
	for (int j=1; j<=Dim; j++) {
		for (int l=0; l<N-1; l++) {
			for (int i=0; i<N+1; i++) {
				for (int n=0; n<N-1; n++) {
					b2(i) += Xpk(j-1,n)*Ypk(j-1,l)*Brs2(i,n,l);
				}
			}
		}
	}

	c2=0;
	for (int j=1; j<=Dim; j++) {
		for (int l=0; l<N-1; l++) {
			for (int i=0; i<N+1; i++) {
				for (int n=0; n<N+1; n++) {
					c2(l) += Xvk(j-1,i)*Yvk(j-1,n)*Brs1(i,n,l);
				}
			}
		}
	}
}




#endif /* PGDS_H_ */
