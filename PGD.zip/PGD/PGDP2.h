/*
 * PGD2.h
 *
 *  Created on: 18 Jun 2012
 *      Author: plog
 */

#ifndef PGD2_H_
#define PGD2_H_

#include "PGDP.h"
#include "blaspp.h"
#include "laslv.h"
#include <blas1pp.h>
#include <stdio.h>
#include "arrays.h"


//PGD for the Poisson equation-----------------------------
void PGDPoisson(Arr& X, Arr& Y, Arr& RHS) {

	double E;

	clock_t time, time2;

	time = clock();

	double tol = 1e-8;

	dx = (bx-ax)/(double)Kx;
    dy = (by-ay)/(double)Ky; //Size of elements (fixed length)

	D.resize(N+1,N+1);
	z.resize(N+1);
	w.resize(N+1);

	xx.resize(Kx,N+1);
	yy.resize(Ky,N+1);

	{
		Arr Leg(N+1);

		DzwL(D,z,w,Leg); //Weights, points, differentiation matrix initiation

	}


	//Generating physical points in x and y (and boundary conditions) :
	{

		Arr uN(Kx,N+1), uE(Ky,N+1), uS(Kx,N+1), uW(Ky,N+1);

		for (int i=0; i<N+1; i++) {
			for (int j=1; j<=Kx; j++) {
				xx(j-1,i)=ax+(j-1)*dx+((z(i)+1)*dx)/2;
				uN(j-1,i)=Pbct(xx(j-1,i));
				uS(j-1,i)=Pbcb(xx(j-1,i));
			}
		}

		for (int i=0; i<N+1; i++) {
			for (int j=1; j<=Ky; j++) {
				yy(j-1,i)=ay+(j-1)*dy+((z(i)+1)*dy)/2;
				uE(j-1,i)=Pbcr(yy(j-1,i));
				uW(j-1,i)=Pbcl(yy(j-1,i));
			}
		}

		transint(X,Y,uN,uE,uS,uW); //Transfinite Interpolation (sets basis functions for Dim=0,...,3.)

	}

	if (RHS.size()==0) {
		RHS.resize(N+1,N+1,Kx,Ky);
		PSetRHS(RHS);
	}

	//Arrays----

	Arr fx(N*Kx+1), fy(N*Ky+1);
	Arr Ax(N*Kx+1,N*Kx+1), Ay(N*Ky+1,N*Ky+1);

	Arr r(N+1,Kx), r2(N+1,Kx);
	Arr s(N+1,Ky), s2(N+1,Ky);

	Arr rsol(N*Kx+1), ssol(N*Ky+1); //Arrays used in linear systems (holds same values as r,s but in a less accessible way)

	//Smaller arrays to be used in for loop over k=1,...,Kx and k=1,...,Ky:

	Arr rsk(N+1); //Array holds rows of r or rows of s

	Arr Xk(J,N+1), Yk(J,N+1); //Holds parts of X and Y respectively

	Arr A(N+1,N+1), f1(N+1), f2(N+1); //Holds local matrices/RHS's

	Arr tenA(N+1,N+1,N+1,N+1); //Holds values of a(h_i,h_n,h_m,h_l)




	//Main code for PGD starts here:-----------------------------------------------------------------------------

	PGDLapl(tenA); //Populate array A (used in matrix construction)

	for (Dim=4; Dim<J; Dim++) {
		r=1;
		r2=1;
		s2=1;// Initial guess for r and setting values for r2/s2 so convergence test makes sense

		r(0,0)=0; // Homogeneous b.c.s
		r(N,Kx-1)=0;

		while(true) { // ADFPA iteration

			xory = 0;

			for (int ky=1; ky<=Ky; ky++) {
				for(int kx=1; kx<=Kx; kx++) {
					for(int i=0; i<N+1; i++) {
						rsk(i) = r(i,kx-1);

							for(int j=1; j<=Dim; j++) {
								Xk(j-1,i) = X(j-1,i,kx-1);
								Yk(j-1,i) = Y(j-1,i,ky-1);//Move this up maybe?
							}
						}

					setr(tenA,rsk,Xk,Yk,A,f1);


					f2=0;
					for (int i=0; i<N+1; i++) {
						for (int j=0; j<N+1; j++) {
							f2(i) += (dx*dy/4)*w(j)*w(i)*rsk(j)*RHS(j,i,kx-1,ky-1); // Contribution from RHS function
						}
					}

					for(int i=0; i<N+1; i++) {
						fy(N*(ky-1)+i) += f2(i)-f1(i); //Global RHS
						for(int j=0; j<N+1; j++) {
							Ay(N*(ky-1)+i,N*(ky-1)+j) += A(i,j); //Global matrix
						}
					}


				}
			}

			trimsolve(Ay,ssol,fy); //Solving linear system

			//ssol.norm();

			fy=0;
			Ay=0;

			for(int i=0; i<N+1; i++) {
				for(int k=1; k<=Ky; k++) {
					s(i,k-1) = ssol(N*(k-1)+i);//Writing s to more easily readable array
				}
			}

			//Checking convergence :
			E=error(r,s,r2,s2);

			if (E < tol) {
				break;
			}
			r2=r;

			//Second part of ADFPA:

			xory = 1;

			for (int kx=1; kx<=Kx; kx++) {
				for(int ky=1; ky<=Ky; ky++) {
					for(int i=0; i<N+1; i++) {
						rsk(i)=s(i,ky-1);

						for(int j=1; j<=Dim; j++) {
							Xk(j-1,i)=X(j-1,i,kx-1);//Move this up maybe?
							Yk(j-1,i)=Y(j-1,i,ky-1);
						}
					}

					sets(tenA,rsk,Xk,Yk,A,f1);


					f2=0;
					for (int i=0; i<N+1; i++) {
						for (int j=0; j<N+1; j++) {
							f2(i) += (dx*dy/4)*w(j)*w(i)*rsk(j)*RHS(i,j,kx-1,ky-1); // Contribution from RHS function
						}
					}

					for(int i=0; i<N+1; i++) {
						fx(N*(kx-1)+i) += f2(i)-f1(i); //Global RHS
						for(int j=0; j<N+1; j++) {
							Ax(N*(kx-1)+i,N*(kx-1)+j)+=A(i,j); //Global matrix
						}
					}

				}
			}

			trimsolve(Ax,rsol,fx); //Solving linear system

			fx=0;
			Ax=0;


			for(int i=0; i<N+1; i++) {
				for(int k=1; k<=Kx; k++) {
					r(i,k-1)=rsol(N*(k-1)+i); //Writing r to more easily readable array
				}
			}

			//Checking convergence :
			E=error(r,s,r2,s2);

			if (sqrt(E) < tol) {
				break;
			}
			s2=s;
		}

		for (int i=0; i<N+1; i++) {//YOU WERE HERE
			for (int k=1; k<=Kx; k++) {
				X(Dim,i,k-1)=r(i,k-1); // Fixing the converged values of r,s.
			}
			for (int k=1; k<=Ky; k++) {
				Y(Dim,i,k-1)=s(i,k-1);
			}
		}
		time2 = clock()-time;

		fprintf(CPUtime,"%15.16d %15.16e\n", Dim-3, ((float)time2)/CLOCKS_PER_SEC);
	}



	return;
}



//PGD for the Poisson equation-----------------------------
void PGDPoisson(Arr& X, Arr& Y) {

	Arr RHS;

	PGDPoisson(X,Y,RHS);

}

#endif /* PGD2_H_ */
