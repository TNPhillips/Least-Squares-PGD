/*
 * PGDS2.h
 *
 *  Created on: 28 Mar 2013
 *      Author: plog
 */

#ifndef PGDS2_H_
#define PGDS2_H_

#include "PGDS.h"
#include "blaspp.h"
#include "laslv.h"
#include <blas1pp.h>
#include <stdio.h>
#include "arrays.h"

void PGDStokes(Arr& Xu, Arr& Yu, Arr& Xv, Arr& Yv, Arr& Xp, Arr& Yp) {

	double Eu, Ev, Ep, S1, S2;

	double con;

	double fix;

	double area;

	area = (bx-ax)*(by-ay);

	if (N>7) {
		con=1e-4;
	}
	else {
		con=1e-4;
	}

	dx = (bx-ax)/(double)Kx;
	dy = (by-ay)/(double)Ky; //Size of elements (fixed length)

	D.resize(N+1,N+1);
	z.resize(N+1);
	w.resize(N+1);

	h_0.resize(N-1);
	h_N.resize(N-1);

	xx.resize(Kx,N+1);
	yy.resize(Ky,N+1);

	{
		Arr Leg(N+1);

		DzwL(D,z,w,Leg);

		for (int i=1; i<N; i++) {

			h_0(i-1) = pow(-1.0,N)*(z(i)-1)/(2*Leg(i));

			h_N(i-1)= -(z(i)+1)/(2*Leg(i));
		}

		pmmatrix(); //Pressure mass matrices

	}

	Arr RHS1(N+1,N+1,Kx,Ky), RHS2(N+1,N+1,Kx,Ky);


	{

		Arr uN(Kx,N+1), uE(Ky,N+1), uS(Kx,N+1), uW(Ky,N+1);
		Arr vN(Kx,N+1), vE(Ky,N+1), vS(Kx,N+1), vW(Ky,N+1);

		for (int i=0; i<N+1; i++) {
			for (int j=1; j<=Kx; j++) {
				xx(j-1,i)=ax+(j-1)*dx+((z(i)+1)*dx)/2;
				uN(j-1,i)=SbcuN(xx(j-1,i));
				vN(j-1,i)=SbcvN(xx(j-1,i));
				uS(j-1,i)=SbcuS(xx(j-1,i));
				vS(j-1,i)=SbcvS(xx(j-1,i));
			}
		}

		for (int i=0; i<N+1; i++) {
			for (int j=1; j<=Ky; j++) {
				yy(j-1,i)=ay+(j-1)*dy+((z(i)+1)*dy)/2;
				uE(j-1,i)=SbcuE(yy(j-1,i));
				vE(j-1,i)=SbcvE(yy(j-1,i));
				uW(j-1,i)=SbcuW(yy(j-1,i));
				vW(j-1,i)=SbcvW(yy(j-1,i));
			}
		}

		transint(Xu,Yu,uN,uE,uS,uW); //Transfinite Interpolation (sets basis functions for Dim=0,...,3.)
		transint(Xv,Yv,vN,vE,vS,vW);

	}



	SsetRHS(RHS1,RHS2);





	Arr f1(N+1), f2(N+1);

	Arr ru(N+1,Kx), ru2(N+1,Kx), su(N+1,Ky), su2(N+1,Ky);
	Arr rv(N+1,Kx), rv2(N+1,Kx), sv(N+1,Ky), sv2(N+1,Ky);
	Arr rp(N-1,Kx), rp2(N-1,Kx), sp(N-1,Ky), sp2(N-1,Ky);

	Arr Xuk(J,N+1), Yuk(J,N+1);
	Arr Xvk(J,N+1), Yvk(J,N+1);
	Arr Xpk(J,N-1), Ypk(J,N-1);

	Arr rsuk(N+1), rsvk(N+1), rspk(N-1);

	Arr rusol(N*Kx+1), rvsol(N*Kx+1), rpsol((N-1)*Kx);
	Arr susol(N*Ky+1), svsol(N*Ky+1), spsol((N-1)*Ky);


	Arr A(N+1,N+1), B(N+1,N-1), C(N+1,N+1), E(N+1,N-1), F(N-1,N-1);


	Arr fx1(N*Kx+1), fx2(N*Kx+1), fx3((N-1)*Kx);
	Arr fy1(N*Ky+1), fy2(N*Ky+1), fy3((N-1)*Ky);

	Arr Ax(N*Kx+1,N*Kx+1), Bx(N*Kx+1,(N-1)*Kx), Cx(N*Kx+1,N*Kx+1), Ex(N*Kx+1,(N-1)*Kx), Fx((N-1)*Kx,(N-1)*Kx);
	Arr Ay(N*Ky+1,N*Ky+1), By(N*Ky+1,(N-1)*Ky), Cy(N*Ky+1,N*Ky+1), Ey(N*Ky+1,(N-1)*Ky), Fy((N-1)*Ky,(N-1)*Ky);

	Arr a1(N+1), a2(N+1), b1(N+1), b2(N+1), c1(N-1), c2(N-1), c3(N-1);


	//Tensors:

	Arr tenA(N+1,N+1,N+1,N+1);
	Arr tenBx(N-1,N-1,N+1,N+1), tenBy(N-1,N-1,N+1,N+1);
	Arr tenC(N-1,N-1,N-1,N-1);

	//Main code for PGD starts here:

	PGDLapl(tenA);
	PGDb(tenBx,tenBy);
	PGDc(tenC);

	for (Dim=4; Dim<J; Dim++) {

		ru=1; //Initial 'guess'
		rv=1;
		rp=1;

		ru2=1; //Just so the convergence criterion makes sense on first iteration
		su2=1;
		rv2=1;
		sv2=1;
		rp2=1;
		sp2=1;

		ru(0,0)=0; // Homogenous b.c.s
		ru(N,Kx-1)=0;
		rv(0,0)=0;
		rv(N,Kx-1)=0;

		while(true) { // ADFPA iteration

			xory=0;


			for (int ky=1; ky<=Ky; ky++) {
				for(int kx=1; kx<=Kx; kx++) {
					for(int i=0; i<N+1; i++) {
						rsuk(i)=ru(i,kx-1);
						rsvk(i)=rv(i,kx-1);
						if (Dim!=0) {
							for(int j=1; j<=Dim; j++) {
								Xuk(j-1,i)=Xu(j-1,i,kx-1);
								Yuk(j-1,i)=Yu(j-1,i,ky-1);
								Xvk(j-1,i)=Xv(j-1,i,kx-1);
								Yvk(j-1,i)=Yv(j-1,i,ky-1);
							}
						}
					}

					for(int i=0; i<N-1; i++) {
						rspk(i)=rp(i,kx-1);
						if (Dim!=0) {
							for(int j=1; j<=Dim; j++) {
								Xpk(j-1,i)=Xp(j-1,i,kx-1);
								Ypk(j-1,i)=Yp(j-1,i,ky-1);
							}
						}
					}



					setr(tenA,rsuk,Xuk,Yuk,A,a1);
					setr(tenA,rsvk,Xvk,Yvk,C,b1);

					bsetr(tenBx,rsuk,rspk,Xuk,Yuk,Xpk,Ypk,B,a2,c1);
					bsetr(tenBy,rsvk,rspk,Xvk,Yvk,Xpk,Ypk,E,b2,c2);

					setr(tenC,rspk,Xpk,Ypk,F,c3);



					// Constructing the RHS vectors:
					S1=0;
					S2=0;

					for (int k=1; k<N; k++) {
						S1+=rspk(k-1)*h_0(k-1);
						S2+=rspk(k-1)*h_N(k-1);
					}

					f1=0;
					f2=0;

					for (int l=0; l<N+1; l++) {
						for (int i=0; i<N+1; i++) {
							f1(l) += (dx*dy/4)*w(l)*w(i)*rsuk(i)*RHS1(i,l,kx-1,ky-1);
							f2(l) += (dx*dy/4)*w(l)*w(i)*rsvk(i)*RHS2(i,l,kx-1,ky-1);
						}
					}



					for(int i=0; i<N+1; i++) {
						fy1(N*(ky-1)+i) += f1(i)-a1(i)-a2(i); //Global RHS's
						fy2(N*(ky-1)+i) += f2(i)-b1(i)-b2(i);
						for(int j=0; j<N+1; j++) {
							Ay(N*(ky-1)+i,N*(ky-1)+j) += A(i,j);
							Cy(N*(ky-1)+i,N*(ky-1)+j) += C(i,j);
						}
						for(int j=0; j<N-1; j++) {
							By(N*(ky-1)+i,(N-1)*(ky-1)+j) += B(i,j);
							Ey(N*(ky-1)+i,(N-1)*(ky-1)+j) += E(i,j);
						}
					}
					for(int i=0; i<N-1; i++) {
						fy3((N-1)*(ky-1)+i) += -c1(i)-c2(i)-c3(i);
						for(int j=0; j<N-1; j++) {
							Fy((N-1)*(ky-1)+i,(N-1)*(ky-1)+j) += F(i,j);//Global matrices
						}
					}


				}
			}


			trimglobal2(Ay,By,Cy,Ey,Fy,susol,svsol,spsol,fy1,fy2,fy3);

			susol.norm();
			svsol.norm();
			spsol.norm();

			Ay=0;
			By=0;
			Cy=0;
			Ey=0;
			Fy=0;
			fy1=0;
			fy2=0;
			fy3=0;



			for(int i=0; i<N+1; i++) {
				for(int k=1; k<=Ky; k++) {
					su(i,k-1)=susol(N*(k-1)+i); //Writing su, sv, sp to more easily readable array
					sv(i,k-1)=svsol(N*(k-1)+i);
				}
			}

			for(int i=0; i<N-1; i++) {
				for(int k=1; k<=Ky; k++) {
					sp(i,k-1)=spsol((N-1)*(k-1)+i);
				}
			}





			//Checking convergence :
			Eu=0;
			Ev=0;
			Ep=0;
			for (int kx=1; kx<=Kx; kx++) {
				for(int ky=1; ky<=Ky; ky++) {
					for (int i=0; i<N+1; i++) {
						for (int j=0; j<N+1; j++) {
							Eu += w(i)*w(j)*pow(ru(i,kx-1)*su(j,ky-1)-ru2(i,kx-1)*su2(j,ky-1),2);
							Ev += w(i)*w(j)*pow(rv(i,kx-1)*sv(j,ky-1)-rv2(i,kx-1)*sv2(j,ky-1),2);
						}
					}
					for (int i=1; i<N; i++) {
						for (int j=1; j<N; j++) {
							Ep += w(i)*w(j)*pow(rp(i-1,kx-1)*sp(j-1,ky-1)-rp2(i-1,kx-1)*sp2(j-1,ky-1),2);
							//Note this isnt the full error for pressure, it will be slightly more.
						}
					}
				}
			}

			Eu *= dx*dy/4;
			Ev *= dx*dy/4;
			Ep *= dx*dy/4;

			cout << sqrt(Eu) << " " << sqrt(Ev) << " " << sqrt(Ep) << endl;

			if (sqrt(Eu) < con && sqrt(Ev) < con && sqrt(Ep) < con) {
				break;
			}
			ru2=ru;
			rv2=rv;
			rp2=rp;

			// Second part of ADFPA (all very similar)

			xory=1;


			for (int kx=1; kx<=Kx; kx++) {
				for(int ky=1; ky<=Ky; ky++) {
					for(int i=0; i<N+1; i++) {
						rsuk(i)=su(i,ky-1);
						rsvk(i)=sv(i,ky-1);
						if (Dim!=0) {
							for(int j=1; j<=Dim; j++) {
								Xuk(j-1,i)=Xu(j-1,i,kx-1);
								Yuk(j-1,i)=Yu(j-1,i,ky-1);
								Xvk(j-1,i)=Xv(j-1,i,kx-1);
								Yvk(j-1,i)=Yv(j-1,i,ky-1);
							}
						}
					}

					for(int i=0; i<N-1; i++) {
						rspk(i)=sp(i,ky-1);
						if (Dim!=0) {
							for(int j=1; j<=Dim; j++) {
								Xpk(j-1,i)=Xp(j-1,i,kx-1);
								Ypk(j-1,i)=Yp(j-1,i,ky-1);
							}
						}
					}

					sets(tenA,rsuk,Xuk,Yuk,A,a1);
					sets(tenA,rsvk,Xvk,Yvk,C,b1);

					bsets(tenBx,rsuk,rspk,Xuk,Yuk,Xpk,Ypk,B,a2,c1);
					bsets(tenBy,rsvk,rspk,Xvk,Yvk,Xpk,Ypk,E,b2,c2);

					sets(tenC,rspk,Xpk,Ypk,F,c3);


					// Constructing the RHS vectors:
					S1=0;// Initialising arrays for PGD coefficients
					S2=0;

					for (int k=1; k<N; k++) {
						S1+=rspk(k-1)*h_0(k-1);
						S2+=rspk(k-1)*h_N(k-1);
					}

					f1=0;
					f2=0;

					for (int l=0; l<N+1; l++) {
						for (int i=0; i<N+1; i++) {
							f1(l) += (dx*dy/4)*w(l)*w(i)*rsuk(i)*RHS1(l,i,kx-1,ky-1);
							f2(l) += (dx*dy/4)*w(l)*w(i)*rsvk(i)*RHS2(l,i,kx-1,ky-1);
						}
					}



					for(int i=0; i<N+1; i++) {
						fx1(N*(kx-1)+i) += f1(i)-a1(i)-a2(i); //Global RHS's
						fx2(N*(kx-1)+i) += f2(i)-b1(i)-b2(i);
						for(int j=0; j<N+1; j++) {
							Ax(N*(kx-1)+i,N*(kx-1)+j) += A(i,j);
							Cx(N*(kx-1)+i,N*(kx-1)+j) += C(i,j);
						}
						for(int j=0; j<N-1; j++) {
							Bx(N*(kx-1)+i,(N-1)*(kx-1)+j) += B(i,j);
							Ex(N*(kx-1)+i,(N-1)*(kx-1)+j) += E(i,j);
						}
					}
					for(int i=0; i<N-1; i++) {
						fx3((N-1)*(kx-1)+i) += -c1(i)-c2(i)-c3(i);
						for(int j=0; j<N-1; j++) {
							Fx((N-1)*(kx-1)+i,(N-1)*(kx-1)+j) += F(i,j);//Global matrices
						}
					}


				}
			}

			trimglobal2(Ax,Bx,Cx,Ex,Fx,rusol,rvsol,rpsol,fx1,fx2,fx3);


			Ax=0;
			Bx=0;
			Cx=0;
			Ex=0;
			Fx=0;
			fx1=0;
			fx2=0;
			fx3=0;

			for(int i=0; i<N+1; i++) {
					for(int k=1; k<=Kx; k++) {
						ru(i,k-1)=rusol(N*(k-1)+i); //Writing su, sv, sp to more easily readable array
						rv(i,k-1)=rvsol(N*(k-1)+i);
					}
				}

				for(int i=0; i<N-1; i++) {
					for(int k=1; k<=Kx; k++) {
						rp(i,k-1)=rpsol((N-1)*(k-1)+i);
					}
				}


			//Checking convergence :
			Eu=0;
			Ev=0;
			Ep=0;
			for (int kx=1; kx<=Kx; kx++) {
				for(int ky=1; ky<=Ky; ky++) {
					for (int i=0; i<N+1; i++) {
						for (int j=0; j<N+1; j++) {
							Eu += w(i)*w(j)*pow(ru(i,kx-1)*su(j,ky-1)-ru2(i,kx-1)*su2(j,ky-1),2);
							Ev += w(i)*w(j)*pow(rv(i,kx-1)*sv(j,ky-1)-rv2(i,kx-1)*sv2(j,ky-1),2);
						}
					}
					for (int i=1; i<N; i++) {
						for (int j=1; j<N; j++) {
							Ep += w(i)*w(j)*pow(rp(i-1,kx-1)*sp(j-1,ky-1)-rp2(i-1,kx-1)*sp2(j-1,ky-1),2);
							//Note this isnt the full error for pressure, it will be slightly more.
						}
					}
				}
			}


			Eu *= dx*dy/4;
			Ev *= dx*dy/4;
			Ep *= dx*dy/4;

			cout << sqrt(Eu) << " " << sqrt(Ev) << " " << sqrt(Ep) << endl;

			if (sqrt(Eu) < con && sqrt(Ev) < con && sqrt(Ep) < con) {
				break;
			}

			su2=su;
			sv2=sv;
			sp2=sp;
		}


		fix=0;

		for (int k=1; k<=Kx; k++) {
			for (int l=1; l<=Ky; l++) {
				for (int i=1; i<N; i++) {
					for (int n=1; n<N; n++) {
						fix += (dx*dy/4)*(w(i)+w(0)*h_0(i-1)+w(N)*h_N(i-1))*(w(n)+w(0)*h_0(n-1)+w(N)*h_N(n-1))*rp(i-1,k-1)*sp(n-1,l-1);
					}
				}
			}
		}

		cout << fix << endl;

		// Fixing the converged values of r,s:


		for(int k=1; k<=Kx; k++) {
			for (int i=0; i<N+1; i++) {
				Xu(Dim,i,k-1)=ru(i,k-1);
				Xv(Dim,i,k-1)=rv(i,k-1);
			}
			for (int i=0; i<N-1; i++) {
				Xp(Dim,i,k-1)=rp(i,k-1);
				Xp(0,i,k-1)=-fix/area;
			}
		}

		for(int k=1; k<=Ky; k++) {
			for (int i=0; i<N+1; i++) {
				Yu(Dim,i,k-1)=su(i,k-1);
				Yv(Dim,i,k-1)=sv(i,k-1);
			}
			for (int i=0; i<N-1; i++) {
				Yp(Dim,i,k-1)=sp(i,k-1);
				Yp(0,i,k-1)=1;
			}
		}
	}
	return;
	// cout << Xp(0,0,0) << endl;
}




#endif /* PGDS2_H_ */
