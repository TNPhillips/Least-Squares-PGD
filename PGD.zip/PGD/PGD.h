/*
 * PGD.h
 *
 *  Created on: 17 May 2012
 *      Author: plog
 */

#ifndef PGD_H_
#define PGD_H_

#include <gmd.h>
#include <lavd.h>
#include <iostream>
#include "Polylib.h"
#include <math.h>
#include <laslv.h>
#include "blaspp.h"
#include <blas1pp.h>
#include "arrays.h"

using namespace std;
using namespace polylib;

const double PI = 3.14159265358979323846264338327950288;

bool stream;

const double ting = 100; //Adjustable constant

double hh; //Value that gets smaller as N,Kx,Ky increase
bool ishh; // Use weightings h^2 and K^h ?


//-------GLOBAL VARIABLES---------

FILE *CPUtime;

Arr z, w; //GLL Points (z), weights (w)
Arr xx, yy; //Physical points (in x and y directions)
Arr D; //Collocation matrix (D), Matrix A from weak laplacian (matA), Kroneker Delta (kd)
int J, N, Kx, Ky; // # of PGD basis functions (J), polynomial degree (N), current PGD iteration (Dim)
double ax, ay, bx, by, dx, dy; // Domain [ax,bx]x[ay,by] and sizes of these dx, dy
int M; //Number of fourier modes
bool xory; // Keeps track of which part of the ADFPA its in

int Dim; // Keeps track on which iteration of the PGD its on


// DO NOT USE z, w, Leg, D, J, N, Dim for anything else!!!!!!


//Gives differentiation matrix, GLL points, weights and evaluation at Legendre polynomials------
void DzwL(Arr& D, Arr& z, Arr& w, Arr& Leg) {

	double *d,*z1,*w1,*leg1;
	d= new double[N*N+2*N+1];
	z1= new double[N+1];
	w1= new double[N+1];
	leg1= new double[N+1];
	zwglj(z1,w1,N+1,0,0); // GLL Points(z) and Weights(w)
	Dglj(d,z1,N+1,0,0); // Differentiation matrix
	jacobf(N+1,z1,leg1,N,0,0);//Legendre polynomial evaluated at GLL points
	for (int i=0; i<N+1; i++) {
		for (int j=0; j<N+1; j++) {
			D(i,j)=d[i*(N+1)+j]; // Converting to a 2D Array
		}
	}
	z.copy(z1);
	w.copy(w1);
	Leg.copy(leg1);
	delete[] d;
	delete[] w1;
	delete[] z1;
	delete[] leg1;
	return;

}

//Preconditioned minres
void minres(LaGenMatDouble A, LaVectorDouble& u, LaVectorDouble f) {

	double H = u.size();

	int count;

	LaGenMatDouble M(H,H);

	M=0;

	for (int i=0; i<H; i++) {
		M(i,i)=1;
	}


	LaVectorDouble v0(H), v1(H), w0(H), w1(H), z0(H), z1(H);
	double gam0, gam1, eta, s0, s1, c0, c1, d1, a0, a1, a2, a3;

	v0=0;
	w0=0;
	w1=0;
	z0=0;

	gam0=1;

	u=1; //Initial guess

	v1=f-A*u;

	LaLinearSolve(M,z1,v1);

	gam1=sqrt(Blas_Dot_Prod(z1,v1));
	eta=gam1;

	s0=0;
	s1=0;
	c0=1;
	c1=1;

	LaVectorDouble vt, wt;


	count = 0;

	while (fabs(eta)>1e-7){

		count++;

		if(count>1000) {
			break;
		}

		Blas_Scale(1./gam1,z1);

		d1=Blas_Dot_Prod(A*z1,z1);

		vt=v1;
		v1=A*z1-(d1/gam1)*v1-(gam1/gam0)*v0;
		v0=vt;

		z0=z1;
		LaLinearSolve(M,z1,v1);

		gam0=gam1;
		gam1=sqrt(Blas_Dot_Prod(z1,v1));



		a0=c1*d1-c0*s1*gam0;
		a1=sqrt(a0*a0+gam1*gam1);
		a2=s1*d1+c0*c1*gam0;
		a3=s0*gam0;

		c0=c1;
		c1=a0/a1;

		s0=s1;
		s1=gam1/a1;


		wt=w1;
		w1=(1./a1)*z0-(a3/a1)*w0-(a2/a1)*w1;
		w0=wt;

		u=u+c1*eta*w1;

		eta=-s1*eta;


	}


}

//Subroutine for checking convergence of ADFPA
double error(Arr& r, Arr& s, Arr& r2, Arr& s2) {
	double E=0;
	for (int kx=1; kx<=Kx; kx++) {
		for(int ky=1; ky<=Ky; ky++) {
			for (int i=0; i<N+1; i++) {
				for (int j=0; j<N+1; j++) {
					E += w(i)*w(j)*pow(r(i,kx-1)*s(j,ky-1)-r2(i,kx-1)*s2(j,ky-1),2);
				}
			}
		}
	}

	E *= dx*dy/4;
	return sqrt(E);
}

//Transfinite interpolation (2D)
void transint(Arr& X, Arr& Y, Arr& Nth, Arr& Est, Arr& Sth, Arr& Wst) {

	for (int i=0; i<N+1; i++) {
		for (int j=1; j<=Kx; j++) {
			X(0,i,j-1) = (bx-xx(j-1,i))/(bx-ax);
			X(1,i,j-1) = (xx(j-1,i)-ax)/(bx-ax);
			X(2,i,j-1) = Sth(j-1,i);
			X(3,i,j-1) = Nth(j-1,i);
		}
		for (int j=1; j<=Ky; j++) {
			Y(0,i,j-1) = Wst(j-1,i)-((by-yy(j-1,i))*Sth(0,0))/(by-ay)-((yy(j-1,i)-ay)*Nth(0,0))/(by-ay);
			Y(1,i,j-1) = Est(j-1,i)-((by-yy(j-1,i))*Sth(Kx-1,N))/(by-ay)-((yy(j-1,i)-ay)*Nth(Kx-1,N))/(by-ay);
			Y(2,i,j-1) = (by-yy(j-1,i))/(by-ay);
			Y(3,i,j-1) = (yy(j-1,i)-ay)/(by-ay);
		}
	}

}

//Weak laplacian tensor
void PGDLapl(Arr& A) {

	Arr S1(N+1,N+1);
	Arr kron(N+1,N+1);

	for (int i=0; i<N+1; i++) {
		kron(i,i)=1; //Kronecker Delta
	}

	for (int i=0; i<N+1; i++) {
		for (int j=0; j<N+1; j++) {
			for (int k=0; k<N+1; k++) {
				S1(i,j) += w(k)*D(k,i)*D(k,j);
			}
		}
	}

	for(int i=0; i<N+1; i++) {
		for(int n=0; n<N+1; n++) {
			for(int m=0; m<N+1; m++) {
				for(int l=0; l<N+1; l++) {
					A(i,n,m,l) = (dy/dx)*w(n)*kron(n,l)*S1(i,m)+(dx/dy)*w(i)*kron(i,m)*S1(n,l);
				}
			}
		}
	}
}



void setr(Arr& A, Arr& rsk1, Arr& rsk2, Arr& Xk, Arr& Yk, Arr& B, Arr& f1) {

	double L = A.size();

	Arr Ars(L,L,L);

	for (int i=0; i<L; i++) {
		for (int n=0; n<L; n++) {
			for (int l=0; l<L; l++) {
				for (int m=0; m<L; m++) {
					Ars(i,n,l) += rsk1(m)*A(i,n,m,l);
				}
			}
		}
	}

	B=0;
	for (int n=0; n<L; n++) {
		for (int l=0; l<L; l++) {
			for (int i=0; i<L; i++) {
				B(l,n) += rsk2(i)*Ars(i,n,l);
			}
		}
	}

	f1=0;
	for (int j=1; j<=Dim; j++) {
		for (int l=0; l<L; l++) {
			for (int i=0; i<L; i++) {
				for (int n=0; n<L; n++) {
					f1(l) += Xk(j-1,i)*Yk(j-1,n)*Ars(i,n,l);
				}
			}
		}
	}
}

void setr(Arr& A, Arr& rsk, Arr& Xk, Arr& Yk, Arr& B, Arr& f1) {
	setr(A,rsk,rsk,Xk,Yk,B,f1);
}

void sets(Arr& A, Arr& rsk1, Arr& rsk2, Arr& Xk, Arr& Yk, Arr& B, Arr& f1) {

	double L = A.size();

	Arr Ars(L,L,L);

	for (int i=0; i<L; i++) {
		for (int n=0; n<L; n++) {
			for (int l=0; l<L; l++) {
				for (int m=0; m<L; m++) {
					Ars(i,n,m) += rsk1(l)*A(i,n,m,l);
				}
			}
		}
	}

	B=0;
	for (int n=0; n<L; n++) {
		for (int l=0; l<L; l++) {
			for (int i=0; i<L; i++) {
				B(l,i) += rsk2(n)*Ars(i,n,l);
			}
		}
	}

	f1=0;
	for (int j=1; j<=Dim; j++) {
		for (int l=0; l<L; l++) {
			for (int i=0; i<L; i++) {
				for (int n=0; n<L; n++) {
					f1(l) += Xk(j-1,i)*Yk(j-1,n)*Ars(i,n,l);
				}
			}
		}
	}

}

void sets(Arr& A, Arr& rsk, Arr& Xk, Arr& Yk, Arr& B, Arr& f1) {
	sets(A,rsk,rsk,Xk,Yk,B,f1);
}

void setvecr(Arr& A, Arr& rsk, Arr& Xk, Arr& Yk, Arr& f1) {

	double L = A.size();

	Arr Ars(L,L,L);

	for (int i=0; i<L; i++) {
		for (int n=0; n<L; n++) {
			for (int l=0; l<L; l++) {
				for (int m=0; m<L; m++) {
					Ars(n,m,l) += rsk(i)*A(i,n,m,l);
				}
			}
		}
	}

	f1=0;
	for (int j=1; j<=Dim; j++) {
		for (int l=0; l<L; l++) {
			for (int i=0; i<L; i++) {
				for (int n=0; n<L; n++) {
					f1(i) += Xk(j-1,n)*Yk(j-1,l)*Ars(i,n,l);
				}
			}
		}
	}
}

void setvecs(Arr& A, Arr& rsk, Arr& Xk, Arr& Yk, Arr& f1) {

	double L = A.size();

	Arr Ars(L,L,L);

	for (int i=0; i<L; i++) {
		for (int n=0; n<L; n++) {
			for (int l=0; l<L; l++) {
				for (int m=0; m<L; m++) {
					Ars(i,m,l) += rsk(n)*A(i,n,m,l);
				}
			}
		}
	}

	f1=0;
	for (int j=1; j<=Dim; j++) {
		for (int l=0; l<L; l++) {
			for (int i=0; i<L; i++) {
				for (int n=0; n<L; n++) {
					f1(i) += Xk(j-1,n)*Yk(j-1,l)*Ars(i,n,l);
				}
			}
		}
	}

}

void trimsolve(Arr& B, Arr& r, Arr& f) {
	int H = f.size()-2;
	LaGenMatDouble Btemp(H,H);
	LaVectorDouble rtemp(H), ftemp(H);
	for (int i=0; i<H; i++) {
		ftemp(i)=f(i+1);
		for(int j=0; j<H; j++) {
			Btemp(i,j)=B(i+1,j+1);
		}
	}
	LaLinearSolveIP(Btemp, rtemp, ftemp);
	for (int i=0; i<H; i++) {
		r(i+1)=rtemp(i);
	}

}

void trimsolve0(Arr& B, Arr& r, Arr& f) {
	int H = f.size()-1;
	LaGenMatDouble Btemp(H,H);
	LaVectorDouble rtemp(H), ftemp(H);
	for (int i=0; i<H; i++) {
		ftemp(i)=f(i);
		for(int j=0; j<H; j++) {
			Btemp(i,j)=B(i,j);
		}
	}
	LaLinearSolveIP(Btemp, rtemp, ftemp);
	for (int i=0; i<H; i++) {
		r(i)=rtemp(i);
	}

}

void justsolve(Arr& B, Arr& r, Arr& f) {
	int H = f.size();
	LaGenMatDouble Btemp(H,H);
	LaVectorDouble rtemp(H), ftemp(H);
	for (int i=0; i<H; i++) {
		ftemp(i)=f(i);
		for(int j=0; j<H; j++) {
			Btemp(i,j)=B(i,j);
		}
	}
	LaLinearSolveIP(Btemp, rtemp, ftemp);
	for (int i=0; i<H; i++) {
		r(i)=rtemp(i);
	}
}


#endif /* PGD_H_ */
