/*
 * FP1D2.h
 *
 *  Created on: 19 Jun 2014
 *      Author: plog
 */

#ifndef FP1D2_H_
#define FP1D2_H_


#include "FP1D.h"
#include "blaspp.h"
#include "laslv.h"
#include <blas1pp.h>
#include <stdio.h>
#include "arrays.h"

void PGDFP1D(Arr& X, Arr& Y, Arr& Xold, Arr& Yold, double kap) {

	double E;

	double tol = 1e-4;

	dx = (bx-ax)/(double)Kx;
	dy = (by-ay)/(double)Ky; //Size of elements (fixed length)


	D.resize(N+1,N+1);
	z.resize(N+1);
	w.resize(N+1);

	xx.resize(Kx,N+1);
	yy.resize(Ky,N+1);
	mx.resize(Kx,N+1);
	mxi.resize(Kx,N+1);
	my.resize(Ky,N+1);
	myi.resize(Ky,N+1);

	{
		Arr Leg(N+1);

		DzwL(D,z,w,Leg); //Weights, points, differentiation matrix initiation

	}


	//Generating physical points in x and y (and boundary conditions) :

	for (int i=0; i<N+1; i++) {
		for (int j=1; j<=Kx; j++) {
			xx(j-1,i)=ax+(j-1)*dx+((z(i)+1)*dx)/2;
		}
	}

	for (int i=0; i<N+1; i++) {
		for (int j=1; j<=Ky; j++) {
			yy(j-1,i)=ay+(j-1)*dy+((z(i)+1)*dy)/2;
		}
	}

	if (timestep1) {
		if (!cov) {
			for (int i=0; i<N+1; i++) {
				for (int j=1; j<=Kx; j++) {
					//Xold(0,i,j-1) = sin(PI*(-1+2*(xx(j-1,i)-ax)/(bx-ax)));
					Xold(0,i,j-1) = sqrtmax(xx(j-1,i));
					//Xold(0,i,j-1) = (693*mmnorm/2048)*(1-(xx(j-1,i)*xx(j-1,i)/16));
				}
				for (int j=1; j<=Ky; j++) {
					//Yold(0,i,j-1) = sin(PI*(-1+2*(yy(j-1,i)-ay)/(by-ay)));
					Yold(0,i,j-1) = (1/mmnorm)*sqrtmax(yy(j-1,i)); //Normality included here for mm=4
					//Yold(0,i,j-1) = (693.0/2048.0)*(1-(yy(j-1,i)*yy(j-1,i)/16));
				}
			}
			Xold(0,0,0) = 0;
			Xold(0,N,Kx-1) = 0;
			Yold(0,0,0) = 0;
			Yold(0,N,Ky-1) = 0;
		}
		else {
			Xold = 0;
			Yold = 0;
		}
	}

	for (int i=0; i<N+1; i++) {
		for (int k=0; k<Kx; k++) {
			if (((i==0) && (k==0)) || ((i==N) && (k==Kx-1))) {
				mx(k,i) = 0;
				mxi(k,i) = 10000000;
			}
			else {
				mx(k,i) = sqrtmax(xx(k,i));
				mxi(k,i) = 1.0/mx(k,i);
			}

		}

		for (int k=0; k<Ky; k++) {


			if (((i==0) && (k==0)) || ((i==N) && (k==Ky-1))) {
				my(k,i) = 0;
				myi(k,i) = 10000000;
			}
			else {
				my(k,i) = sqrtmax(yy(k,i));
				myi(k,i) = 1.0/my(k,i);
			}

		}
	}




	//Arrays----

	Arr fx(N*Kx+1), fy(N*Ky+1);
	Arr Ax(N*Kx+1,N*Kx+1), Ay(N*Ky+1,N*Ky+1);

	Arr lagy(N*Ky+1);

	Arr r(N+1,Kx), r2(N+1,Kx);
	Arr s(N+1,Ky), s2(N+1,Ky);

	Arr rsol(N*Kx+1), ssol(N*Ky+1); //Arrays used in linear systems (holds same values as r,s but in a less accessible way)

	//Smaller arrays to be used in for loop over k=1,...,Kx and k=1,...,Ky:

	Arr rsk(N+1), rsk2(N+1); //Array holds rows of r or rows of s

	Arr mk(N+1);

	Arr Xk(J,N+1), Yk(J,N+1); //Holds parts of X and Y respectively

	Arr A(N+1,N+1), f1(N+1), f2(N+1); //Holds local matrices/RHS's

	Arr tenA(N+1,N+1,N+1,N+1); //Holds values of a(h_i,h_n,h_m,h_l)

	Arr tenll(N+1,N+1,N+1,N+1);

	Arr kron(N+1,N+1);

	for (int i=0; i<N+1; i++) {
		kron(i,i)=1; //Kronecker Delta
	}




	//Main code for PGD starts here:-----------------------------------------------------------------------------

	for (Dim=0; Dim<J; Dim++) {
		r=1;
		r2=1;
		s2=1;// Initial guess for r and setting values for r2/s2 so convergence test makes sense

		r(0,0)=0; // Homogeneous b.c.s
		r(N,Kx-1)=0;
		s(0,0)=0;
		s(N,Ky-1)=0;


		/*for(int i=0; i<N+1; i++) {
			for (int k=0; k<Kx; k++) {
				r(i,k)=Xold(Dim,i,k);
			}
		}*/


		while(true) { // ADFPA iteration

			xory = 0;

			for (int ky=1; ky<=Ky; ky++) {
				for(int kx=1; kx<=Kx; kx++) {
					for(int i=0; i<N+1; i++) {
						if (suli) {
							rsk(i) = mx(kx-1,i);
						}
						else {
							rsk(i) = r(i,kx-1);
						}
						rsk2(i) = r(i,kx-1);

						for(int j=1; j<=Dim; j++) {
							Xk(j-1,i) = X(j-1,i,kx-1);
							Yk(j-1,i) = Y(j-1,i,ky-1);//Move this up maybe?
						}
					}

					fptensor2(tenA,kx,ky,kap);


					setr(tenA,rsk2,rsk,Xk,Yk,A,f1);



					f2=0;
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							if (unst) {
								for (int j=0; j<J; j++) {
									if (semimp) {
										for (int p=0; p<N+1; p++) {
											f2(n) += kap*(dy/2)*w(p)*xx(kx-1,p)*Xold(j,p,kx-1)*mx(kx-1,p)*rsk(i)*mxi(kx-1,i)*D(p,i)*w(n)*Yold(j,n,ky-1);
											f2(n) += kap*(dx/2)*w(p)*yy(ky-1,p)*Yold(j,p,ky-1)*my(ky-1,p)*myi(ky-1,n)*D(p,n)*w(i)*rsk(i)*Xold(j,i,kx-1);
											for (int q=0; q<N+1; q++) {
												//f2(n) += -alp*(dy/dx)*rsk(i)*w(q)*mxi(kx-1,q)*mxi(kx-1,q)*D(q,p)*D(q,i)*xx(kx-1,i)*xx(kx-1,p)*mx(kx-1,i)*mx(kx-1,p)*Xold(j,p,kx-1)*w(n)*Yold(j,n,ky-1);
												//f2(n) += -alp*(dx/dy)*rsk(i)*w(q)*myi(ky-1,q)*myi(ky-1,q)*D(q,p)*D(q,n)*yy(ky-1,n)*yy(ky-1,p)*my(ky-1,n)*my(ky-1,p)*Yold(j,p,ky-1)*w(i)*Xold(j,i,kx-1);
												//f2(n) += -alp*rsk(i)*w(i)*mxi(kx-1,i)*D(i,p)*xx(kx-1,p)*mx(kx-1,p)*Xold(j,p,kx-1)*w(q)*myi(ky-1,q)*D(q,n)*yy(ky-1,n)*my(ky-1,n)*Yold(j,q,ky-1);
												//f2(n) += -alp*rsk(i)*w(p)*mxi(kx-1,p)*D(p,i)*xx(kx-1,i)*mx(kx-1,i)*Xold(j,p,kx-1)*w(n)*myi(ky-1,n)*D(n,q)*yy(ky-1,q)*my(ky-1,q)*Yold(j,q,ky-1);
											}


										}
									}
									f2(n) += (1/delt)*(dx*dy/4)*w(i)*w(n)*rsk(i)*Xold(j,i,kx-1)*Yold(j,n,ky-1);
								}
							}
							if (lsqnorm && !cov) {
								f2(n) += ting*(1/mmnorm)*(dx*dy/4)*w(i)*w(n)*mx(kx-1,i)*my(ky-1,n)*rsk(i);
							}
							else if (cov) {
								for (int p=0; p<N+1; p++) {
									f2(n) += kap*(dy/2)*(1/mmnorm)*rsk(i)*w(p)*xx(kx-1,p)*mx(kx-1,p)*mx(kx-1,p)*mxi(kx-1,i)*D(p,i)*w(n)*my(ky-1,n);
									f2(n) += kap*(dx/2)*(1/mmnorm)*rsk(i)*w(i)*mx(kx-1,i)*w(p)*yy(ky-1,p)*my(ky-1,p)*my(ky-1,p)*D(p,n)*myi(ky-1,n);
								}
							}

						}
					}



					for(int i=0; i<N+1; i++) {
						fy(N*(ky-1)+i) += f2(i)-f1(i); //Global RHS
						for(int j=0; j<N+1; j++) {
							Ay(N*(ky-1)+i,N*(ky-1)+j) += A(i,j); //Global matrix
						}
					}


					//Normality Condition Stuff:
					if (lsqnorm) {
						for (int kx2=1; kx2<=Kx; kx2++) {
							for (int ky2=1; ky2<=Ky; ky2++) {

								for(int i=0; i<N+1; i++) {
									rsk2(i) = r(i,kx2-1);
								}

								lltensor(tenll,kx,ky,kx2,ky2);


								setr(tenll,rsk2,rsk,Xk,Yk,A,f1);

								for(int i=0; i<N+1; i++) {
									fy(N*(ky2-1)+i) -= f1(i); //Global RHS
									for(int j=0; j<N+1; j++) {
										Ay(N*(ky2-1)+i,N*(ky-1)+j) += A(i,j); //Global matrix
									}
								}



							}
						}


					}
				}
			}



			if (lsqnorm || suli || !cov) {
				trimsolve(Ay,ssol,fy);
			}
			else {
				for (int ky=1; ky<=Ky; ky++) {
					for (int i=0; i<N+1; i++) {
						lagy(N*(ky-1)+i) += (dy/2)*w(i)*my(ky-1,i);
					}
				}
				lagsolve(Ay,ssol,fy,lagy);
			}
			//ssol.norm();

			fy=0;
			Ay=0;
			lagy=0;

			for(int i=0; i<N+1; i++) {
				for(int k=1; k<=Ky; k++) {
					s(i,k-1) = ssol(N*(k-1)+i);//Writing s to more easily readable array
				}
			}

			if (ssol.getnorm()==0) {
				break;
			}


			//Checking convergence :
			E=error(r,s,r2,s2);

			cout << E << endl;

			if (E < tol) {
				break;
			}
			r2=r;

			//Second part of ADFPA:

			xory = 1;


			for (int kx=1; kx<=Kx; kx++) {
				for(int ky=1; ky<=Ky; ky++) {
					for(int i=0; i<N+1; i++) {
						if (suli) {
							rsk(i)=my(ky-1,i);
						}
						else{
							rsk(i)=s(i,ky-1);
						}
						rsk2(i)=s(i,ky-1);

						for(int j=1; j<=Dim; j++) {
							Xk(j-1,i)=X(j-1,i,kx-1);//Move this up maybe?
							Yk(j-1,i)=Y(j-1,i,ky-1);
						}
					}

					fptensor2(tenA,kx,ky,kap);

					sets(tenA,rsk,rsk2,Xk,Yk,A,f1);


					f2=0;
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							if (unst) {
								for (int j=0; j<J; j++) {
									if (semimp) {
										for (int p=0; p<N+1; p++) {
											f2(n) += kap*(dx/2)*w(n)*Xold(j,n,kx-1)*w(p)*yy(ky-1,p)*Yold(j,p,ky-1)*my(ky-1,p)*rsk(i)*myi(ky-1,i)*D(p,i);
											f2(n) += kap*(dy/2)*w(p)*xx(kx-1,p)*Xold(j,p,kx-1)*mx(kx-1,p)*mxi(kx-1,n)*D(p,n)*w(i)*rsk(i)*Yold(j,i,ky-1);

											for (int q=0; q<N+1; q++) {
												//f2(i) += -alp*(dy/dx)*rsk(n)*w(q)*mxi(kx-1,q)*mxi(kx-1,q)*D(q,p)*D(q,i)*xx(kx-1,i)*xx(kx-1,p)*mx(kx-1,i)*mx(kx-1,p)*Xold(j,p,kx-1)*w(n)*Yold(j,n,ky-1);
												//f2(i) += -alp*(dx/dy)*rsk(n)*w(q)*myi(ky-1,q)*myi(ky-1,q)*D(q,p)*D(q,n)*yy(ky-1,n)*yy(ky-1,p)*my(ky-1,n)*my(ky-1,p)*Yold(j,p,ky-1)*w(i)*Xold(j,i,kx-1);
												//f2(i) += -alp*rsk(n)*w(i)*mxi(kx-1,i)*D(i,p)*xx(kx-1,p)*mx(kx-1,p)*Xold(j,p,kx-1)*w(q)*myi(ky-1,q)*D(q,n)*yy(ky-1,n)*my(ky-1,n)*Yold(j,q,ky-1);
												//f2(i) += -alp*rsk(n)*w(p)*mxi(kx-1,p)*D(p,i)*xx(kx-1,i)*mx(kx-1,i)*Xold(j,p,kx-1)*w(n)*myi(ky-1,n)*D(n,q)*yy(ky-1,q)*my(ky-1,q)*Yold(j,q,ky-1);
											}
										}
									}
									f2(i) += (1/delt)*(dx*dy/4)*w(i)*w(n)*rsk(n)*Xold(j,i,kx-1)*Yold(j,n,ky-1);
								}
							}
							if (lsqnorm && !cov) {
								f2(i) += ting*(1/mmnorm)*(dx*dy/4)*w(i)*w(n)*mx(kx-1,i)*my(ky-1,n)*rsk(n);
							}
							else if (cov) {
								for (int p=0; p<N+1; p++) {
									f2(i) += kap*(dy/2)*(1/mmnorm)*rsk(n)*w(p)*xx(kx-1,p)*mx(kx-1,p)*mx(kx-1,p)*mxi(kx-1,i)*D(p,i)*w(n)*my(ky-1,n);
									f2(i) += kap*(dx/2)*(1/mmnorm)*rsk(n)*w(i)*mx(kx-1,i)*w(p)*yy(ky-1,p)*my(ky-1,p)*my(ky-1,p)*D(p,n)*myi(ky-1,n);
								}
							}

						}
					}

					for(int i=0; i<N+1; i++) {
						fx(N*(kx-1)+i) += f2(i)-f1(i); //Global RHS
						for(int j=0; j<N+1; j++) {
							Ax(N*(kx-1)+i,N*(kx-1)+j)+=A(i,j); //Global matrix
						}
					}

					//Normality Condition Stuff:
					if (lsqnorm) {
						for (int kx2=1; kx2<=Kx; kx2++) {
							for (int ky2=1; ky2<=Ky; ky2++) {

								for(int i=0; i<N+1; i++) {
									rsk2(i) = s(i,ky2-1);
								}

								lltensor(tenll,kx,ky,kx2,ky2);

								sets(tenll,rsk2,rsk,Xk,Yk,A,f1);

								for(int i=0; i<N+1; i++) {
									fx(N*(kx2-1)+i) -= f1(i); //Global RHS
									for(int j=0; j<N+1; j++) {
										Ax(N*(kx2-1)+i,N*(kx-1)+j) += A(i,j); //Global matrix
									}
								}



							}
						}

					}
				}
			}


			trimsolve(Ax,rsol,fx); //Solving linear system

			fx=0;
			Ax=0;


			for(int i=0; i<N+1; i++) {
				for(int k=1; k<=Kx; k++) {
					r(i,k-1)=rsol(N*(k-1)+i); //Writing r to more easily readable array
				}
			}

			if (rsol.getnorm()==0) {
				break;
			}

			//Checking convergence :
			E=error(r,s,r2,s2);

			cout << E << endl;

			if (sqrt(E) < tol) {
				break;
			}
			s2=s;
		}

		for (int i=0; i<N+1; i++) {
			for (int k=1; k<=Kx; k++) {
				X(Dim,i,k-1)=r(i,k-1); // Fixing the converged values of r,s.
			}
			for (int k=1; k<=Ky; k++) {
				Y(Dim,i,k-1)=s(i,k-1);
			}
		}
	}



	return;
}


#endif /* FP1D2_H_ */
