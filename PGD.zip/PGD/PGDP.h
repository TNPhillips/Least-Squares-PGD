/*
 * PGDP.h
 *
 *  Created on: 27 Mar 2013
 *      Author: plog
 */

#ifndef PGDP_H_
#define PGDP_H_

#include "PGD.h"
#include <gmd.h>
#include <lavd.h>
#include <iostream>
#include "Polylib.h"
#include <math.h>
#include <laslv.h>
#include "blaspp.h"
#include <blas1pp.h>
#include "arrays.h"

using namespace std;
using namespace polylib;




//True solution for Poisson-------------------------------------------
double Psol(double x, double y) {
	return sin(PI*cos(PI*x)*cos(PI*y));
	//return x*y*cos(2*PI*x*y);
	//return sin(PI*(ax-x)*(bx-x)*(ay-y)*(by-y));
	//double f1 = sin(PI*x)*sin(PI*y);
	//double f2 = (x*x-1)*(y*y-1);
	//double f3 = (exp(x*x-1)-1)*(exp(y*y-1)-1);
	//return f1+f2;

	//return sin(PI*x*y);
	//return sin(PI*x)*sin(PI*y);
	//return sin(PI*x)*sin(PI*y)+(sin(PI*x)-1)*cos(PI*y);
	//return sin(PI*x)*sin(PI*y)+cos(PI*x)*cos(PI*y);
	//return sin(PI*x)*sin(PI*y)+(1-x*x)*(1-y*y);

}


//RHS for Poisson-----------------------------------------------------
double Pfct(double x,double y) {
	return PI*PI*PI*(2*cos(PI*x)*cos(PI*y)*cos(PI*cos(PI*x)*cos(PI*y))+PI*(sin(PI*x)*sin(PI*x)*cos(PI*y)*cos(PI*y)+sin(PI*y)*sin(PI*y)*cos(PI*x)*cos(PI*x))*sin(PI*cos(PI*x)*cos(PI*y)));
	//return 4*PI*(x*x+y*y)*sin(2*PI*x*y)+4*PI*PI*x*y*(x*x+y*y)*cos(2*PI*x*y);
	//double f1 = pow(PI,2)*(pow((2*y-ay-by)*(ax-x)*(bx-x),2)+pow((2*x-ax-bx)*(ay-y)*(by-y),2))*sin(PI*(ax-x)*(bx-x)*(ay-y)*(by-y));
	//double f2 = 2*PI*((ay-y)*(by-y)+(ax-x)*(bx-x))*cos(PI*(ax-x)*(bx-x)*(ay-y)*(by-y));
	//return f1  -f2;
	//-----------------
	//double f1 = 2*PI*PI*sin(PI*x)*sin(PI*y);
	//double f2 = 2*(x*x-1)+2*(y*y-1);
	//double f3 = 2*(1+2*x*x)*exp(x*x-1)*(exp(y*y-1)-1)+2*(1+2*y*y)*exp(y*y-1)*(exp(x*x-1)-1);
	//return f1-f2-f3;
	//return 8*PI*PI*cos(2*PI*x)*sin(2*PI*y);
	//return 2*(1-x*x)+2*(1-y*y);
	///return PI*PI*(x*x+y*y)*sin(PI*x*y);
	//return 2*PI*PI*sin(PI*x)*sin(PI*y);
	//return 2*PI*PI*sin(PI*x)*sin(PI*y)+PI*PI*(2*sin(PI*x)-1)*cos(PI*y);
	//return 2*PI*PI*sin(PI*x)*sin(PI*y)+2*PI*PI*cos(PI*x)*cos(PI*y);
	//return  2*PI*PI*sin(PI*x)*sin(PI*y)+2*(2-x*x-y*y);

}

//Left b.c. for Poisson
double Pbcl(double y) {
	//return sin(2*PI*y);
	//return 0;
	//return -y*cos(2*PI*y);
	return -sin(PI*cos(PI*y));
	//return -sin(PI*y);
	//return -cos(PI*y);
}


//Right b.c. for Poisson
double Pbcr(double y) {
	//return sin(2*PI*y);
	//return 0;
	//return y*cos(2*PI*y);
	return -sin(PI*cos(PI*y));
	//return sin(PI*y);
	//return -cos(PI*y);
}


//Top b.c. for Poisson
double Pbct(double x) {
	//return sin(PI*x);
	//return 0;
	//return x*cos(2*PI*x);
	return -sin(PI*cos(PI*x));
	//return 1-sin(PI*x);
	//return -cos(PI*x);
}


//Bottom b.c. for Poisson
double Pbcb(double x) {
	//return -sin(PI*x);
	//return 0;
	//return -x*cos(2*PI*x);
	return -sin(PI*cos(PI*x));
	//return 1-sin(PI*x);
	//return -cos(PI*x);
}


//Gives true solution at (mapped) GLL points-----------------------
void u2true(Arr& u2) {

	for (int i=0; i<N+1; i++) {
		for (int j=0; j<N+1; j++) {
			for (int k=1; k<=Kx; k++) {
				for (int l=1; l<=Ky; l++) {
					u2(i,j,k-1,l-1)=Psol(xx(k-1,i),yy(l-1,j)); // RHS of equation
				}
			}
		}
	}
}


void PSetRHS(Arr& RHS) {

	for (int i=0; i<N+1; i++) {
		for (int j=0; j<N+1; j++) {
			for (int k=1; k<=Kx; k++) {
				for (int l=1; l<=Ky; l++) {
					RHS(i,j,k-1,l-1)=Pfct(xx(k-1,i),yy(l-1,j)); // RHS of equation
				}
			}
		}
	}
}

#endif /* PGDP_H_ */
