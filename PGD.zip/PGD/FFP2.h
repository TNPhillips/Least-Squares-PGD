/*
 * FFP2.h
 *
 *  Created on: 30 Mar 2015
 *      Author: plog
 */

#ifndef FFP2_H_
#define FFP2_H_

#include "FFP.h"
#include "blaspp.h"
#include "laslv.h"
#include <blas1pp.h>
#include <stdio.h>
#include "arrays.h"

void PGDFFP(Arr& Q, Arr& Y, Arr& Qold, Arr& Yold, Arr& kap) {

	double E;

	int test=0;

	double tol = 1e-4;

	dx = (bx-ax)/(double)Kx; // Size of elements in radial direction for configuration space
	dy = (by-ay)/(double)Ky; //Size of elements (physical space) (fixed length)


	D.resize(N+1,N+1);
	z.resize(N+1);
	w.resize(N+1);

	xx.resize(Kx,N+1);
	yy.resize(Ky,N+1);

	{
		Arr Leg(N+1);

		DzwL(D,z,w,Leg); //Weights, points, differentiation matrix initiation

	}


	//Generating physical points:

	for (int i=0; i<N+1; i++) {
		for (int j=1; j<=Ky; j++) {
			yy(j-1,i)=ay+(j-1)*dy+((z(i)+1)*dy)/2;
		}
	}

	for (int i=0; i<N+1; i++) {
		for (int j=1; j<=Kx; j++) {
			xx(j-1,i)=ax+(j-1)*dx+((z(i)+1)*dx)/2;
		}
	}

	if (timestep1) {
		for (int i=0; i<N+1; i++) {
			for (int j=1; j<=Kx; j++) {
				Qold(0,i,j-1,0) =  sqrtmax(xx(j-1,i))/sqrt(mmnorm);  //Qold(J,N,Kx,2*M-1) (cos(2mT) m=0,..,M then sin(2mT) m=1,..,M)
			}
			for (int j=1; j<=Ky; j++) {
				Yold(0,i,j-1) = 1;
			}
		}
		Qold(0,N,Kx-1,0) = 0; //Boundary condition

	}


	Arr r3func(Kx,N+1), r2func(Kx,N+1), invr(Kx,N+1);

	for (int kx=1; kx<=Kx; kx++) {
		for (int i=0; i<N+1; i++) {
			r3func(kx-1,i) = pow(xx(kx-1,i),3)/(4*pow(1-(pow(xx(kx-1,i),2)/(4*mm)),2));
			r2func(kx-1,i) = pow(xx(kx-1,i),2)/(2*(1-(pow(xx(kx-1,i),2)/(4*mm))));
			invr(kx-1,i) = 1.0/xx(kx-1,i);
		}
	}

	invr(0,0) = 10e14;


	Arr r(N+1,Kx,2*M+1), r2(N+1,Kx,2*M+1);
	Arr s(N+1,Ky), s2(N+1,Ky);

	double xsum1; //Physical space integrals evaluated with GLL
	Arr xsum2(J), xsum3(J), xsum4(J);

	double qsum1; //Configuration space integrals evaluated with GLL
	Arr qsum2(J), qsum3(J), qsum4(J);

	Arr rMsol(N*Kx+1), ssol(N*Ky+1);

	Arr Ax(N*Kx+1,N*Kx+1);
	Arr Ay(N*Ky+1,N*Ky+1);
	Arr A(N+1,N+1);

	Arr fx(N*Kx+1);
	Arr fy(N*Ky+1);
	Arr f1(N+1);

	double pm, mod;

	for (Dim=0; Dim<J; Dim++) {
		r2=1;
		s=1;
		s2=1;// Initial guess for s and setting values for r2/s2 so convergence test makes sense

		r2(N,Kx-1,0)=0;  // Boundary condition
		for (int m=1; m<2*M+1; m++) {
			r2(0,0,m)=0; //Pole conditions
			r2(N,Kx-1,m)=0; //Boundary conditions
		}


		while(true) { // ADFPA iteration

			//Evaluating physical space integrals with GLL quadrature:
			xsum1=0;
			xsum2=0;
			xsum3=0;
			xsum4=0;
			for (int ky=1; ky<=Ky; ky++) {
				for (int i=0; i<N+1; i++) {
					xsum1 += w(i)*s(i,ky-1)*s(i,ky-1);
					for (int j=0; j<J; j++) {
						xsum2(j) += w(i)*kap(i,ky-1)*s(i,ky-1)*Yold(j,i,ky-1);
						xsum3(j) += w(i)*s(i,ky-1)*Yold(j,i,ky-1);
					}
				}

				if (Dim>0) {
					for (int i=0; i<N+1; i++) {
						for (int j=0; j<Dim; j++) {
							xsum4(j) += w(i)*s(i,ky-1)*Y(j,i,ky-1);
						}
					}
				}

			}


			for (int kx=1; kx<=Kx; kx++) {

				//Local matrices for m=0 (no pole conditions)
				A=0;
				f1=0;
				for (int i=0; i<N+1; i++) {
					A(i,i) += w(i)*xsum1*(1.0/delt)*(dx/2)*xx(kx-1,i);
					A(i,i) += w(i)*xsum1*(1.0/2*We)*(dx/2)*r3func(kx-1,i);
					for (int l=0; l<N+1; l++) {
						A(l,i) += xsum1*(1.0/2*We)*w(i)*r2func(kx-1,i)*D(i,l);
						A(l,i) += xsum1*(1.0/2*We)*w(l)*r2func(kx-1,l)*D(l,i);
						for (int n=0; n<N+1; n++) {
							A(l,i) += w(n)*xsum1*(2/dx)*(1.0/2*We)*xx(kx-1,n)*D(n,i)*D(n,l);
						}
					}
				}


				//Local RHSs for m=0:---------------------------------------------
				//Backwards Euler Contribution:
				for (int j=0; j<J; j++) {
					for (int i=0; i<N+1; i++) {
						f1(i) += w(i)*(1.0/delt)*(dx/2)*xsum3(j)*xx(kx-1,i)*Qold(j,i,kx-1,0);
					}
				}

				//Explicit convective term contribution:
				if (M>0) {
					for (int j=0; j<J; j++) {
						for (int i=0; i<N+1; i++) {
							f1(i) += w(i)*(dx/2)*(0.25)*xsum2(j)*r2func(kx-1,i)*xx(kx-1,i)*Qold(j,i,kx-1,M+1);
							for (int n=0; n<N+1; n++) {
								f1(i) += w(n)*xx(kx-1,n)*xx(kx-1,n)*(0.25)*xsum2(j)*Qold(j,n,kx-1,M+1)*D(n,i);
							}
						}
					}
				}

				//Known part of PGD contribution
				for (int j=0; j<Dim; j++) {
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							f1(i) -= (xsum4(j)/xsum1)*A(i,n)*Q(j,n,kx-1,0); //Make sure xsum1=/=0 (shouldnt be)
						}
					}
				}
				//------------------------------------------------------------------



				for(int i=0; i<N+1; i++) {
					fx(N*(kx-1)+i) += f1(i); //Global RHS for m=0
					for(int j=0; j<N+1; j++) {
						Ax(N*(kx-1)+i,N*(kx-1)+j) += A(i,j); //Global matrix for m=0
					}
				}

			}

			//cout << Ax << endl;
			//cout << fx << endl;




			rMsol=0;
			trimsolve0(Ax,rMsol,fx); //Solve with no pole condition


			for (int kx=1; kx<=Kx; kx++) {
				for(int i=0; i<N+1; i++) {
					r(i,kx-1,0)=rMsol(N*(kx-1)+i);
				}
			}

			fx=0;
			Ax=0;

			//Looping through the rest of the Fourier modes
			for (int ii=0; ii<2; ii++) {
				pm = pow(-1.0,ii);
				for (int m=1; m<=M; m++) {

					for (int kx=1; kx<=Kx; kx++) {

						//Local matrices
						A=0;
						f1=0;
						for (int i=0; i<N+1; i++) {
							A(i,i) += w(i)*xsum1*(1.0/delt)*(dx/2)*xx(kx-1,i);
							A(i,i) += w(i)*xsum1*(1.0/2*We)*(dx/2)*r3func(kx-1,i);
							A(i,i) += w(i)*xsum1*(1.0/2*We)*(dx/2)*(m*m*invr(kx-1,i));
							for (int l=0; l<N+1; l++) {
								A(l,i) += xsum1*(1.0/2*We)*w(i)*r2func(kx-1,i)*D(i,l);
								A(l,i) += xsum1*(1.0/2*We)*w(l)*r2func(kx-1,l)*D(l,i);
								for (int n=0; n<N+1; n++) {
									A(l,i) += w(n)*xsum1*(2/dx)*(1.0/2*We)*xx(kx-1,n)*D(n,i)*D(n,l);
								}
							}
						}


						//Local RHSs:---------------------------------------------
						//Backwards Euler Contribution:
						for (int j=0; j<J; j++) {
							for (int i=0; i<N+1; i++) {
								f1(i) += w(i)*(1.0/delt)*(dx/2)*xsum3(j)*xx(kx-1,i)*Qold(j,i,kx-1,m+ii*M);
							}
						}

						//Explicit convective term contribution:

						//Special cases when m=1,M:
						if (m==1) {
							mod = 2.0*ii;
						}
						else {
							mod = 1.0;
						}

						if (m<M) {
							for (int j=0; j<J; j++) {
								for (int i=0; i<N+1; i++) {
									f1(i) += pm*w(i)*(dx/2)*(0.25)*xsum2(j)*(r2func(kx-1,i)-m)*xx(kx-1,i)*Qold(j,i,kx-1,M*(1-ii)+m+1);
									for (int n=0; n<N+1; n++) {
										f1(i) += pm*w(n)*xx(kx-1,n)*xx(kx-1,n)*(0.25)*xsum2(j)*Qold(j,n,kx-1,M*(1-ii)+m+1)*D(n,i);
									}
								}
							}
						}

						for (int j=0; j<J; j++) {
							for (int i=0; i<N+1; i++) {
								f1(i) += mod*pm*w(i)*(dx/2)*(0.25)*xsum2(j)*(-r2func(kx-1,i)-m)*xx(kx-1,i)*Qold(j,i,kx-1,M*(1-ii)+m-1);
								f1(i) += pm*w(i)*(dx/2)*(0.5)*xsum2(j)*m*xx(kx-1,i)*Qold(j,i,kx-1,M*(1-ii)+m);
								for (int n=0; n<N+1; n++) {
									f1(i) += -mod*pm*w(n)*xx(kx-1,n)*xx(kx-1,n)*(0.25)*xsum2(j)*Qold(j,n,kx-1,M*(1-ii)+m-1)*D(n,i);
								}
							}
						}


						//Known part of PGD contribution
						for (int j=0; j<Dim; j++) {
							for (int i=0; i<N+1; i++) {
								for (int n=0; n<N+1; n++) {
									f1(i) -= (xsum4(j)/xsum1)*A(i,n)*Q(j,n,kx-1,m+ii*M); //Make sure xsum1=/=0 (shouldnt be)
								}
							}
						}
						//------------------------------------------------------------------

						for(int i=0; i<N+1; i++) {
							fx(N*(kx-1)+i) += f1(i); //Global RHS for m=0
							for(int j=0; j<N+1; j++) {
								Ax(N*(kx-1)+i,N*(kx-1)+j) += A(i,j); //Global matrix for m=0
							}
						}


					}

					//cout << Ax << endl;
					//cout << fx << endl;




					rMsol=0;
					trimsolve(Ax,rMsol,fx); //Solve with boundary conditions and pole conditions

					//cout << rMsol << endl;

					for (int kx=1; kx<=Kx; kx++) {
						for(int i=0; i<N+1; i++) {
							r(i,kx-1,m+ii*M)=rMsol(N*(kx-1)+i);
						}
					}

					fx=0;
					Ax=0;


				}
			}

			//Checking convergence :
			E=ffperror(r,s,r2,s2);

			cout << E << endl;

			/*if (test==1) {
				abort();
			}*/



			if (E < tol) {
				break;
			}
			s2=s;

			//SECOND PART OF THE ADFPA:=====================================================================

			//Evaluating configuration space integrals with GLL quadrature:
			qsum1=0;
			qsum2=0;
			qsum3=0;
			qsum4=0;

			for (int kx=1; kx<=Kx; kx++) {

				for (int i=0; i<N+1; i++) {
					qsum1 += PI*w(i)*(1.0/delt)*(dx/2)*xx(kx-1,i)*r(i,kx-1,0)*r(i,kx-1,0);
					qsum1 += PI*w(i)*(1.0/2*We)*(dx/2)*r3func(kx-1,i)*r(i,kx-1,0)*r(i,kx-1,0);
					for (int n=0; n<N+1; n++) {
						qsum1 += PI*(1.0/2*We)*r(i,kx-1,0)*r(n,kx-1,0)*(w(i)*r2func(kx-1,i)*D(i,n)+w(n)*r2func(kx-1,n)*D(n,i));
						for (int p=0; p<N+1; p++) {
							qsum1 += PI*w(p)*(1.0/2*We)*(2/dx)*r(i,kx-1,0)*r(n,kx-1,0)*xx(kx-1,p)*D(p,i)*D(p,n);
						}
					}
				}

				//cout << qsum1 << endl;

				for (int ii=0; ii<2; ii++) {
					for (int m=1; m<=M; m++) {

						for (int i=0; i<N+1; i++) {
							qsum1 += (PI/2)*w(i)*(1.0/delt)*(dx/2)*xx(kx-1,i)*r(i,kx-1,M*ii+m)*r(i,kx-1,M*ii+m);
							qsum1 += (PI/2)*w(i)*(1.0/2*We)*(dx/2)*r3func(kx-1,i)*r(i,kx-1,M*ii+m)*r(i,kx-1,M*ii+m);
							qsum1 += (PI/2)*w(i)*(1.0/2*We)*(dx/2)*(m*m*invr(kx-1,i))*r(i,kx-1,M*ii+m)*r(i,kx-1,M*ii+m);
							for (int n=0; n<N+1; n++) {
								qsum1 += (PI/2)*(1.0/2*We)*r(i,kx-1,M*ii+m)*r(n,kx-1,M*ii+m)*(w(i)*r2func(kx-1,i)*D(i,n)+w(n)*r2func(kx-1,n)*D(n,i));
								for (int p=0; p<N+1; p++) {
									qsum1 += (PI/2)*w(p)*(1.0/2*We)*(2/dx)*r(i,kx-1,M*ii+m)*r(n,kx-1,M*ii+m)*xx(kx-1,p)*D(p,i)*D(p,n);
								}
							}
						}
					}
				}


				//---------------------------------------------------------------------------
				if (M>0) {
					for (int j=0; j<J; j++) {
						for (int i=0; i<N+1; i++) {
							qsum2(j) += (PI/4)*w(i)*(dx/2)*r2func(kx-1,i)*xx(kx-1,i)*Qold(j,i,kx-1,M+1)*r(i,kx-1,0);
							for (int n=0; n<N+1; n++) {
								qsum2(j) += (PI/4)*w(n)*xx(kx-1,n)*xx(kx-1,n)*D(n,i)*Qold(j,n,kx-1,M+1)*r(i,kx-1,0);
							}
						}
					}
				}

				for (int ii=0; ii<2; ii++) {
					pm = pow(-1.0,ii);
					for(int m=1; m<=M; m++) {

						if (m==1) {
							mod = 2.0*ii;
						}
						else {
							mod = 1.0;
						}

						if (m<M) {
							for (int j=0; j<J; j++) {
								for (int i=0; i<N+1; i++) {
									qsum2(j) += (PI/8)*pm*w(i)*(dx/2)*(r2func(kx-1,i)-m)*xx(kx-1,i)*Qold(j,i,kx-1,M*(1-ii)+m+1)*r(i,kx-1,M*ii+m);
									for (int n=0; n<N+1; n++) {
										qsum2(j) += (PI/8)*pm*w(n)*xx(kx-1,n)*xx(kx-1,n)*Qold(j,n,kx-1,M*(1-ii)+m+1)*r(i,kx-1,M*ii+m)*D(n,i);
									}
								}
							}
						}

						for (int j=0; j<J; j++) {
							for (int i=0; i<N+1; i++) {
								qsum2(j) += (PI/8)*mod*pm*w(i)*(dx/2)*(-r2func(kx-1,i)-m)*xx(kx-1,i)*Qold(j,i,kx-1,M*(1-ii)+m-1)*r(i,kx-1,M*ii+m);
								qsum2(j) += (PI/4)*pm*w(i)*(dx/2)*m*xx(kx-1,i)*Qold(j,i,kx-1,M*(1-ii)+m)*r(i,kx-1,ii*M+m);
								for (int n=0; n<N+1; n++) {
									qsum2(j) += -(PI/8)*mod*pm*w(n)*xx(kx-1,n)*xx(kx-1,n)*Qold(j,n,kx-1,M*(1-ii)+m-1)*r(i,kx-1,M*ii+m)*D(n,i);
								}
							}
						}
					}
				}

				//---------------------------------------------------------------------------
				for (int i=0; i<N+1; i++) {
					for (int j=0; j<J; j++) {
						qsum3(j) += PI*w(i)*(dx/2)*(1.0/delt)*xx(kx-1,i)*r(i,kx-1,0)*Qold(j,i,kx-1,0);
					}
				}

				for (int ii=0; ii<2; ii++) {
					for (int m=1; m<=M; m++) {
						for (int i=0; i<N+1; i++) {
							for (int j=0; j<J; j++) {
								qsum3(j) += (PI/2)*w(i)*(dx/2)*(1.0/delt)*xx(kx-1,i)*r(i,kx-1,ii*M+m)*Qold(j,i,kx-1,ii*M+m);
							}
						}
					}
				}

				//----------------------------------------------------------------------------
				if (Dim>0) {
					for (int j=0; j<Dim; j++) {
						for (int i=0; i<N+1; i++) {
							qsum4(j) += PI*w(i)*(1.0/delt)*(dx/2)*xx(kx-1,i)*r(i,kx-1,0)*Q(j,i,kx-1,0);
							qsum4(j) += PI*w(i)*(1.0/2*We)*(dx/2)*r3func(kx-1,i)*r(i,kx-1,0)*Q(j,i,kx-1,0);
							for (int n=0; n<N+1; n++) {
								qsum4(j) += PI*(1.0/2*We)*r(i,kx-1,0)*Q(j,n,kx-1,0)*(w(i)*r2func(kx-1,i)*D(i,n)+w(n)*r2func(kx-1,n)*D(n,i));
								for (int p=0; p<N+1; p++) {
									qsum4(j) += PI*w(p)*(1.0/2*We)*(2/dx)*r(i,kx-1,0)*Q(j,n,kx-1,0)*xx(kx-1,p)*D(p,i)*D(p,n);
								}
							}
						}

						for (int ii=0; ii<2; ii++) {
							for (int m=1; m<=M; m++) {

								for (int i=0; i<N+1; i++) {
									qsum4(j) += (PI/2)*w(i)*(1.0/delt)*(dx/2)*xx(kx-1,i)*r(i,kx-1,M*ii+m)*Q(j,i,kx-1,M*ii+m);
									qsum4(j) += (PI/2)*w(i)*(1.0/2*We)*(dx/2)*r3func(kx-1,i)*r(i,kx-1,M*ii+m)*Q(j,i,kx-1,M*ii+m);
									qsum4(j) += (PI/2)*w(i)*(1.0/2*We)*(dx/2)*(m*m*invr(kx-1,i))*r(i,kx-1,M*ii+m)*Q(j,i,kx-1,M*ii+m);
									for (int n=0; n<N+1; n++) {
										qsum4(j) += (PI/2)*(1.0/2*We)*r(i,kx-1,M*ii+m)*Q(j,n,kx-1,M*ii+m)*(w(i)*r2func(kx-1,i)*D(i,n)+w(n)*r2func(kx-1,n)*D(n,i));
										for (int p=0; p<N+1; p++) {
											qsum4(j) += (PI/2)*w(p)*(1.0/2*We)*(2/dx)*r(i,kx-1,M*ii+m)*Q(j,n,kx-1,M*ii+m)*xx(kx-1,p)*D(p,i)*D(p,n);
										}
									}
								}
							}
						}
					}
				}
			}

			//------------------------------------------------------------------

			for (int ky=1; ky<=Ky; ky++) {
				// Local matrices
				A=0;
				f1=0;
				for (int i=0; i<N+1; i++) {
					A(i,i) = w(i)*qsum1;
				}

				//Local RHSs:

				//Backwards Euler Contribution:
				for (int j=0; j<J; j++) {
					for (int i=0; i<N+1; i++) {
						f1(i) += w(i)*qsum3(j)*Yold(j,i,ky-1);
					}
				}

				//Explicit convective term contribution:
				for (int j=0; j<J; j++) {
					for (int i=0; i<N+1; i++) {
						f1(i) += w(i)*qsum2(j)*Yold(j,i,ky-1)*kap(i,ky-1);
					}
				}

				//Known part of PGD contribution
				for (int j=0; j<Dim; j++) {
					for (int i=0; i<N+1; i++) {
						f1(i) -= w(i)*qsum4(j)*Y(j,i,ky-1);
					}
				}

				for(int i=0; i<N+1; i++) {
					fy(N*(ky-1)+i) += f1(i); //Global RHS for m=0
					for(int j=0; j<N+1; j++) {
						Ay(N*(ky-1)+i,N*(ky-1)+j) += A(i,j); //Global matrix for m=0
					}
				}

			}

			ssol=0;
			//cout << Ay << endl;
			//cout << fy << endl;
			justsolve(Ay,ssol,fy); //Solve with boundary conditions and pole conditions

			for (int ky=1; ky<=Ky; ky++) {
				for(int i=0; i<N+1; i++) {
					s(i,ky-1)=ssol(N*(ky-1)+i);
				}
			}
			//cout << ssol << endl;


			fy=0;
			Ay=0;

			//Checking convergence:

			E=ffperror(r,s,r2,s2);

			cout << E << endl;

			if (E < tol) {
				break;
			}
			r2=r;

			test++;

		}

		for (int i=0; i<N+1; i++) {//YOU WERE HERE
			for (int k=1; k<=Kx; k++) {
				for (int m=0; m<2*M+1; m++) {
					Q(Dim,i,k-1,m)=r(i,k-1,m); // Fixing the converged values of r,s.
				}
			}
			for (int k=1; k<=Ky; k++) {
				Y(Dim,i,k-1)=s(i,k-1);
			}
		}

	}

	return;
}





#endif /* FFP2_H_ */
