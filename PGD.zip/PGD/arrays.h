/*
 * arrays.h
 *
 *  Created on: 1 Oct 2012
 *      Author: plog
 */

#ifndef ARRAYS_H_
#define ARRAYS_H_

#include <iostream>
#include <cmath>
using namespace std;

class Arr {
private:
	double *arr;
	int maxi;
	int maxj;
	int maxk;
	int maxl;
	bool flag;

public:
	//Copy constructor:
	Arr(const Arr& other) {
		maxi=other.maxi;
		maxj=other.maxj;
		maxk=other.maxk;
		maxl=other.maxl;
		flag=other.flag;
		for (int i=0; i<maxi*maxj*maxk*maxl; i++) {
			arr[i]=other.arr[i];
		}
	}



	Arr() {
		flag=1;
		maxi=0;
		maxj=0;
		maxk=0;
		maxl=0;
	}
	Arr(int imax) {
		flag=0;
		maxi=imax;
		maxj=1;
		maxk=1;
		maxl=1;
		arr = new double[maxi];
		for (int i=0; i<maxi; i++) {
			arr[i]=0;
		}
	}
	Arr(int imax, int jmax) {
		flag=0;
		maxi=imax;
		maxj=jmax;
		maxk=1;
		maxl=1;
		arr = new double[maxi*maxj];
		for (int i=0; i<maxi*maxj; i++) {
			arr[i]=0;
		}
	}
	Arr(int imax, int jmax, int kmax) {
		flag=0;
		maxi=imax;
		maxj=jmax;
		maxk=kmax;
		maxl=1;
		arr = new double[maxi*maxj*maxk];
		for (int i=0; i<maxi*maxj*maxk; i++) {
			arr[i]=0;
		}
	}

	Arr(int imax, int jmax, int kmax, int lmax) {
		flag=0;
		maxi=imax;
		maxj=jmax;
		maxk=kmax;
		maxl=lmax;
		arr = new double[maxi*maxj*maxk*maxl];
		for (int i=0; i<maxi*maxj*maxk*maxl; i++) {
			arr[i]=0;
		}
	}

	void resize(int imax) {
		if (flag) {
			flag=0;
			maxi=imax;
			maxj=1;
			maxk=1;
			maxl=1;
			arr = new double[maxi];
			for (int i=0; i<maxi; i++) {
				arr[i]=0;
			}
		}
		else {
			delete[] arr;
			maxi=imax;
			maxj=1;
			maxk=1;
			maxl=1;
			arr = new double[maxi];
			for (int i=0; i<maxi; i++) {
				arr[i]=0;
			}
		}
	}

	void resize(int imax, int jmax) {
		if (flag) {
			flag=0;
			maxi=imax;
			maxj=jmax;
			maxk=1;
			maxl=1;
			arr = new double[maxi*maxj];
			for (int i=0; i<maxi*maxj; i++) {
				arr[i]=0;
			}
		}
		else {
			delete[] arr;
			maxi=imax;
			maxj=jmax;
			maxk=1;
			maxl=1;
			arr = new double[maxi*maxj];
			for (int i=0; i<maxi*maxj; i++) {
				arr[i]=0;
			}
		}
	}

	void resize(int imax, int jmax, int kmax) {
		if (flag) {
			flag=0;
			maxi=imax;
			maxj=jmax;
			maxk=kmax;
			maxl=1;
			arr = new double[maxi*maxj*maxk];
			for (int i=0; i<maxi*maxj*maxk; i++) {
				arr[i]=0;
			}
		}
		else {
			delete[] arr;
			maxi=imax;
			maxj=jmax;
			maxk=kmax;
			maxl=1;
			arr = new double[maxi*maxj*maxk];
			for (int i=0; i<maxi*maxj*maxk; i++) {
				arr[i]=0;
			}
		}
	}

	void resize(int imax, int jmax, int kmax, int lmax) {
		if (flag) {
			flag=0;
			maxi=imax;
			maxj=jmax;
			maxk=kmax;
			maxl=lmax;
			arr = new double[maxi*maxj*maxk*maxl];
			for (int i=0; i<maxi*maxj*maxk*maxl; i++) {
				arr[i]=0;
			}
		}
		else {
			delete[] arr;
			maxi=imax;
			maxj=jmax;
			maxk=kmax;
			maxl=lmax;
			arr = new double[maxi*maxj*maxk*maxl];
			for (int i=0; i<maxi*maxj*maxk*maxl; i++) {
				arr[i]=0;
			}
		}
	}

	int size() {
		return maxi;
	}

	~Arr() {
		if(!flag) {
			delete[] arr;
		}
		else {
			return;
		}
	}

	void copy(double *cpy) {
		for (int i=0; i<maxi*maxj*maxk*maxl; i++) {
			arr[i]=cpy[i];
		}
	}

	Arr& operator=(double val) {
		for(int i=0; i<maxi*maxj*maxk*maxl; i++) {
			arr[i]=val;
		}
		return *this;
	}

	Arr& operator*(double val) {
		for(int i=0; i<maxi*maxj*maxk*maxl; i++) {
			arr[i]=arr[i]*val;
		}
		return *this;
	}

	Arr& operator=(const Arr& other) {
		if (this == &other) {
			return *this; //Check for self assignment
		}
		if ((maxi==other.maxi) && (maxj==other.maxj) && (maxk==other.maxk) && (maxl==other.maxl)) {
			for (int i=0; i<maxi*maxj*maxk*maxl; i++) {
				arr[i]=other.arr[i];
			}
		}
		else {
			cerr << "Attempted to assign an array to another of different size." << endl;
			abort();
		}
		return *this;

	}

	/*Arr& operator+=(const Arr& other) {
		if ((maxi==other.maxi) && (maxj==other.maxj) && (maxk==other.maxk) && (maxl==other.maxl)) {
			for (int i=0; i<maxi*maxj*maxk*maxl; i++) {
				arr[i]+=other.arr[i];
			}
		}
		else {
			cerr << "Dimensions mismatch" << endl;
			abort();
		}
		return *this;

	}

	Arr& operator-=(const Arr& other) {
		if ((maxi==other.maxi) && (maxj==other.maxj) && (maxk==other.maxk) && (maxl==other.maxl)) {
			for (int i=0; i<maxi*maxj*maxk*maxl; i++) {
				arr[i]-=other.arr[i];
			}
		}
		else {
			cerr << "Dimensions mismatch" << endl;
			abort();
		}
		return *this;

	}*/

	void norm() { //Inf norm
		double max=arr[0];
		for (int i=1; i<maxi*maxj*maxk*maxl; i++) {
			if(fabs(arr[i])>max) {
				max=fabs(arr[i]);
			}
		}
		for (int i=0; i<maxi*maxj*maxk*maxl; i++) {
			arr[i]=arr[i]/max;
		}
	}

	double getnorm() { //Inf norm
		double max=arr[0];
		for (int i=1; i<maxi*maxj*maxk*maxl; i++) {
			if(fabs(arr[i])>max) {
				max=fabs(arr[i]);
			}
		}
		return max;
	}

	void norm2() {
		LaVectorDouble temp;
		double norm;
		for (int i=0; i<maxi*maxj*maxk*maxl; i++) {
			temp(i)=arr[i];
		}
		norm = Blas_Norm2(temp);
		for (int i=0; i<maxi*maxj*maxk*maxl; i++) {
			arr[i]=arr[i]/norm;
		}
	}

	double& operator()(int i) {
		return arr[i];
	}

	double& operator()(int i, int j) {
		return arr[i*maxj+j];
	}

	double& operator()(int i, int j, int k) {
		return arr[i*maxj*maxk+j*maxk+k];
	}

	double& operator()(int i, int j, int k, int l) {
		return arr[i*maxj*maxk*maxl+j*maxk*maxl+k*maxl+l];
	}

	friend ostream& operator<<(ostream& os, Arr& a) {
		for (int j=0; j<a.maxi; j++) {
			for (int i=0; i<a.maxj; i++) {
				os << a.arr[a.maxj*j+i] << " ";
			}
			os << endl;
		}
		return os;
	}


};




#endif /* ARRAYS_H_ */
