/*
 * PGDLSQP.h
 *
 *  Created on: 4 Oct 2013
 *      Author: plog
 */

#ifndef PGDLSQP_H_
#define PGDLSQP_H_


#include "PGD.h"
#include <gmd.h>
#include <lavd.h>
#include <iostream>
#include "Polylib.h"
#include <math.h>
#include <laslv.h>
#include "blaspp.h"
#include <blas1pp.h>
#include "arrays.h"

using namespace std;
using namespace polylib;

double gam; // ={0,1} using div-grad or extended div-grad
double bb1, bb2; //Advection-Diffusion coefficients



//True Solutions (For Calculating Error):
double Plsqphisol(double x, double y) {
	return sin(PI*(ax-x)*(bx-x)*(ay-y)*(by-y));
	//return sin(PI*x*y);
	//return sin(PI*x)*sin(PI*y);
	//return sin(PI*x)*sin(PI*y)+(sin(PI*x)-1)*cos(PI*y);
	//return sin(PI*x)*sin(PI*y)+cos(PI*x)*cos(PI*y);
	//return  sin(PI*x)*sin(PI*y)+(1-x*x)*(1-y*y);
}

double Plsqusol(double x, double y) {
	return -PI*(2*x-ax-bx)*(ay-y)*(by-y)*cos(PI*(ax-x)*(bx-x)*(ay-y)*(by-y));
	//return -PI*cos(PI*x)*sin(PI*y);
	//return -PI*cos(PI*x)*(sin(PI*y)+cos(PI*y));
	//return -PI*cos(PI*x)*sin(PI*y)+PI*sin(PI*x)*cos(PI*y);
	//return -PI*cos(PI*x)*sin(PI*y)+2*x*(1-y*y);

}

double Plsqvsol(double x, double y) {
	//return -PI*(2*y-ay-by)*(ax-x)*(bx-x)*cos(PI*(ax-x)*(bx-x)*(ay-y)*(by-y));
	//return -PI*cos(PI*y)*sin(PI*x);
	return -PI*sin(PI*x)*cos(PI*y)+PI*(sin(PI*x)-1)*sin(PI*y);
}



void phiuvtrue(Arr& phi2, Arr& u2, Arr& v2) {
	for (int i=0; i<N+1; i++) {
		for (int j=0; j<N+1; j++) {
			for (int k=1; k<=Kx; k++) {
				for (int l=1; l<=Ky; l++) {
					phi2(i,j,k-1,l-1)=Plsqphisol(xx(k-1,i),yy(l-1,j));
					u2(i,j,k-1,l-1)=Plsqusol(xx(k-1,i),yy(l-1,j));
					v2(i,j,k-1,l-1)=Plsqvsol(xx(k-1,i),yy(l-1,j));

				}
			}
		}
	}
}


// Right hand side functions:
double Plsqfct(double x, double y) {
	double f1 = pow(PI,2)*(pow((2*y-ay-by)*(ax-x)*(bx-x),2)+pow((2*x-ax-bx)*(ay-y)*(by-y),2))*sin(PI*(ax-x)*(bx-x)*(ay-y)*(by-y));
	double f2 = 2*PI*((ay-y)*(by-y)+(ax-x)*(bx-x))*cos(PI*(ax-x)*(bx-x)*(ay-y)*(by-y));
	double f3 = bb1*PI*(2*x-ax-bx)*(ay-y)*(by-y)*cos(PI*(ax-x)*(bx-x)*(ay-y)*(by-y));
	double f4 = bb2*PI*(2*y-ay-by)*(ax-x)*(bx-x)*cos(PI*(ax-x)*(bx-x)*(ay-y)*(by-y));
	//return 2*PI*PI*sin(PI*x)*sin(PI*y)+bb1*PI*cos(PI*x)*sin(PI*y)+bb2*PI*sin(PI*x)*cos(PI*y);
	return f1-f2+f3+f4;
	//return PI*PI*(x*x+y*y)*sin(PI*x*y);
	//return 2*PI*PI*sin(PI*x)*sin(PI*y);
	//return 2*PI*PI*sin(PI*x)*sin(PI*y)+PI*PI*(2*sin(PI*x)-1)*cos(PI*y);
	//return 2*PI*PI*sin(PI*x)*sin(PI*y)+2*PI*PI*cos(PI*x)*cos(PI*y);
	//return  2*PI*PI*sin(PI*x)*sin(PI*y)+2*(2-x*x-y*y);

}

//---------------------------


// Boundary conditions
double PlsqbcN(double x) {
	//return 1-sin(PI*x);
	return 0;
	//return -cos(PI*x);
}

double PlsqbcE(double x) {
	//return -cos(PI*x);
	return 0;
}

double PlsqbcS(double x) {
	//return 1-sin(PI*x);
	return 0;
	//return -cos(PI*x);
}

double PlsqbcW(double x) {
	//return -cos(PI*x);
	return 0;
}

// X Boundary conditions
double XuPlsqbcN(double x) {
	//return PI*cos(PI*x);
	//return -PI*sin(PI*x);
	return 0;
}

double XuPlsqbcE(double x) {//Dummy bc
	return 0;
}

double XuPlsqbcS(double x) {
	//return PI*cos(PI*x);
	//return -PI*sin(PI*x);
	return 0;
}

double XuPlsqbcW(double x) {//Dummy bc
	return 0;
}

double XvPlsqbcN(double x) {//Dummy bc
	return 0;
}

double XvPlsqbcE(double x) {
	//return -PI*sin(PI*x);
	return 0;
}

double XvPlsqbcS(double x) {//Dummy bc
	return 0;
}

double XvPlsqbcW(double x) {
	//return -PI*sin(PI*x);
	return 0;
}

//------------------------------------


void Plsqsolve(Arr& A, Arr& B, Arr& C, Arr& E, Arr& F, Arr& G, Arr& rphi, Arr& ru, Arr& rv, Arr& f1, Arr& f2, Arr& f3) {

	int K = f1.size();

	LaGenMatDouble whole(3*K-2,3*K-2);

	LaVectorDouble f123(3*K-2), phiuv(3*K-2);

	whole = 0;
	f123 = 0;
	phiuv = 0;

	for (int i=0; i<K-2; i++) {
		f123(i) = f1(i+1);
		for (int j=0; j<K-2; j++) {
			whole(i,j) = A(i+1,j+1);
		}
		for (int j=0; j<K; j++) {
			whole(i,j+K-2) = B(i+1,j);
			whole(i,j+2*K-2) = C(i+1,j);
		}
	}

	for (int i=0; i<K; i++) {
		f123(i+(K-2)) = f2(i);
		f123(i+2*K-2) = f3(i);
		for (int j=0; j<K; j++) {
			whole(i+(K-2),j+(K-2)) = E(i,j);
			whole(i+(K-2),j+2*K-2) = F(i,j);
			whole(i+2*K-2,j+(K-2)) = F(j,i);
			whole(i+2*K-2,j+2*K-2) = G(i,j);
		}
		for (int j=0; j<K-2; j++) {
			whole(i+(K-2),j) = B(j+1,i);
			whole(i+2*K-2,j) = C(j+1,i);
		}
	}

	//cout << F << endl;

	//minres(whole,uvwp,f1234);

	//cout << whole << endl;

	//abort();

	LaLinearSolve(whole,phiuv,f123);


	for (int i=0; i<K-2; i++) {
		rphi(i+1) = phiuv(i);
	}

	for (int i=0; i<K; i++) {
		ru(i) = phiuv(i+(K-2));
		rv(i) = phiuv(i+2*K-2);
	}


}

void Plsqsolve4(Arr& A, Arr& B, Arr& C, Arr& E, Arr& F, Arr& G, Arr& rphi, Arr& ru, Arr& rv, Arr& f1, Arr& f2, Arr& f3) {

	int K = f1.size();

	LaGenMatDouble whole(3*K-4,3*K-4);

	LaVectorDouble f123(3*K-4), phiuv(3*K-4);

	whole = 0;
	f123 = 0;
	phiuv = 0;

	if(xory) {
		for (int i=0; i<K-2; i++) {
			f123(i) = f1(i+1);
			f123(i+K-2) = f2(i+1);
			for (int j=0; j<K-2; j++) {
				whole(i,j) = A(i+1,j+1);
				whole(i,j+K-2) = B(i+1,j+1);
				whole(i+K-2,j) = B(j+1,i+1);
				whole(i+K-2,j+K-2) = E(i+1,j+1);
			}
			for (int j=0; j<K; j++) {
				whole(i,j+2*K-4) = C(i+1,j);
				whole(i+K-2,j+2*K-4) = F(i+1,j);

				whole(j+2*K-4,i) = C(i+1,j);
				whole(j+2*K-4,i+K-2) = F(i+1,j);
			}
		}

		for (int i=0; i<K; i++) {
			f123(i+2*K-4) = f3(i);
			for (int j=0; j<K; j++) {
				whole(i+2*K-4,j+2*K-4) = G(i,j);
			}
		}
	}

	else {
		for (int i=0; i<K-2; i++) {
			f123(i) = f1(i+1);
			f123(i+2*K-2) = f3(i+1);
			for (int j=0; j<K-2; j++) {
				whole(i,j) = A(i+1,j+1);
				whole(i,j+2*K-2) = C(i+1,j+1);
				whole(i+2*K-2,j) = C(j+1,i+1);
				whole(i+2*K-2,j+2*K-2) = G(i+1,j+1);
			}
			for (int j=0; j<K; j++) {
				whole(i,j+K-2) = B(i+1,j);
				whole(i+2*K-2,j+K-2) = F(j,i+1);

				whole(j+K-2,i) = B(i+1,j);
				whole(j+K-2,i+2*K-2) = F(j,i+1);
			}
		}

		for (int i=0; i<K; i++) {
			f123(i+K-2) = f2(i);
			for (int j=0; j<K; j++) {
				whole(i+K-2,j+K-2) = E(i,j);
			}
		}
	}


	LaLinearSolve(whole,phiuv,f123);

	if(xory) {
		for (int i=0; i<K-2; i++) {
			rphi(i+1) = phiuv(i);
			ru(i+1) = phiuv(i+K-2);
		}

		for (int i=0; i<K; i++) {
			rv(i) = phiuv(i+2*K-4);
		}
	}

	else {
		for (int i=0; i<K-2; i++) {
			rphi(i+1) = phiuv(i);
			rv(i+1) = phiuv(i+2*K-2);
		}

		for (int i=0; i<K; i++) {
			ru(i) = phiuv(i+K-2);
		}
	}


}




//Generates tensors for least-squares Stokes PGD
void Plsqtensors(Arr& A, Arr& B, Arr& C, Arr& E, Arr& F, Arr& G) {


	Arr Axx(N+1,N+1,N+1,N+1);
	Arr Axy(N+1,N+1,N+1,N+1);
	Arr Ayx(N+1,N+1,N+1,N+1);
	Arr Ayy(N+1,N+1,N+1,N+1);
	Arr Bx(N+1,N+1,N+1,N+1);
	Arr By(N+1,N+1,N+1,N+1);
	Arr Cc(N+1,N+1,N+1,N+1);


	Arr S1(N+1,N+1);
	Arr kron(N+1,N+1);

	for (int i=0; i<N+1; i++) {
		kron(i,i)=1; //Kronecker Delta
	}

	for (int i=0; i<N+1; i++) {
		for (int j=0; j<N+1; j++) {
			for (int k=0; k<N+1; k++) {
				S1(i,j) += w(k)*D(k,i)*D(k,j);
			}
		}
	}

	for(int i=0; i<N+1; i++) {
		for(int n=0; n<N+1; n++) {
			for(int m=0; m<N+1; m++) {
				for(int l=0; l<N+1; l++) {
					Axx(i,n,m,l) = (dy/dx)*w(n)*kron(n,l)*S1(i,m);
					Axy(i,n,m,l) = w(m)*w(n)*D(m,i)*D(n,l);
					Ayx(i,n,m,l) = w(i)*w(l)*D(i,m)*D(l,n);
					Ayy(i,n,m,l) = (dx/dy)*w(i)*kron(i,m)*S1(n,l);
					Bx(i,n,m,l) = (dy/2)*w(i)*w(n)*D(i,m)*kron(n,l);
					By(i,n,m,l) = (dx/2)*w(i)*w(n)*D(n,l)*kron(i,m);
					Cc(i,n,m,l) = (dx*dy/4)*w(i)*w(n)*kron(i,m)*kron(n,l);

					A(i,n,m,l) = (hh*hh*bb1*bb1+1)*Axx(i,n,m,l)+(hh*hh*bb2*bb2+1)*Ayy(i,n,m,l)+hh*hh*bb1*bb2*(Axy(i,n,m,l)+Ayx(i,n,m,l));
					B(i,n,m,l) = Bx(i,n,m,l)+hh*hh*bb1*Axx(i,n,m,l)+hh*hh*bb2*Axy(i,n,m,l);
					C(i,n,m,l) = By(i,n,m,l)+hh*hh*bb1*Ayx(i,n,m,l)+hh*hh*bb2*Ayy(i,n,m,l);
					E(i,n,m,l) = hh*hh*Axx(i,n,m,l)+gam*Ayy(i,n,m,l)+Cc(i,n,m,l);
					F(i,n,m,l) = hh*hh*Ayx(i,n,m,l)-gam*Axy(i,n,m,l);
					G(i,n,m,l) = gam*Axx(i,n,m,l)+hh*hh*Ayy(i,n,m,l)+Cc(i,n,m,l);


				}
			}
		}
	}
}




void PlsqRHS(Arr& g1, Arr& g2, Arr& g3) {

	Arr RHS(N+1,N+1,Kx,Ky);

	g1=0;
	g2=0;
	g3=0;
	for (int i=0; i<N+1; i++) {
		for (int n=0; n<N+1; n++) {
			for (int k=1; k<=Kx; k++) {
				for (int l=1; l<=Ky; l++) {
					RHS(i,n,k-1,l-1) = Plsqfct(xx(k-1,i),yy(l-1,n));
				}
			}
		}
	}

	for (int i=0; i<N+1; i++) {
		for (int n=0; n<N+1; n++) {
			for (int k=1; k<=Kx; k++) {
				for (int l=1; l<=Ky; l++) {
					for(int p=0; p<N+1; p++) {
						g1(i,n,k-1,l-1) += bb1*(dy/2)*w(n)*w(p)*D(p,i)*RHS(p,n,k-1,l-1)+bb2*(dx/2)*w(i)*w(p)*D(p,n)*RHS(i,p,k-1,l-1);
						g2(i,n,k-1,l-1) += (dy/2)*w(n)*w(p)*D(p,i)*RHS(p,n,k-1,l-1);
						g3(i,n,k-1,l-1) += (dx/2)*w(i)*w(p)*D(p,n)*RHS(i,p,k-1,l-1);
					}
				}
			}
		}

	}


}








#endif /* PGDLSQP_H_ */
