 #!/bin/bash

for i in {4..20}
do
	./Algebra 2 3 4 $i
done

echo DONE.
