 #!/bin/bash

	./Algebra 1 2 25 8 3 3
	./Algebra 4 1 25 8 3 3
	./Algebra 4 2 25 8 3 3
	./Algebra 4 3 25 8 3 3


echo DONE.
