 #!/bin/bash

for i in {4..30}
do
	./Algebra 2 3 1 $i 4 10
done

echo DONE.
