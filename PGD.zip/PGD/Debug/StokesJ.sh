 #!/bin/bash

for i in {1..25}
do
	./Algebra 2 2 $i 15 1 1
done

echo DONE.
