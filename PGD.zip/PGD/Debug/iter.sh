 #!/bin/bash

for i in {5,10,15,20,25,30}
do
	./Algebra 3 1 i 4 8 8

done

echo DONE.
