 #!/bin/bash

for i in {1,3}
do
	for n in {4,8,12,16}
	do
		./Algebra 3 5 25 $n $i $i
		cp XPGDerrJu.txt XPGDu$i-$n.txt
		cp XPGDerrJp.txt XPGDp$i-$n.txt
	done
done



echo DONE.
