 #!/bin/bash


	./Algebra 3 3 25 8 3 3
	./Algebra 3 4 25 8 3 3
	./Algebra 3 5 25 8 3 3



echo DONE.
