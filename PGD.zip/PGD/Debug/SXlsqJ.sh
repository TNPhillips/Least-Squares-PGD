 #!/bin/bash

for i in {1..25}
do
	./Algebra 3 3 $i 8 3 3	
	./Algebra 3 4 $i 8 3 3
	./Algebra 3 5 $i 8 3 3
done

echo DONE.
