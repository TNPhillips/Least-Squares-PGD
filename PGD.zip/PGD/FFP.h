/*
 * FFP.h
 *
 *  Created on: 30 Mar 2015
 *      Author: plog
 */

#ifndef FFP_H_
#define FFP_H_

#include "PGD.h"
#include <gmd.h>
#include <lavd.h>
#include <iostream>
#include "Polylib.h"
#include <math.h>
#include <laslv.h>
#include "blaspp.h"
#include <blas1pp.h>
#include "arrays.h"

using namespace std;
using namespace polylib;

double beta=1;
double KK=1;
double Rey=1;

void navsto(Arr& u, Arr& uold, Arr& tau) {
	Arr A(N+1,N+1), Ay(N*Ky+1,N*Ky+1);
	Arr f(N+1), fy(N*Ky+1);
	Arr usol(N*Ky+1);

	for (int k=1; k<=Ky; k++) {
		A=0;
		f=0;
		for (int i=0; i<N+1; i++) {
			A(i,i) += (1.0/delt)*w(i)*(dy/2);
			for (int n=0; n<N+1; n++) {
				for (int p=0; p<N+1; p++) {
					A(i,n) += (beta/Rey)*(2/dy)*w(p)*D(p,i)*D(p,n);
				}
			}
		}

		for (int i=0; i<N+1; i++) {
			f(i) += (KK+uold(k-1,i))*w(i)*(dy/2)*(1.0/delt);
			for (int n=0; n<N+1; n++) {
				f(i) += (1.0/Rey)*w(i)*tau(k-1,n)*D(i,n);
			}
		}

		for(int i=0; i<N+1; i++) {
			fy(N*(k-1)+i) += f(i); //Global RHS for m=0
			for(int j=0; j<N+1; j++) {
				Ay(N*(k-1)+i,N*(k-1)+j) += A(i,j); //Global matrix for m=0
			}
		}

		usol=0;
		trimsolve(Ay,usol,fy);

		for (int ky=1; ky<=Ky; ky++) {
			for(int i=0; i<N+1; i++) {
				u(i,ky-1)=usol(N*(ky-1)+i);
			}
		}

	}

}

void kramers(Arr& tau, Arr& Q, Arr& Y) {
	for(int iy=0; iy<N+1; iy++) {
		for (int ky=1; ky<=Ky; ky++) {
			for (int j=0; j<J; j++) {
				for (int ix=0; ix<N+1; ix++) {
					for (int kx=1; kx<=Kx; kx++) {
						tau(ky-1,iy) += (PI/(4.0*sqrt(mmnorm)))*(dx/2)*pow(xx(kx-1,ix),3)*(1-pow((xx(kx-1,ix)*xx(kx-1,ix)/4*mm),mm-1))*Q(j,ix,kx-1,M+1)*Y(j,iy,ky-1);
					}
				}
			}
			tau(ky-1,iy) = ((1-beta)/We)*(1+(3/4*mm))*(tau(ky-1,iy)); //CHECK DELTA IN KRAMERS, CHECK 3
		}
	}

}

double ffperror(Arr& r, Arr& s, Arr& r2, Arr& s2) {
	double E=0;

	double Ey1=0;
	double Ey2=0;
	double Ey3=0;

	double Ex1=0;
	double Ex2=0;
	double Ex3=0;

	//cout << r << endl;
	//cout << s << endl;
	//cout << r2 << endl;
	//cout << s2 << endl;

	for (int ky=1; ky<=Ky; ky++) {
		for (int i=0; i<N+1; i++) {
			Ey1 += w(i)*(dy/2)*s(i,ky-1)*s(i,ky-1);
			Ey2 += w(i)*(dy/2)*s(i,ky-1)*s2(i,ky-1);
			Ey3 += w(i)*(dy/2)*s2(i,ky-1)*s2(i,ky-1);
		}
	}

	for (int kx=1; kx<=Kx; kx++) {
		for (int i=0; i<N+1; i++) {
			Ex1 += PI*w(i)*(dx/2)*xx(kx-1,i)*r(i,kx-1,0)*r(i,kx-1,0);
			Ex2 += PI*w(i)*(dx/2)*xx(kx-1,i)*r(i,kx-1,0)*r2(i,kx-1,0);
			Ex3 += PI*w(i)*(dx/2)*xx(kx-1,i)*r2(i,kx-1,0)*r2(i,kx-1,0);
			for (int m=1; m<2*M+1; m++) {
				Ex1 += (PI/2)*w(i)*(dx/2)*xx(kx-1,i)*r(i,kx-1,m)*r(i,kx-1,m);
				Ex2 += (PI/2)*w(i)*(dx/2)*xx(kx-1,i)*r(i,kx-1,m)*r2(i,kx-1,m);
				Ex3 += (PI/2)*w(i)*(dx/2)*xx(kx-1,i)*r2(i,kx-1,m)*r2(i,kx-1,m);
			}
		}
	}

	E=Ey1*Ex1-2*Ey2*Ex2+Ex3*Ey3;
	//cout << E << endl;
	return sqrt(abs(E));
}



#endif /* FFP_H_ */
