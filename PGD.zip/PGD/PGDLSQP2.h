/*
 * PGDLSQP2.h
 *
 *  Created on: 8 Oct 2013
 *      Author: plog
 */

#ifndef PGDLSQP2_H_
#define PGDLSQP2_H_

#include "PGDLSQP.h"
#include "blaspp.h"
#include "laslv.h"
#include <blas1pp.h>
#include <stdio.h>
#include "arrays.h"

void PGDLSQPoisson(Arr& Xphi, Arr& Yphi, Arr& Xu, Arr& Yu, Arr& Xv, Arr& Yv) {


	double tol = 1e-8;

	clock_t time, time2;

	time = clock();

	double Ephi, Eu, Ev; //Errors

	dx = (bx-ax)/(double)Kx;
	dy = (by-ay)/(double)Ky; //Size of elements (fixed length)

	D.resize(N+1,N+1);
	z.resize(N+1);
	w.resize(N+1);

	xx.resize(Kx,N+1);
	yy.resize(Ky,N+1);

	{
		Arr Leg(N+1);

		DzwL(D,z,w,Leg);

	}


	//Generating physical points in x and y (and boundary conditions for phi) :
	{

		Arr phiN(Kx,N+1), phiE(Ky,N+1), phiS(Kx,N+1), phiW(Ky,N+1);

		for (int i=0; i<N+1; i++) {
			for (int j=1; j<=Kx; j++) {
				xx(j-1,i)=ax+(j-1)*dx+((z(i)+1)*dx)/2;
				phiN(j-1,i)=PlsqbcN(xx(j-1,i));
				phiS(j-1,i)=PlsqbcS(xx(j-1,i));
			}
		}

		for (int i=0; i<N+1; i++) {
			for (int j=1; j<=Ky; j++) {
				yy(j-1,i)=ay+(j-1)*dy+((z(i)+1)*dy)/2;
				phiE(j-1,i)=PlsqbcE(yy(j-1,i));
				phiW(j-1,i)=PlsqbcW(yy(j-1,i));
			}
		}
		if (ishh) {
			if (Kx>Ky) {
				hh = xx(0,1)-xx(0,0);
			}
			else {
				hh = yy(0,1)-yy(0,0);
			}
		}
		else {
			hh = 1;
		}

		if (gam==1) {
			Arr uN(Kx,N+1), uS(Kx,N+1), uE(Ky,N+1), uW(Ky,N+1);
			Arr vE(Ky,N+1), vW(Ky,N+1), vN(Kx,N+1), vS(Kx,N+1);

			for (int i=0; i<N+1; i++) {
				for (int j=1; j<=Kx; j++) {
					uN(j-1,i)=XuPlsqbcN(xx(j-1,i));
					uS(j-1,i)=XuPlsqbcS(xx(j-1,i));
					vN(j-1,i)=XvPlsqbcN(xx(j-1,i));
					vS(j-1,i)=XuPlsqbcS(xx(j-1,i));
				}
			}

			for (int i=0; i<N+1; i++) {
				for (int j=1; j<=Ky; j++) {
					vE(j-1,i)=XvPlsqbcE(yy(j-1,i));
					vW(j-1,i)=XvPlsqbcW(yy(j-1,i));
					uE(j-1,i)=XuPlsqbcE(yy(j-1,i));
					uW(j-1,i)=XuPlsqbcW(yy(j-1,i));
				}
			}

			transint(Xu,Yu,uN,uE,uS,uW);
			transint(Xv,Yv,vN,vE,vS,vW);

		}


		LaGenMatDouble Khx(N*Kx+1,N*Kx+1);
		LaGenMatDouble Khy(N*Ky+1,N*Ky+1);
		Khx=0;
		Khy=0;

		for (int i=0; i<N*Kx+1; i++) {
		}





		transint(Xphi,Yphi,phiN,phiE,phiS,phiW); //Transfinite Interpolation (sets basis functions for Dim=0,...,3.)

	}

	Arr ru(N+1,Kx), ru2(N+1,Kx), su(N+1,Ky), su2(N+1,Ky);
	Arr rv(N+1,Kx), rv2(N+1,Kx), sv(N+1,Ky), sv2(N+1,Ky);
	Arr rphi(N+1,Kx), rphi2(N+1,Kx), sphi(N+1,Ky), sphi2(N+1,Ky);

	Arr Xuk(J,N+1), Yuk(J,N+1);
	Arr Xvk(J,N+1), Yvk(J,N+1);
	Arr Xphik(J,N+1), Yphik(J,N+1);


	Arr rsuk(N+1), rsvk(N+1), rsphik(N+1);

	Arr A(N+1,N+1), B(N+1,N+1), C(N+1,N+1), E(N+1,N+1), F(N+1,N+1), G(N+1,N+1);

	Arr a1(N+1), a2(N+1), a3(N+1);
	Arr b1(N+1), b2(N+1), b3(N+1);
	Arr c1(N+1), c2(N+1), c3(N+1);

	Arr f1(N+1), f2(N+1), f3(N+1);

	Arr fx1(N*Kx+1), fx2(N*Kx+1), fx3(N*Kx+1);
	Arr fy1(N*Ky+1), fy2(N*Ky+1), fy3(N*Ky+1);

	Arr Ax(N*Kx+1,N*Kx+1), Bx(N*Kx+1,N*Kx+1), Cx(N*Kx+1,N*Kx+1), Ex(N*Kx+1,N*Kx+1), Fx(N*Kx+1,N*Kx+1), Gx(N*Kx+1,N*Kx+1);
	Arr Ay(N*Ky+1,N*Ky+1), By(N*Ky+1,N*Ky+1), Cy(N*Ky+1,N*Ky+1), Ey(N*Ky+1,N*Ky+1), Fy(N*Ky+1,N*Ky+1), Gy(N*Ky+1,N*Ky+1);

	Arr rusol(N*Kx+1), rvsol(N*Kx+1), rphisol(N*Kx+1);
	Arr susol(N*Ky+1), svsol(N*Ky+1), sphisol(N*Ky+1);

	Arr tenA(N+1,N+1,N+1,N+1), tenB(N+1,N+1,N+1,N+1), tenC(N+1,N+1,N+1,N+1);
	Arr tenE(N+1,N+1,N+1,N+1), tenF(N+1,N+1,N+1,N+1), tenG(N+1,N+1,N+1,N+1);

	Arr g1(N+1,N+1,Kx,Ky), g2(N+1,N+1,Kx,Ky), g3(N+1,N+1,Kx,Ky);




	//Populating tensors:
	Plsqtensors(tenA, tenB, tenC, tenE, tenF, tenG);
	PlsqRHS(g1,g2,g3);





	//Main code starts here-------------------

	for (Dim=4; Dim<J; Dim++) {

		ru=1; //Initial 'guess'
		rv=1;
		rphi=1;


		ru2=1; //Just so the convergence criterion makes sense on first iteration
		su2=1;
		rv2=1;
		sv2=1;
		rphi2=1;
		sphi2=1;

		rphi(0,0)=0; // Homogenous b.c.s
		rphi(N,Kx-1)=0;

		if (gam==1) { //nxu bc
			rv(0,0)=0;
			rv(N,Kx-1)=0;
			su(0,0)=0;
			su(N,Ky-1)=0;
		}

		while(true) { // ADFPA iteration

			xory=1;

			for (int ky=1; ky<=Ky; ky++) {
				for(int kx=1; kx<=Kx; kx++) {


					for(int i=0; i<N+1; i++) {
						rsuk(i)=ru(i,kx-1);
						rsvk(i)=rv(i,kx-1);
						rsphik(i)=rphi(i,kx-1);
						for(int j=0; j<Dim; j++) {
							Xuk(j,i)=Xu(j,i,kx-1);
							Yuk(j,i)=Yu(j,i,ky-1);
							Xvk(j,i)=Xv(j,i,kx-1);
							Yvk(j,i)=Yv(j,i,ky-1);
							Xphik(j,i)=Xphi(j,i,kx-1);
							Yphik(j,i)=Yphi(j,i,ky-1);
						}
					}


					setr(tenA,rsphik,Xphik,Yphik,A,a1);
					setr(tenB,rsphik,rsuk,Xuk,Yuk,B,a2);
					setr(tenC,rsphik,rsvk,Xvk,Yvk,C,a3);

					setvecr(tenB,rsuk,Xphik,Yphik,b1);
					setr(tenE,rsuk,Xuk,Yuk,E,b2);
					setr(tenF,rsuk,rsvk,Xvk,Yvk,F,b3);

					setvecr(tenC,rsvk,Xphik,Yphik,c1);
					setvecr(tenF,rsvk,Xuk,Yuk,c2);
					setr(tenG,rsvk,Xvk,Yvk,G,c3);


					f1=0;
					f2=0;
					f3=0;
					//Contribution from RHS:
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							f1(n) += rsphik(i)*g1(i,n,kx-1,ky-1);
							f2(n) += rsuk(i)*g2(i,n,kx-1,ky-1);
							f3(n) += rsvk(i)*g3(i,n,kx-1,ky-1);
						}
					}


					//Constructing global system:
					for(int i=0; i<N+1; i++) {
						fy1(N*(ky-1)+i) += hh*hh*f1(i)-a1(i)-a2(i)-a3(i);
						fy2(N*(ky-1)+i) += hh*hh*f2(i)-b1(i)-b2(i)-b3(i);
						fy3(N*(ky-1)+i) += hh*hh*f3(i)-c1(i)-c2(i)-c3(i);


						for(int j=0; j<N+1; j++) {
							Ay(N*(ky-1)+i,N*(ky-1)+j) += A(i,j);
							By(N*(ky-1)+i,N*(ky-1)+j) += B(i,j);
							Cy(N*(ky-1)+i,N*(ky-1)+j) += C(i,j);
							Ey(N*(ky-1)+i,N*(ky-1)+j) += E(i,j);
							Fy(N*(ky-1)+i,N*(ky-1)+j) += F(i,j);
							Gy(N*(ky-1)+i,N*(ky-1)+j) += G(i,j);

						}
					}

				}
			}




			if (gam==1) {
				Plsqsolve4(Ay,By,Cy,Ey,Fy,Gy,sphisol,susol,svsol,fy1,fy2,fy3);
			}
			else {
				Plsqsolve(Ay,By,Cy,Ey,Fy,Gy,sphisol,susol,svsol,fy1,fy2,fy3);
			}



			susol.norm();
			svsol.norm();
			sphisol.norm();


			for(int i=0; i<N+1; i++) {
				for(int k=1; k<=Ky; k++) {
					su(i,k-1)=susol(N*(k-1)+i); //Writing su, sv, sw, sp to more easily readable array
					sv(i,k-1)=svsol(N*(k-1)+i);
					sphi(i,k-1)=sphisol(N*(k-1)+i);
				}
			}

			Ay=0;
			By=0;
			Cy=0;
			Ey=0;
			Fy=0;
			Gy=0;
			fy1=0;
			fy2=0;
			fy3=0;

			//Checking convergence :
			Eu=error(ru,su,ru2,su2);
			Ev=error(rv,sv,rv2,sv2);
			Ephi=error(rphi,sphi,rphi2,sphi2);

			if ((Eu < tol) && (Ev < tol) && (Ephi < tol)) {
				break;
			}
			ru2=ru;
			rv2=rv;
			rphi2=rphi;


			//Second part of ADFPA:

			xory=0;

			for (int ky=1; ky<=Ky; ky++) {
				for(int kx=1; kx<=Kx; kx++) {


					for(int i=0; i<N+1; i++) {
						rsuk(i)=su(i,ky-1);
						rsvk(i)=sv(i,ky-1);
						rsphik(i)=sphi(i,ky-1);
						for(int j=0; j<Dim; j++) {
							Xuk(j,i)=Xu(j,i,kx-1);
							Yuk(j,i)=Yu(j,i,ky-1);
							Xvk(j,i)=Xv(j,i,kx-1);
							Yvk(j,i)=Yv(j,i,ky-1);
							Xphik(j,i)=Xphi(j,i,kx-1);
							Yphik(j,i)=Yphi(j,i,ky-1);
						}
					}

					sets(tenA,rsphik,Xphik,Yphik,A,a1);
					sets(tenB,rsphik,rsuk,Xuk,Yuk,B,a2);
					sets(tenC,rsphik,rsvk,Xvk,Yvk,C,a3);

					setvecs(tenB,rsuk,Xphik,Yphik,b1);
					sets(tenE,rsuk,Xuk,Yuk,E,b2);
					sets(tenF,rsuk,rsvk,Xvk,Yvk,F,b3);

					setvecs(tenC,rsvk,Xphik,Yphik,c1);
					setvecs(tenF,rsvk,Xuk,Yuk,c2);
					sets(tenG,rsvk,Xvk,Yvk,G,c3);


					f1=0;
					f2=0;
					f3=0;
					//Contribution from RHS:
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							f1(i) += rsphik(n)*g1(i,n,kx-1,ky-1);
							f2(i) += rsuk(n)*g2(i,n,kx-1,ky-1);
							f3(i) += rsvk(n)*g3(i,n,kx-1,ky-1);
						}
					}


					//Constructing global system:
					for(int i=0; i<N+1; i++) {
						fx1(N*(kx-1)+i) += hh*hh*f1(i)-a1(i)-a2(i)-a3(i);
						fx2(N*(kx-1)+i) += hh*hh*f2(i)-b1(i)-b2(i)-b3(i);
						fx3(N*(kx-1)+i) += hh*hh*f3(i)-c1(i)-c2(i)-c3(i);
						for(int j=0; j<N+1; j++) {
							Ax(N*(kx-1)+i,N*(kx-1)+j) += A(i,j);
							Bx(N*(kx-1)+i,N*(kx-1)+j) += B(i,j);
							Cx(N*(kx-1)+i,N*(kx-1)+j) += C(i,j);
							Ex(N*(kx-1)+i,N*(kx-1)+j) += E(i,j);
							Fx(N*(kx-1)+i,N*(kx-1)+j) += F(i,j);
							Gx(N*(kx-1)+i,N*(kx-1)+j) += G(i,j);
						}
					}

				}
			}




			if (gam==1) {
				Plsqsolve4(Ax,Bx,Cx,Ex,Fx,Gx,rphisol,rusol,rvsol,fx1,fx2,fx3);
			}
			else {
				Plsqsolve(Ax,Bx,Cx,Ex,Fx,Gx,rphisol,rusol,rvsol,fx1,fx2,fx3);
			}






			for(int i=0; i<N+1; i++) {
				for(int k=1; k<=Kx; k++) {
					ru(i,k-1)=rusol(N*(k-1)+i); //Writing su, sv, sw, sp to more easily readable array
					rv(i,k-1)=rvsol(N*(k-1)+i);
					rphi(i,k-1)=rphisol(N*(k-1)+i);
				}
			}

			Ax=0;
			Bx=0;
			Cx=0;
			Ex=0;
			Fx=0;
			Gx=0;
			fx1=0;
			fx2=0;
			fx3=0;

			//Checking convergence :
			Eu=error(ru,su,ru2,su2);
			Ev=error(rv,sv,rv2,sv2);
			Ephi=error(rphi,sphi,rphi2,sphi2);

			if ((Eu < tol) && (Ev < tol) && (Ephi < tol)) {
				break;
			}

			cout << Eu << " " << Ev << " " << Ephi << endl;


			su2=su;
			sv2=sv;
			sphi2=sphi;

		}//End of while loop

		// Fixing the converged values of r,s:



		for(int k=1; k<=Kx; k++) {
			for (int i=0; i<N+1; i++) {
				Xu(Dim,i,k-1)=ru(i,k-1);
				Xv(Dim,i,k-1)=rv(i,k-1);
				Xphi(Dim,i,k-1)=rphi(i,k-1);
			}
		}

		for(int k=1; k<=Ky; k++) {
			for (int i=0; i<N+1; i++) {
				Yu(Dim,i,k-1)=su(i,k-1);
				Yv(Dim,i,k-1)=sv(i,k-1);
				Yphi(Dim,i,k-1)=sphi(i,k-1);
			}
		}

		time2 = clock()-time;

		fprintf(CPUtime,"%15.16d %15.16e\n", Dim-3, ((float)time2)/CLOCKS_PER_SEC);

	}

	return;

}




#endif /* PGDLSQP2_H_ */
