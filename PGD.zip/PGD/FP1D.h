/*
 * FP1D.h
 *
 *  Created on: 19 Jun 2014
 *      Author: plog
 */

#ifndef FP1D_H_
#define FP1D_H_


#endif /* FP1D_H_ */

#include "PGD.h"
#include <gmd.h>
#include <lavd.h>
#include <iostream>
#include "Polylib.h"
#include <math.h>
#include <laslv.h>
#include "blaspp.h"
#include <blas1pp.h>
#include "arrays.h"

using namespace std;
using namespace polylib;

const double mmnorm = ((512.0*sqrt(10))/693.0); //(262144.0/109395.0);     //(68719476736.0/27981667175.0);
const double mm = 10.0/4.0; //b=4m where sqrt(b) is max extension
const double We = 1;//sqrt(2)/4.0; //Weissenberg number
const double delt = 1e-1; //Time step
double alp; //SU Stabilisation parameter
int noT; //Number of timesteps
bool timestep1 = true;

bool unst, semimp, lsqnorm, cov, suli;

Arr mx, my, mxi, myi;


double sqrtmax(double x) {
	return pow((1-(x*x)/(4*mm)),mm);
}


void fptensor2(Arr& A, int kx, int ky, double kap) {

	Arr euler(N+1,N+1,N+1,N+1), A1(N+1,N+1,N+1,N+1), A2(N+1,N+1,N+1,N+1), A3(N+1,N+1,N+1,N+1), B1(N+1,N+1,N+1,N+1), B2(N+1,N+1,N+1,N+1);
	Arr SU1(N+1,N+1,N+1,N+1), SU2(N+1,N+1,N+1,N+1), SU3(N+1,N+1,N+1,N+1);
	Arr S1(N+1,N+1), S2(N+1,N+1), S3(N+1,N+1), S4(N+1,N+1), S5(N+1,N+1);
	Arr kron(N+1,N+1);

	for (int i=0; i<N+1; i++) {
		kron(i,i)=1; //Kronecker Delta
	}

	for (int i=0; i<N+1; i++) {
		for (int j=0; j<N+1; j++) {
			for (int k=0; k<N+1; k++) {
				S1(i,j) += mx(kx-1,k)*mx(kx-1,k)*w(k)*D(k,i)*D(k,j);
				S2(i,j) += my(ky-1,k)*my(ky-1,k)*w(k)*D(k,i)*D(k,j);
				S3(i,j) += w(k)*D(k,i)*D(k,j);
				S4(i,j) += mxi(kx-1,k)*mxi(kx-1,k)*w(k)*D(k,i)*D(k,j);
				S5(i,j) += myi(ky-1,k)*myi(ky-1,k)*w(k)*D(k,i)*D(k,j);
			}
		}
	}
	for(int i=0; i<N+1; i++) {
		for(int n=0; n<N+1; n++) {
			for(int m=0; m<N+1; m++) {
				for(int l=0; l<N+1; l++) {
					if (unst) {
						euler(i,n,m,l) = (1/delt)*(dx*dy/4)*w(i)*w(n)*kron(i,m)*kron(n,l);
					}
					A1(i,n,m,l) = (dy/dx)*(1.0/(2*We))*w(n)*kron(n,l)*mxi(kx-1,i)*mxi(kx-1,m)*S1(i,m);
					A2(i,n,m,l) = -(1.0/(4*We))*w(m)*mx(kx-1,m)*mxi(kx-1,i)*D(m,i)*w(n)*my(ky-1,n)*myi(ky-1,l)*D(n,l);
					A3(i,n,m,l) = (dx/dy)*(1.0/(2*We))*w(i)*kron(i,m)*myi(ky-1,n)*myi(ky-1,l)*S2(n,l);
					if (!semimp) {
						B1(i,n,m,l) = kap*(dy/2)*w(i)*xx(kx-1,i)*mx(kx-1,i)*mxi(kx-1,m)*D(i,m)*w(n)*kron(n,l);
						B2(i,n,m,l) = kap*(dx/2)*w(i)*kron(i,m)*w(n)*yy(ky-1,n)*my(ky-1,n)*myi(ky-1,l)*D(n,l);
						//SU1(i,n,m,l) = alp*(dy/dx)*S4(i,m)*xx(kx-1,i)*xx(kx-1,m)*mx(kx-1,i)*mx(kx-1,m)*w(n)*kron(n,l);
						//SU2(i,n,m,l) = alp*w(m)*mxi(kx-1,m)*xx(kx-1,i)*mx(kx-1,i)*D(m,i)*w(n)*myi(ky-1,n)*yy(ky-1,l)*my(ky-1,l)*D(n,l);
						//SU3(i,n,m,l) = alp*(dx/dy)*S5(n,l)*yy(ky-1,n)*my(ky-1,n)*yy(ky-1,l)*my(ky-1,l)*w(i)*kron(i,m);
					}
					SU1(i,n,m,l) = alp*(dy/dx)*S4(i,m)*xx(kx-1,i)*xx(kx-1,m)*mx(kx-1,i)*mx(kx-1,m)*w(n)*kron(n,l);
					SU2(i,n,m,l) = alp*w(m)*mxi(kx-1,m)*xx(kx-1,i)*mx(kx-1,i)*D(m,i)*w(n)*myi(ky-1,n)*yy(ky-1,l)*my(ky-1,l)*D(n,l);
					SU3(i,n,m,l) = alp*(dx/dy)*S5(n,l)*yy(ky-1,n)*my(ky-1,n)*yy(ky-1,l)*my(ky-1,l)*w(i)*kron(i,m);

				}
			}
		}
	}
	for(int i=0; i<N+1; i++) {
		for(int n=0; n<N+1; n++) {
			for(int m=0; m<N+1; m++) {
				for(int l=0; l<N+1; l++) {
					A(i,n,m,l) = euler(i,n,m,l) + A1(i,n,m,l) + A2(i,n,m,l) + A2(m,l,i,n) + A3(i,n,m,l) + SU1(i,n,m,l) + SU2(i,n,m,l) + SU2(m,l,i,n) + SU3(i,n,m,l) - B1(i,n,m,l) - B2(i,n,m,l);
				}
			}
		}
	}

}

void lltensor(Arr& ll, double kx, double ky, double kx2, double ky2) {

	for(int i=0; i<N+1; i++) {
		for(int n=0; n<N+1; n++) {
			for(int m=0; m<N+1; m++) {
				for(int l=0; l<N+1; l++) {
					ll(i,n,m,l) = ting*(dx*dx*dy*dy/16)*(1/mmnorm)*(1/mmnorm)*w(i)*w(n)*w(m)*w(l)*mx(kx-1,i)*my(ky-1,n)*mx(kx2-1,m)*my(ky2-1,l);
				}
			}
		}
	}

}

void lagsolve(Arr& B, Arr& r, Arr& f, Arr& lag) {
	int H = f.size()-1;
	LaGenMatDouble Btemp(H,H);
	LaVectorDouble rtemp(H), ftemp(H);
	Btemp = 0;
	ftemp = 0;
	for (int i=0; i<H-1; i++) {
		ftemp(i)=f(i+1);
		for(int j=0; j<H-1; j++) {
			Btemp(i,j)=B(i+1,j+1);
		}
	}

	for (int i=0; i<H-1; i++) {
		Btemp(H-1,i) = lag(i+1);
		Btemp(i,H-1) = lag(i+1);
	}



	LaLinearSolveIP(Btemp, rtemp, ftemp);
	for (int i=0; i<H-1; i++) {
		r(i+1)=rtemp(i);
	}

}





