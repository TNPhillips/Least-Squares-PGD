/*
 * main.cpp
 *
 *  Created on: 20 Mar 2012
 *      Author: plog
 */
/*
 * main.cpp
 *
 *  Created on: 16 Apr 2012
 *      Author: plog
 */
#include "FP1D2.h"
#include "PGDS2.h"
#include "PGDP2.h"
#include "FFP2.h"
#include "PGDLSQS2.h"
#include "PGDLSQP2.h"
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <lasvd.h>
#include <blas3pp.h>
#include <time.h>
#include "arrays.h"

using namespace std;
using namespace polylib;

int main(int argc, char* argv[]) {

	stream = 0;

	if (atoi(argv[1])==1) {
		//Program #1: Poisson Equation in 2D



		if (atoi(argv[2])==0) {
			//SVD THING
			J=atoi(argv[3])+4;
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}

			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			Arr u2(N+1,N+1,Kx,Ky);

			Arr X(J,N+1,Kx), Y(J,N+1,Ky); // Initialising arrays for PGD coefficients

			CPUtime = fopen("CPUtimeG.txt","w");

			PGDPoisson(X,Y); //PGD algorithm (Calculates X and Y)

			fclose(CPUtime);

			u2true(u2);

			FILE* outputxy;

			outputxy=fopen("svdthis.txt","w");

			for (int i=0; i<N+1; i++) {
				for (int j=0; j<N+1; j++) {
					fprintf(outputxy,"%15.16e ", u2(j,i,0,0));
				}
				if(Kx>0) {
					for (int kx=1; kx<Kx; kx++) {
						for(int j=1; j<N+1; j++) {
							fprintf(outputxy,"%15.16e ", u2(j,i,kx,0));
						}
					}
				}
				fprintf(outputxy,"\n");


			}

			if(Ky>0) {
				for (int ky=1; ky<Ky; ky++) {
					for (int i=1; i<N+1; i++) {
						for (int j=0; j<N+1; j++) {
							fprintf(outputxy,"%15.16e ", u2(j,i,0,ky));
						}
						if (Kx>0) {
							for (int kx=1; kx<Kx; kx++) {
								for (int j=1; j<N+1; j++) {
									fprintf(outputxy,"%15.16e ", u2(j,i,kx,ky));
								}
							}
						}
						fprintf(outputxy,"\n");
					}

				}
			}

			fclose(outputxy);
		}


		if (atoi(argv[2])==1) {
			/*** Routine #1: PGD Approximation Plot----------------------------------
			 *** Arguments: J, N, Kx, Ky, (ax, bx, ay, by)                        */

			J=atoi(argv[3])+4;// +4 for transfinite interpolation
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}



			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			Arr X(J,N+1,Kx), Y(J,N+1,Ky); // Initialising arrays for PGD coefficients

			CPUtime = fopen("CPUtimeG.txt","w");

			PGDPoisson(X,Y); //PGD algorithm (Calculates X and Y)

			fclose(CPUtime);


			FILE * outputx;//Start: Output to file--------
			FILE * outputy;
			FILE * info;

			info = fopen("info.txt","w");
			fprintf(info,"%15d %15d %15d %15d %15.16e %15.16e %15.16e %15.16e", J, N, Kx, Ky, ax, bx, ay, by);
			fclose(info);

			outputx = fopen("PGDSEMPoissonx.txt","w");
			outputy = fopen("PGDSEMPoissony.txt","w");

			for (int i=0; i<N+1; i++) {
				for (int j=0; j<J; j++) {
					fprintf(outputx,"%15.16e ", X(j,i,0));
				}
				fprintf(outputx,"\n");
			}


			if (Kx>1) {

				for (int k=2; k<=Kx; k++) {
					for (int i=1; i<N+1; i++) {
						for (int j=0; j<J; j++) {
							fprintf(outputx,"%15.16e ", X(j,i,k-1));
						}
						fprintf(outputx,"\n");
					}
				}
			}

			for (int i=0; i<N+1; i++) {
				for (int j=0; j<J; j++) {
					fprintf(outputy,"%15.16e ", Y(j,i,0));
				}
				fprintf(outputy,"\n");
			}


			if (Ky>1) {

				for (int k=2; k<=Ky; k++) {
					for (int i=1; i<N+1; i++) {
						for (int j=0; j<J; j++) {
							fprintf(outputy,"%15.16e ", Y(j,i,k-1));
						}
						fprintf(outputy,"\n");
					}
				}
			}
			fclose(outputy);
			fclose(outputx);//End: Output to file---------

		}

		if (atoi(argv[2])==2) {
			/*** Routine #2: PGD Error (Increasing J)----------------------------------
			 *** Arguments: J (max), N, Kx, Ky, (ax, bx, ay, by)                   */

			J=atoi(argv[3])+4;
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}

			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			Arr X(J,N+1,Kx), Y(J,N+1,Ky); // Initialising arrays for PGD coefficients

			double sum, logJ, E; //Values for plotting error

			Arr u2(N+1,N+1,Kx,Ky);

			CPUtime = fopen("CPUtimeG.txt","w");

			PGDPoisson(X,Y); // PGD algorithm (Calculates X & Y)

			fclose(CPUtime);

			u2true(u2); // Evaluates u at mapped GL points


			FILE * output2; //Begin: Output to file---------
			output2= fopen("PGDerrJ.txt","w");
			for (int JJ=5; JJ<=J; JJ++) {
				E=0;
				for (int kx=1; kx<=Kx; kx++) {
					for (int ky=1; ky<=Ky; ky++) {
						for (int i=0; i<N+1; i++) {
							for (int n=0; n<N+1; n++) {
								sum=0;
								for (int j=1; j<=JJ; j++) {
									sum += X(j-1,i,kx-1)*Y(j-1,n,ky-1);
								}
								E += (dx*dy/4)*w(i)*w(n)*pow(u2(i,n,kx-1,ky-1)-sum,2);
							}
						}
					}
				}
				logJ=log10(JJ-4);
				E=log10(sqrt(E));
				fprintf(output2,"%15.16e %15.16e\n", logJ, E);
			}
			fclose(output2);//End: Output to file----------

		}

		if (atoi(argv[2])==3) {
			/*** Routine #2: PGD Error (Increasing N)----------------------------------
			 *** Arguments: J (max), N, Kx, Ky, (ax, bx, ay, by)                   */
			J=atoi(argv[3])+4;
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}

			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			Arr X(J,N+1,Kx), Y(J,N+1,Ky); // Initialising arrays for PGD coefficients

			double sum, logN, E; //Values for plotting error

			Arr u2(N+1,N+1,Kx,Ky);

			cout << "whooo" << endl;

			CPUtime = fopen("CPUtimeG.txt","w");

			PGDPoisson(X,Y); // PGD algorithm (Calculates X & Y)

			fclose(CPUtime);

			u2true(u2); // Evaluates u at mapped GL points



			FILE * output2; //Begin: Output to file---------

			if (N==1) {
				output2= fopen("PGDerrN.txt","w");
			}
			else {
				output2=fopen("PGDerrN.txt","a");
			}


			E=0;
			for (int kx=1; kx<=Kx; kx++) {
				for (int ky=1; ky<=Ky; ky++) {
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							sum=0;
							for (int j=1; j<=J; j++) {
								sum += X(j-1,i,kx-1)*Y(j-1,n,ky-1);
							}
							E += (dx*dy/4)*w(i)*w(n)*pow(u2(i,n,kx-1,ky-1)-sum,2);
						}
					}
				}
			}
			logN=log10(N);
			E=log10(sqrt(E));
			fprintf(output2,"%15.16e %15.16e\n", logN, E);
			fclose(output2);//End: Output to file----------

		}

		if (atoi(argv[2])==4) {
			/*** Routine #2: PGD Error (Increasing N)----------------------------------
			 *** Arguments: J (max), N, Kx, Ky, (ax, bx, ay, by)                   */
			J=atoi(argv[3])+4;
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}

			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			Arr X(J,N+1,Kx), Y(J,N+1,Ky); // Initialising arrays for PGD coefficients

			double sum, logN, E; //Values for plotting error

			Arr u2(N+1,N+1,Kx,Ky);

			cout << "whooo" << endl;

			CPUtime = fopen("CPUtimeG.txt","w");

			PGDPoisson(X,Y); // PGD algorithm (Calculates X & Y)

			fclose(CPUtime);

			u2true(u2); // Evaluates u at mapped GL points



			FILE * output2; //Begin: Output to file---------

			if (Kx==3) {
				output2= fopen("PGDerrK.txt","w");
			}
			else {
				output2=fopen("PGDerrK.txt","a");
			}


			E=0;
			for (int kx=1; kx<=Kx; kx++) {
				for (int ky=1; ky<=Ky; ky++) {
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							sum=0;
							for (int j=1; j<=J; j++) {
								sum += X(j-1,i,kx-1)*Y(j-1,n,ky-1);
							}
							E += (dx*dy/4)*w(i)*w(n)*pow(u2(i,n,kx-1,ky-1)-sum,2);
						}
					}
				}
			}
			logN=log10(((bx-ax))/(double)Kx);
			E=log10(sqrt(E));
			fprintf(output2,"%15.16e %15.16e\n", logN, E);
			fclose(output2);//End: Output to file----------

		}


	}

	if (atoi(argv[1])==2) {
		//Galerkin Stokes PGD

		if (atoi(argv[2])==1) {
			//Approximation Plots


			J=atoi(argv[3])+4;
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}


			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			// Initialising arrays for PGD coefficients:
			Arr Xu(J,N+1,Kx), Yu(J,N+1,Ky), Xv(J,N+1,Kx), Yv(J,N+1,Ky), Xp(J,N-1,Kx), Yp(J,N-1,Ky);

			PGDStokes(Xu,Yu,Xv,Yv,Xp,Yp);

			FILE *outputux, *outputvx, *outputpx;
			FILE *outputuy, *outputvy, *outputpy;
			FILE *info;

			info = fopen("info.txt","w");
			fprintf(info,"%15d %15d %15d %15d %15.16e %15.16e %15.16e %15.16e", J, N, Kx, Ky, ax, bx, ay, by);
			fclose(info);

			outputux = fopen("PGDSEMStokesux.txt","w");
			outputuy = fopen("PGDSEMStokesuy.txt","w");
			outputvx = fopen("PGDSEMStokesvx.txt","w");
			outputvy = fopen("PGDSEMStokesvy.txt","w");
			outputpx = fopen("PGDSEMStokespx.txt","w");
			outputpy = fopen("PGDSEMStokespy.txt","w");

			for (int i=0; i<N+1; i++) {
				for (int j=0; j<J; j++) {
					fprintf(outputux,"%15.16e ", Xu(j,i,0));
					fprintf(outputvx,"%15.16e ", Xv(j,i,0));
				}
				fprintf(outputux,"\n");
				fprintf(outputvx,"\n");
			}

			for (int i=0; i<N-1; i++) {
				for (int j=0; j<J; j++) {
					fprintf(outputpx,"%15.16e ", Xp(j,i,0));
				}
				fprintf(outputpx,"\n");
			}


			if (Kx>1) {

				for (int k=2; k<=Kx; k++) {

					for (int i=1; i<N+1; i++) {
						for (int j=0; j<J; j++) {
							fprintf(outputux,"%15.16e ", Xu(j,i,k-1));
							fprintf(outputvx,"%15.16e ", Xv(j,i,k-1));
						}
						fprintf(outputux,"\n");
						fprintf(outputvx,"\n");
					}

					for(int i=0; i<N-1; i++) {
						for(int j=0; j<J; j++) {
							fprintf(outputpx,"%15.16e ", Xp(j,i,k-1));
						}
						fprintf(outputpx,"\n");
					}
				}
			}

			for (int i=0; i<N+1; i++) {
				for (int j=0; j<J; j++) {
					fprintf(outputuy,"%15.16e ", Yu(j,i,0));
					fprintf(outputvy,"%15.16e ", Yv(j,i,0));
				}
				fprintf(outputuy,"\n");
				fprintf(outputvy,"\n");
			}

			for (int i=0; i<N-1; i++) {
				for (int j=0; j<J; j++) {
					fprintf(outputpy,"%15.16e ", Yp(j,i,0));
				}
				fprintf(outputpy,"\n");
			}


			if (Ky>1) {

				for (int k=2; k<=Ky; k++) {

					for (int i=1; i<N+1; i++) {
						for (int j=0; j<J; j++) {
							fprintf(outputuy,"%15.16e ", Yu(j,i,k-1));
							fprintf(outputvy,"%15.16e ", Yv(j,i,k-1));
						}
						fprintf(outputuy,"\n");
						fprintf(outputvy,"\n");
					}

					for(int i=0; i<N-1; i++) {
						for(int j=0; j<J; j++) {
							fprintf(outputpy,"%15.16e ", Yp(j,i,k-1));
						}
						fprintf(outputpy,"\n");
					}
				}
			}

			fclose(outputux);
			fclose(outputuy);
			fclose(outputvx);
			fclose(outputvy);
			fclose(outputpx);
			fclose(outputpy);//End: Output to file---------


		}

		if(atoi(argv[2])==2) {

			//Error in increasing J (Galerkin Stokes)

			J=atoi(argv[3])+4;
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}

			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			Arr Xu(J,N+1,Kx), Yu(J,N+1,Ky); // Initialising arrays for PGD coefficients
			Arr Xv(J,N+1,Kx), Yv(J,N+1,Ky);
			Arr Xp(J,N-1,Kx), Yp(J,N-1,Ky);

			double sumu, sumv, sump, logJ, Eu, Ev, Ep; //Values for plotting error

			Arr u2(N+1,N+1,Kx,Ky), v2(N+1,N+1,Kx,Ky), p2(N+1,N+1,Kx,Ky);

			PGDStokes(Xu,Yu,Xv,Yv,Xp,Yp); // PGD algorithm (Calculates X & Y)

			uvp2true(u2,v2,p2); // Evaluates u,v,p at mapped GL points


			FILE * outputu, * outputv, *outputp; //Begin: Output to file---------

			if (J==5) {
				outputu= fopen("PGDerrJu.txt","w");
				outputv= fopen("PGDerrJv.txt","w");
				outputp= fopen("PGDerrJp.txt","w");
			}
			else {
				outputu= fopen("PGDerrJu.txt","a");
				outputv= fopen("PGDerrJv.txt","a");
				outputp= fopen("PGDerrJp.txt","a");
			}

			Eu=0;
			Ev=0;
			Ep=0;
			for (int kx=1; kx<=Kx; kx++) {
				for (int ky=1; ky<=Ky; ky++) {
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							sumu=0;
							sumv=0;
							for (int j=1; j<=J; j++) {
								sumu += Xu(j-1,i,kx-1)*Yu(j-1,n,ky-1);
								sumv += Xv(j-1,i,kx-1)*Yv(j-1,n,ky-1);
							}
							Eu += (dx*dy/4)*w(i)*w(n)*pow(u2(i,n,kx-1,ky-1)-sumu,2);
							Ev += (dx*dy/4)*w(i)*w(n)*pow(v2(i,n,kx-1,ky-1)-sumv,2);
						}
					}
					for(int i=1; i<N; i++) {
						for (int n=1; n<N; n++) {
							sump=0;
							for (int j=1; j<=J; j++) {
								sump += Xp(j-1,i-1,kx-1)*Yp(j-1,n-1,ky-1);
							}
							Ep += (dx*dy/4)*w(i)*w(n)*pow(p2(i,n,kx-1,ky-1)-sump,2);
						}
					}
				}
			}
			logJ=log10(J-4);
			Eu=log10(sqrt(Eu));
			Ev=log10(sqrt(Ev));
			Ep=log10(sqrt(Ep));
			fprintf(outputu,"%15.16e %15.16e\n", logJ, Eu);
			fprintf(outputv,"%15.16e %15.16e\n", logJ, Ev);
			fprintf(outputp,"%15.16e %15.16e\n", logJ, Ep);
			fclose(outputu);//End: Output to file----------
			fclose(outputv);
			fclose(outputp);

		}

		if(atoi(argv[2])==3) {

			//Error in increasing N (Galerkin Stokes)

			J=atoi(argv[3])+4;
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}


			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			Arr Xu(J,N+1,Kx), Yu(J,N+1,Ky); // Initialising arrays for PGD coefficients
			Arr Xv(J,N+1,Kx), Yv(J,N+1,Ky);
			Arr Xp(J,N-1,Kx), Yp(J,N-1,Ky);

			double sumu, sumv, sump, logN, Eu, Ev, Ep; //Values for plotting error

			Arr u2(N+1,N+1,Kx,Ky), v2(N+1,N+1,Kx,Ky), p2(N+1,N+1,Kx,Ky);

			PGDStokes(Xu,Yu,Xv,Yv,Xp,Yp); // PGD algorithm (Calculates X & Y)

			uvp2true(u2,v2,p2); // Evaluates u,v,p at mapped GL points


			FILE * outputu, * outputv, *outputp; //Begin: Output to file---------

			if (N==4) {
				outputu= fopen("PGDerrNu.txt","w");
				outputv= fopen("PGDerrNv.txt","w");
				outputp= fopen("PGDerrNp.txt","w");
			}
			else {
				outputu= fopen("PGDerrNu.txt","a");
				outputv= fopen("PGDerrNv.txt","a");
				outputp= fopen("PGDerrNp.txt","a");
			}

			Eu=0;
			Ev=0;
			Ep=0;
			for (int kx=1; kx<=Kx; kx++) {
				for (int ky=1; ky<=Ky; ky++) {
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							sumu=0;
							sumv=0;
							for (int j=1; j<=J; j++) {
								sumu += Xu(j-1,i,kx-1)*Yu(j-1,n,ky-1);
								sumv += Xv(j-1,i,kx-1)*Yv(j-1,n,ky-1);
							}
							Eu += (dx*dy/4)*w(i)*w(n)*pow(u2(i,n,kx-1,ky-1)-sumu,2);
							Ev += (dx*dy/4)*w(i)*w(n)*pow(v2(i,n,kx-1,ky-1)-sumv,2);
						}
					}
					for(int i=1; i<N; i++) {
						for (int n=1; n<N; n++) {
							sump=0;
							for (int j=1; j<=J; j++) {
								sump += Xp(j-1,i-1,kx-1)*Yp(j-1,n-1,ky-1);
							}
							Ep += (dx*dy/4)*w(i)*w(n)*pow(p2(i,n,kx-1,ky-1)-sump,2);
						}
					}
				}
			}
			logN=log10(N);
			Eu=log10(sqrt(Eu));
			Ev=log10(sqrt(Ev));
			Ep=log10(sqrt(Ep));
			fprintf(outputu,"%15.16e %15.16e\n", logN, Eu);
			fprintf(outputv,"%15.16e %15.16e\n", logN, Ev);
			fprintf(outputp,"%15.16e %15.16e\n", logN, Ep);
			fclose(outputu);//End: Output to file----------
			fclose(outputv);
			fclose(outputp);

		}
	}

	if (atoi(argv[1])==3) {
		//Program #3: Least Squares Stokes
		if (atoi(argv[2])==1) {
			//XVGVP Lid Driven Cavity

			stream = 1;

			J=atoi(argv[3])+4;
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}


			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			CPUtime= fopen("dump.txt","w");


			// Initialising arrays for PGD coefficients:
			Arr Xu(J,N+1,Kx), Yu(J,N+1,Ky), Xv(J,N+1,Kx), Yv(J,N+1,Ky), Xp(J,N+1,Kx), Yp(J,N+1,Ky);
			Arr XV1(J,N+1,Kx), YV1(J,N+1,Ky), XV2(J,N+1,Kx), YV2(J,N+1,Ky), XV3(J,N+1,Kx), YV3(J,N+1,Ky), XV4(J,N+1,Kx), YV4(J,N+1,Ky);

			PGDLSQStokesX(Xu,Yu,Xv,Yv,Xp,Yp,XV1,YV1,XV2,YV2,XV3,YV3,XV4,YV4);

			fclose(CPUtime);

			FILE *outputux, *outputvx;
			FILE *outputuy, *outputvy;
			FILE *info;
			info = fopen("info.txt","w");
			fprintf(info,"%15d %15d %15d %15d %15.16e %15.16e %15.16e %15.16e", J, N, Kx, Ky, ax, bx, ay, by);
			fclose(info);



			outputux = fopen("PGDLSQStokesux.txt","w");
			outputuy = fopen("PGDLSQStokesuy.txt","w");
			outputvx = fopen("PGDLSQStokesvx.txt","w");
			outputvy = fopen("PGDLSQStokesvy.txt","w");

			for (int i=0; i<N+1; i++) {
				for (int j=0; j<J; j++) {
					fprintf(outputux,"%15.16e ", Xu(j,i,0));
					fprintf(outputvx,"%15.16e ", Xv(j,i,0));

				}
				fprintf(outputux,"\n");
				fprintf(outputvx,"\n");
			}

			if (Kx>1) {

				for (int k=2; k<=Kx; k++) {

					for (int i=1; i<N+1; i++) {
						for (int j=0; j<J; j++) {
							fprintf(outputux,"%15.16e ", Xu(j,i,k-1));
							fprintf(outputvx,"%15.16e ", Xv(j,i,k-1));
						}
						fprintf(outputux,"\n");
						fprintf(outputvx,"\n");
					}

				}
			}

			for (int i=0; i<N+1; i++) {
				for (int j=0; j<J; j++) {
					fprintf(outputuy,"%15.16e ", Yu(j,i,0));
					fprintf(outputvy,"%15.16e ", Yv(j,i,0));
				}
				fprintf(outputuy,"\n");
				fprintf(outputvy,"\n");
			}


			if (Ky>1) {

				for (int k=2; k<=Ky; k++) {

					for (int i=1; i<N+1; i++) {
						for (int j=0; j<J; j++) {
							fprintf(outputuy,"%15.16e ", Yu(j,i,k-1));
							fprintf(outputvy,"%15.16e ", Yv(j,i,k-1));
						}
						fprintf(outputuy,"\n");
						fprintf(outputvy,"\n");
					}

				}
			}

			fclose(outputux);
			fclose(outputuy);
			fclose(outputvx);
			fclose(outputvy);

			Arr Stream(N+1,N+1,Kx,Ky);

			Streamfct(Xv,Yv,Stream);

			FILE *streamfile;
			FILE *streamsize;

			streamfile = fopen("streamfct.txt","w");
			streamsize = fopen("streamsize.txt", "a");

			double E;
			double sum;


							E=0;
							for (int kx=1; kx<=Kx; kx++) {
								for (int ky=1; ky<=Ky; ky++) {
									for (int i=0; i<N+1; i++) {
										for (int n=0; n<N+1; n++) {
											E += (dx*dy/4)*w(i)*w(n)*pow(Stream(i,n,kx-1,ky-1),2);
										}
									}
								}
							}
							fprintf(streamsize,"%15.16e %15.16e\n", J, E);





			for (int n=0; n<N+1; n++) {
				for (int m=0; m<N+1; m++) {
					fprintf(streamfile,"%15.16e ", Stream(n,m,0,0));
				}
				if (Ky>1) {
					for (int ky=2; ky<=Ky; ky++) {
						for (int m=1; m<N+1; m++) {
							fprintf(streamfile,"%15.16e ", Stream(n,m,0,ky-1));
						}
					}
				}
				fprintf(streamfile,"\n");
			}


			if(Kx>1) {
				for (int kx=2; kx<=Kx; kx++) {
					for(int n=1; n<N+1; n++) {
						for (int m=0; m<N+1; m++) {
							fprintf(streamfile,"%15.16e ", Stream(n,m,kx-1,0));
						}
						if (Ky>1) {
							for (int ky=2; ky<=Ky; ky++) {
								for (int m=1; m<N+1; m++) {
									fprintf(streamfile,"%15.16e ", Stream(n,m,kx-1,ky-1));
								}
							}
						}
						fprintf(streamfile,"\n");
					}
				}
			}



			fclose(streamfile);





		}


		if (atoi(argv[2])==2) {
			// Approximation Plots for VVP?

			J=atoi(argv[3])+4;
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}


			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}


			// Initialising arrays for PGD coefficients:
			Arr Xu(J,N+1,Kx), Yu(J,N+1,Ky), Xv(J,N+1,Kx), Yv(J,N+1,Ky), Xw(J,N+1,Kx), Yw(J,N+1,Ky), Xp(J,N+1,Kx), Yp(J,N+1,Ky);

			PGDLSQStokes(Xu,Yu,Xv,Yv,Xw,Yw,Xp,Yp);

			FILE *outputux, *outputvx, *outputwx, *outputpx;
			FILE *outputuy, *outputvy, *outputwy, *outputpy;
			FILE *info;
			info = fopen("info.txt","w");
			fprintf(info,"%15d %15d %15d %15d %15.16e %15.16e %15.16e %15.16e", J, N, Kx, Ky, ax, bx, ay, by);
			fclose(info);



			outputux = fopen("PGDLSQStokesux.txt","w");
			outputuy = fopen("PGDLSQStokesuy.txt","w");
			outputvx = fopen("PGDLSQStokesvx.txt","w");
			outputvy = fopen("PGDLSQStokesvy.txt","w");
			outputwx = fopen("PGDLSQStokeswx.txt","w");
			outputwy = fopen("PGDLSQStokeswy.txt","w");
			outputpx = fopen("PGDLSQStokespx.txt","w");
			outputpy = fopen("PGDLSQStokespy.txt","w");

			for (int i=0; i<N+1; i++) {
				for (int j=0; j<J; j++) {
					fprintf(outputux,"%15.16e ", Xu(j,i,0));
					fprintf(outputvx,"%15.16e ", Xv(j,i,0));
					fprintf(outputwx,"%15.16e ", Xw(j,i,0));
					fprintf(outputpx,"%15.16e ", Xp(j,i,0));

				}
				fprintf(outputux,"\n");
				fprintf(outputvx,"\n");
				fprintf(outputwx,"\n");
				fprintf(outputpx,"\n");
			}

			if (Kx>1) {

				for (int k=2; k<=Kx; k++) {

					for (int i=1; i<N+1; i++) {
						for (int j=0; j<J; j++) {
							fprintf(outputux,"%15.16e ", Xu(j,i,k-1));
							fprintf(outputvx,"%15.16e ", Xv(j,i,k-1));
							fprintf(outputwx,"%15.16e ", Xw(j,i,k-1));
							fprintf(outputpx,"%15.16e ", Xp(j,i,k-1));
						}
						fprintf(outputux,"\n");
						fprintf(outputvx,"\n");
						fprintf(outputwx,"\n");
						fprintf(outputpx,"\n");
					}

				}
			}

			for (int i=0; i<N+1; i++) {
				for (int j=0; j<J; j++) {
					fprintf(outputuy,"%15.16e ", Yu(j,i,0));
					fprintf(outputvy,"%15.16e ", Yv(j,i,0));
					fprintf(outputwy,"%15.16e ", Yw(j,i,0));
					fprintf(outputpy,"%15.16e ", Yp(j,i,0));
				}
				fprintf(outputuy,"\n");
				fprintf(outputvy,"\n");
				fprintf(outputwy,"\n");
				fprintf(outputpy,"\n");
			}


			if (Ky>1) {

				for (int k=2; k<=Ky; k++) {

					for (int i=1; i<N+1; i++) {
						for (int j=0; j<J; j++) {
							fprintf(outputuy,"%15.16e ", Yu(j,i,k-1));
							fprintf(outputvy,"%15.16e ", Yv(j,i,k-1));
							fprintf(outputwy,"%15.16e ", Yw(j,i,k-1));
							fprintf(outputpy,"%15.16e ", Yp(j,i,k-1));
						}
						fprintf(outputuy,"\n");
						fprintf(outputvy,"\n");
						fprintf(outputwy,"\n");
						fprintf(outputpy,"\n");
					}

				}
			}

			fclose(outputux);
			fclose(outputuy);
			fclose(outputvx);
			fclose(outputvy);
			fclose(outputwx);
			fclose(outputwy);
			fclose(outputpx);
			fclose(outputpy);//End: Output to file---------

		}



		if (atoi(argv[2])==3) {
			// VVP Error and CPU Time (no h)

			ishh = 0;

			J=atoi(argv[3])+4;
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}

			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			Arr Xu(J,N+1,Kx), Yu(J,N+1,Ky); // Initialising arrays for PGD coefficients
			Arr Xv(J,N+1,Kx), Yv(J,N+1,Ky);
			Arr Xw(J,N+1,Kx), Yw(J,N+1,Ky);
			Arr Xp(J,N+1,Kx), Yp(J,N+1,Ky);

			double sumu, sumv, sumw, sump, logJ, Eu, Ev, Ew, Ep; //Values for plotting error

			Arr u2(N+1,N+1,Kx,Ky), v2(N+1,N+1,Kx,Ky), w2(N+1,N+1,Kx,Ky), p2(N+1,N+1,Kx,Ky);

			FILE * outputu, * outputv, *outputw, *outputp; //Begin: Output to file---------

			outputu= fopen("PGDerrJu1.txt","w");
			outputv= fopen("PGDerrJv1.txt","w");
			outputw= fopen("PGDerrJw1.txt","w");
			outputp= fopen("PGDerrJp1.txt","w");
			CPUtime= fopen("LSQStime1.txt","w");


			PGDLSQStokes(Xu,Yu,Xv,Yv,Xw,Yw,Xp,Yp); // PGD algorithm (Calculates X & Y)

			fclose(CPUtime);

			uvwptrue(u2,v2,w2,p2); // Evaluates u,v,p at mapped GL points

			for (int JJ=5; JJ<=J; JJ++) {
				Eu=0;
				Ev=0;
				Ew=0;
				Ep=0;
				for (int kx=1; kx<=Kx; kx++) {
					for (int ky=1; ky<=Ky; ky++) {
						for (int i=0; i<N+1; i++) {
							for (int n=0; n<N+1; n++) {
								sumu=0;
								sumv=0;
								sumw=0;
								sump=0;
								for (int j=1; j<=JJ; j++) {
									sumu += Xu(j-1,i,kx-1)*Yu(j-1,n,ky-1);
									sumv += Xv(j-1,i,kx-1)*Yv(j-1,n,ky-1);
									sumw += Xw(j-1,i,kx-1)*Yw(j-1,n,ky-1);
									sump += Xp(j-1,i,kx-1)*Yp(j-1,n,ky-1);
								}
								Eu += (dx*dy/4)*w(i)*w(n)*pow(u2(i,n,kx-1,ky-1)-sumu,2);
								Ev += (dx*dy/4)*w(i)*w(n)*pow(v2(i,n,kx-1,ky-1)-sumv,2);
								Ew += (dx*dy/4)*w(i)*w(n)*pow(w2(i,n,kx-1,ky-1)-sumw,2);
								Ep += (dx*dy/4)*w(i)*w(n)*pow(p2(i,n,kx-1,ky-1)-sump,2);
							}
						}
					}
				}
				logJ=log10(JJ-4);
				Eu=log10(sqrt(Eu));
				Ev=log10(sqrt(Ev));
				Ew=log10(sqrt(Ew));
				Ep=log10(sqrt(Ep));
				fprintf(outputu,"%15.16e %15.16e\n", logJ, Eu);
				fprintf(outputv,"%15.16e %15.16e\n", logJ, Ev);
				fprintf(outputw,"%15.16e %15.16e\n", logJ, Ew);
				fprintf(outputp,"%15.16e %15.16e\n", logJ, Ep);
			}
			fclose(outputu);//End: Output to file----------
			fclose(outputv);
			fclose(outputw);
			fclose(outputp);



		}

		if (atoi(argv[2])==4) {
			// VVP Error and CPU Time (with h)

			ishh = 1;

			J=atoi(argv[3])+4;
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}

			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			Arr Xu(J,N+1,Kx), Yu(J,N+1,Ky); // Initialising arrays for PGD coefficients
			Arr Xv(J,N+1,Kx), Yv(J,N+1,Ky);
			Arr Xw(J,N+1,Kx), Yw(J,N+1,Ky);
			Arr Xp(J,N+1,Kx), Yp(J,N+1,Ky);

			double sumu, sumv, sumw, sump, logJ, Eu, Ev, Ew, Ep; //Values for plotting error

			Arr u2(N+1,N+1,Kx,Ky), v2(N+1,N+1,Kx,Ky), w2(N+1,N+1,Kx,Ky), p2(N+1,N+1,Kx,Ky);

			FILE * outputu, * outputv, *outputw, *outputp; //Begin: Output to file---------

			outputu= fopen("PGDerrJu2.txt","w");
			outputv= fopen("PGDerrJv2.txt","w");
			outputw= fopen("PGDerrJw2.txt","w");
			outputp= fopen("PGDerrJp2.txt","w");
			CPUtime= fopen("LSQStime2.txt","w");


			PGDLSQStokes(Xu,Yu,Xv,Yv,Xw,Yw,Xp,Yp); // PGD algorithm (Calculates X & Y)

			fclose(CPUtime);

			uvwptrue(u2,v2,w2,p2); // Evaluates u,v,p at mapped GL points

			for (int JJ=5; JJ<=J; JJ++) {
				Eu=0;
				Ev=0;
				Ew=0;
				Ep=0;
				for (int kx=1; kx<=Kx; kx++) {
					for (int ky=1; ky<=Ky; ky++) {
						for (int i=0; i<N+1; i++) {
							for (int n=0; n<N+1; n++) {
								sumu=0;
								sumv=0;
								sumw=0;
								sump=0;
								for (int j=1; j<=JJ; j++) {
									sumu += Xu(j-1,i,kx-1)*Yu(j-1,n,ky-1);
									sumv += Xv(j-1,i,kx-1)*Yv(j-1,n,ky-1);
									sumw += Xw(j-1,i,kx-1)*Yw(j-1,n,ky-1);
									sump += Xp(j-1,i,kx-1)*Yp(j-1,n,ky-1);
								}
								Eu += (dx*dy/4)*w(i)*w(n)*pow(u2(i,n,kx-1,ky-1)-sumu,2);
								Ev += (dx*dy/4)*w(i)*w(n)*pow(v2(i,n,kx-1,ky-1)-sumv,2);
								Ew += (dx*dy/4)*w(i)*w(n)*pow(w2(i,n,kx-1,ky-1)-sumw,2);
								Ep += (dx*dy/4)*w(i)*w(n)*pow(p2(i,n,kx-1,ky-1)-sump,2);
							}
						}
					}
				}
				logJ=log10(JJ-4);
				Eu=log10(sqrt(Eu));
				Ev=log10(sqrt(Ev));
				Ew=log10(sqrt(Ew));
				Ep=log10(sqrt(Ep));
				fprintf(outputu,"%15.16e %15.16e\n", logJ, Eu);
				fprintf(outputv,"%15.16e %15.16e\n", logJ, Ev);
				fprintf(outputw,"%15.16e %15.16e\n", logJ, Ew);
				fprintf(outputp,"%15.16e %15.16e\n", logJ, Ep);
			}
			fclose(outputu);//End: Output to file----------
			fclose(outputv);
			fclose(outputw);
			fclose(outputp);



		}

		if (atoi(argv[2])==5) {
			// XVGVP Error and CPU Time

			J=atoi(argv[3])+4;
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			if (argv[7]==NULL) {
				ax=-1;
				ay=-1;
				bx=1;
				by=1;
			}
			else {
				ax=atof(argv[7]);
				bx=atof(argv[8]);
				ay=atof(argv[9]);
				by=atof(argv[10]);
			}

			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			Arr Xu(J,N+1,Kx), Yu(J,N+1,Ky); // Initialising arrays for PGD coefficients
			Arr Xv(J,N+1,Kx), Yv(J,N+1,Ky);
			Arr Xp(J,N+1,Kx), Yp(J,N+1,Ky);
			Arr XV1(J,N+1,Kx), YV1(J,N+1,Ky);
			Arr XV2(J,N+1,Kx), YV2(J,N+1,Ky);
			Arr XV3(J,N+1,Kx), YV3(J,N+1,Ky);
			Arr XV4(J,N+1,Kx), YV4(J,N+1,Ky);

			double sumu, sumv, sump, logJ, Eu, Ev, Ep; //Values for plotting error

			Arr u2(N+1,N+1,Kx,Ky), v2(N+1,N+1,Kx,Ky), p2(N+1,N+1,Kx,Ky);

			FILE *outputu, *outputv, *outputp; //Begin: Output to file---------


			outputu= fopen("XPGDerrJu.txt","w");
			outputv= fopen("XPGDerrJv.txt","w");
			outputp= fopen("XPGDerrJp.txt","w");
			CPUtime = fopen("LSQSXtime.txt","w");

			PGDLSQStokesX(Xu,Yu,Xv,Yv,Xp,Yp,XV1,YV1,XV2,YV2,XV3,YV3,XV4,YV4); // PGD algorithm (Calculates X & Y)

			fclose(CPUtime);


			Xuvptrue(u2,v2,p2); // Evaluates u,v,p at mapped GL points



			for (int JJ=5; JJ<=J; JJ++) {
				Eu=0;
				Ev=0;
				Ep=0;
				for (int kx=1; kx<=Kx; kx++) {
					for (int ky=1; ky<=Ky; ky++) {
						for (int i=0; i<N+1; i++) {
							for (int n=0; n<N+1; n++) {
								sumu=0;
								sumv=0;
								sump=0;
								for (int j=1; j<=JJ; j++) {
									sumu += Xu(j-1,i,kx-1)*Yu(j-1,n,ky-1);
									sumv += Xv(j-1,i,kx-1)*Yv(j-1,n,ky-1);
									sump += Xp(j-1,i,kx-1)*Yp(j-1,n,ky-1);
								}
								Eu += (dx*dy/4)*w(i)*w(n)*pow(u2(i,n,kx-1,ky-1)-sumu,2);
								Ev += (dx*dy/4)*w(i)*w(n)*pow(v2(i,n,kx-1,ky-1)-sumv,2);
								Ep += (dx*dy/4)*w(i)*w(n)*pow(p2(i,n,kx-1,ky-1)-sump,2);
							}
						}
					}
				}
				logJ=log10(JJ-4);
				Eu=(sqrt(Eu));
				Ev=(sqrt(Ev));
				Ep=(sqrt(Ep));
				fprintf(outputu,"%15.16e %15.16e\n", logJ, Eu);
				fprintf(outputv,"%15.16e %15.16e\n", logJ, Ev);
				fprintf(outputp,"%15.16e %15.16e\n", logJ, Ep);
			}
			fclose(outputu);//End: Output to file----------
			fclose(outputv);
			fclose(outputp);

		}


	}

	if (atoi(argv[1])==4) { //Least-squares Poisson

		FILE *outputphi, *outputu, *outputv;

		J=atoi(argv[3])+4;
		N=atoi(argv[4]);
		Kx=atoi(argv[5]);
		Ky=atoi(argv[6]);
		if (argv[7]==NULL) {
			ax=-1;
			ay=-1;
			bx=1;
			by=1;
		}
		else {
			ax=atof(argv[7]);
			bx=atof(argv[8]);
			ay=atof(argv[9]);
			by=atof(argv[10]);
		}

		//bb1=bb2=100/sqrt(2);
		bb1=bb2=100/sqrt(2);

		if ((ax>=bx) || (ay>=by)) {
			cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
			abort();
		}

		if(atoi(argv[2])==1) {
			gam=0;
			ishh=0;


			outputphi= fopen("PGDerrJphi1.txt","w");
			outputu= fopen("PGDerrJu1.txt","w");
			outputv= fopen("PGDerrJv1.txt","w");
			CPUtime = fopen("CPUtime1.txt","w");

		}
		if(atoi(argv[2])==2) {
			gam=0;
			ishh=1;


			outputphi= fopen("PGDerrJphi2.txt","w");
			outputu= fopen("PGDerrJu2.txt","w");
			outputv= fopen("PGDerrJv2.txt","w");
			CPUtime = fopen("CPUtime2.txt","w");
		}
		if(atoi(argv[2])==3) {
			gam=1;
			ishh=0;


			outputphi= fopen("PGDerrJphi4.txt","w");
			outputu= fopen("PGDerrJu4.txt","w");
			outputv= fopen("PGDerrJv4.txt","w");
			CPUtime = fopen("CPUtime4.txt","w");

		}



		Arr Xu(J,N+1,Kx), Yu(J,N+1,Ky); // Initialising arrays for PGD coefficients
		Arr Xv(J,N+1,Kx), Yv(J,N+1,Ky);
		Arr Xphi(J,N+1,Kx), Yphi(J,N+1,Ky);

		double sumphi, sumu, sumv, logJ, Ephi, Eu, Ev; //Values for plotting error

		Arr phi2(N+1,N+1,Kx,Ky), u2(N+1,N+1,Kx,Ky), v2(N+1,N+1,Kx,Ky);

		PGDLSQPoisson(Xphi,Yphi,Xu,Yu,Xv,Yv); // PGD algorithm (Calculates X & Y)

		fclose(CPUtime);


		phiuvtrue(phi2,u2,v2); // Evaluates u,v,p at mapped GL points



		for (int JJ=5; JJ<=J; JJ++) {
			Ephi=0;
			Eu=0;
			Ev=0;
			for (int kx=1; kx<=Kx; kx++) {
				for (int ky=1; ky<=Ky; ky++) {
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							sumphi=0;
							sumu=0;
							sumv=0;
							for (int j=1; j<=JJ; j++) {
								sumphi += Xphi(j-1,i,kx-1)*Yphi(j-1,n,ky-1);
								sumu += Xu(j-1,i,kx-1)*Yu(j-1,n,ky-1);
								sumv += Xv(j-1,i,kx-1)*Yv(j-1,n,ky-1);
							}
							Ephi += (dx*dy/4)*w(i)*w(n)*pow(phi2(i,n,kx-1,ky-1)-sumphi,2);
							Eu += (dx*dy/4)*w(i)*w(n)*pow(u2(i,n,kx-1,ky-1)-sumu,2);
							Ev += (dx*dy/4)*w(i)*w(n)*pow(v2(i,n,kx-1,ky-1)-sumv,2);
						}
					}
				}
			}
			logJ=log10(JJ-4);
			Ephi=log10(sqrt(Ephi));
			Eu=log10(sqrt(Eu));
			Ev=log10(sqrt(Ev));
			fprintf(outputphi,"%15.16e %15.16e\n", logJ, Ephi);
			fprintf(outputu,"%15.16e %15.16e\n", logJ, Eu);
			fprintf(outputv,"%15.16e %15.16e\n", logJ, Ev);
		}
		fclose(outputphi);
		fclose(outputu);
		fclose(outputv);//End: Output to file----------

	}

	if (atoi(argv[1])==5) {//1d Fokker Planck

		if(atoi(argv[2])==1) {

			J=atoi(argv[3]);
			N=atoi(argv[4]);
			Kx=atoi(argv[5]);
			Ky=atoi(argv[6]);
			noT=atof(argv[7]);

			ax=ay=-2*sqrt(mm);
			bx=by=2*sqrt(mm);

			unst = 1; //Unsteady 1 or Steady 0?
			semimp = 1; //Semi-implicit 1 or fully implicit 0?
			lsqnorm = 0; //Least-squares normality 1 or lagrange multiplier 0?
			cov = 0; //Change of variable (psi'=psi-sqrt(M)) 1 or no change 0?
			suli = 0; //Suli's normality 1 or something else (lsqnorm) 0?

			if ((ax>=bx) || (ay>=by)) {
				cerr << "DOMAINS DEFINED INCORRECTLY" << endl;
				abort();
			}

			Arr X(J+1,N+1,Kx), Y(J+1,N+1,Ky); // Initialising arrays for PGD coefficients
			Arr Xold(J+1,N+1,Kx), Yold(J+1,N+1,Ky);

			double kap = sqrt(2)/4.0;
			alp = 0;//0.1*pow(kap/(double)N,2);

			cout << "ALPHA IS " << alp << endl;

			double normality;

			FILE *normalityfile;

			normalityfile = fopen("normality.txt","w");


			CPUtime = fopen("FPCPU.txt","w");

			clock_t time, time2;

			time=clock();

			for (int i=0; i<noT; i++) {
				cout << "hello?" << endl;
				X=0;
				Y=0;

				PGDFP1D(X,Y,Xold,Yold,kap); //PGD algorithm (Calculates X and Y)
				kap = sqrt(2)/4.0;//pow(10.0,i-10);
				alp = 0;//0.1*pow(kap/(double)N,2);
				timestep1=false;

				time2 = clock()-time;

				fprintf(CPUtime,"%15.16d %15.16e\n", i, ((float)time2)/CLOCKS_PER_SEC);


				normality=0;
				for (int k=1; k<=Kx; k++) {
					for (int l=1; l<=Ky; l++) {
						for (int ii=0; ii<N+1; ii++) {
							for (int n=0; n<N+1; n++) {
								for (int j=0; j<J; j++) {
									if (((ii==0) && (k==1)) || ((ii==N) && (k==Kx)) || ((n==0) && (l==1)) || ((n==N) && (l==Ky))) {
										normality += 0;
									}
									else {
										normality += (1/mmnorm)*(dx*dy/4)*w(ii)*w(n)*X(j,ii,k-1)*sqrtmax(xx(k-1,ii))*Y(j,n,l-1)*sqrtmax(yy(l-1,n));
									}
								}
							}
						}
					}
				}


				fprintf(normalityfile,"%15d %15.16e\n", i, abs(1-normality));

				if (!cov && !lsqnorm) {
					for (int i=0; i<N+1; i++) {
						for (int j=0; j<J+1; j++) {
							for (int k=0; k<Kx; k++) {
								X(j,i,k)=(X(j,i,k))*(1/normality);
							}
						}
					}
				}

				Xold = X;
				Yold = Y;

			}

			fclose(CPUtime);

			fclose(normalityfile);

			if (cov) {
				for (int i=0; i<N+1; i++) {
					for (int k=0; k<Kx; k++) {
						X(J,i,k)=(1/mmnorm)*mx(k,i);
					}
					for (int k=0; k<Ky; k++) {
						Y(J,i,k)=my(k,i);
					}
				}
			}

			for (int i=0; i<N+1; i++) {
				for (int j=0; j<J+1; j++) {
					for (int k=0; k<Kx; k++) {
						X(j,i,k)=(X(j,i,k))*mx(k,i);
					}
					for (int k=0; k<Ky; k++) {
						Y(j,i,k)=(1/mmnorm)*Y(j,i,k)*my(k,i);
					}
				}
			}


			FILE * outputx;//Start: Output to file--------
			FILE * outputy;
			FILE * info;

			info = fopen("info.txt","w");
			fprintf(info,"%15d %15d %15d %15d %15.16e %15.16e %15.16e %15.16e", J+1, N, Kx, Ky, ax, bx, ay, by);
			fclose(info);

			outputx = fopen("FP1Dx.txt","w");
			outputy = fopen("FP1Dy.txt","w");

			for (int i=0; i<N+1; i++) {
				for (int j=0; j<J+1; j++) {
					fprintf(outputx,"%15.16e ", X(j,i,0));
				}
				fprintf(outputx,"\n");
			}


			if (Kx>1) {

				for (int k=2; k<=Kx; k++) {
					for (int i=1; i<N+1; i++) {
						for (int j=0; j<J+1; j++) {
							fprintf(outputx,"%15.16e ", X(j,i,k-1));
						}
						fprintf(outputx,"\n");
					}
				}
			}

			for (int i=0; i<N+1; i++) {
				for (int j=0; j<J+1; j++) {
					fprintf(outputy,"%15.16e ", Y(j,i,0));
				}
				fprintf(outputy,"\n");
			}


			if (Ky>1) {

				for (int k=2; k<=Ky; k++) {
					for (int i=1; i<N+1; i++) {
						for (int j=0; j<J+1; j++) {
							fprintf(outputy,"%15.16e ", Y(j,i,k-1));
						}
						fprintf(outputy,"\n");
					}
				}
			}
			fclose(outputy);
			fclose(outputx);//End: Output to file---------

		}
	}

	if (atoi(argv[1])==6) {//Full Fokker Planck

		if(atoi(argv[2])==1) {

			J=atoi(argv[3]);
			N=atoi(argv[4]);
			M=atoi(argv[5]);
			Kx=atoi(argv[6]);
			Ky=atoi(argv[7]);
			noT=atof(argv[8]);

			ax=ay=0;
			bx=2*sqrt(mm);
			by=1;

			Arr Q(J,N+1,Kx,2*M+1), Y(J,N+1,Ky); // Initialising arrays for PGD coefficients
			Arr Qold(J,N+1,Kx,2*M+1), Yold(J,N+1,Ky);

			Arr kap(N+1,Ky);

			for (int i=0; i<noT; i++) {
				Q=0;
				Y=0;

				PGDFFP(Q,Y,Qold,Yold,kap); //PGD algorithm (Calculates Q and Y)

				for (int n=0; n<N+1; n++) {
					for (int k=1; k<=Ky; k++) {
						kap(n,k-1)= sqrt(2)/4.0;
					}
				}

				cout << "NUMBER" << i << endl;

				timestep1=false;

				Qold=Q;
				Yold=Y;
			}

		}
	}




	return 0;
}

