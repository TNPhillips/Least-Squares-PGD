/*
 * PGDLSQ2.h
 *
 *  Created on: 22 Apr 2013
 *      Author: plog
 */

#ifndef PGDLSQ2_H_
#define PGDLSQ2_H_


#include "PGDLSQS.h"
#include "blaspp.h"
#include "laslv.h"
#include <blas1pp.h>
#include <stdio.h>
#include "arrays.h"

void PGDLSQStokes(Arr& Xu, Arr& Yu, Arr& Xv, Arr& Yv, Arr& Xw, Arr& Yw, Arr& Xp, Arr& Yp) {

	int count = 0;

	clock_t time, time2;

	time = clock();

	double fix;

	double area;

	area = (bx-ax)*(by-ay);

	double tol = 1e-6;

	double Eu, Ev, Ew, Ep; //Errors

	dx = (bx-ax)/(double)Kx;
	dy = (by-ay)/(double)Ky; //Size of elements (fixed length)

	D.resize(N+1,N+1);
	z.resize(N+1);
	w.resize(N+1);

	xx.resize(Kx,N+1);
	yy.resize(Ky,N+1);

	{
		Arr Leg(N+1);

		DzwL(D,z,w,Leg);

	}


	//Generating physical points in x and y (and boundary conditions for u and v) :
	{

		Arr uN(Kx,N+1), uE(Ky,N+1), uS(Kx,N+1), uW(Ky,N+1);
		Arr vN(Kx,N+1), vE(Ky,N+1), vS(Kx,N+1), vW(Ky,N+1);

		for (int i=0; i<N+1; i++) {
			for (int j=1; j<=Kx; j++) {
				xx(j-1,i)=ax+(j-1)*dx+((z(i)+1)*dx)/2;
				uN(j-1,i)=SlsqbcuN(xx(j-1,i));
				vN(j-1,i)=SlsqbcvN(xx(j-1,i));
				uS(j-1,i)=SlsqbcuS(xx(j-1,i));
				vS(j-1,i)=SlsqbcvS(xx(j-1,i));
			}
		}

		for (int i=0; i<N+1; i++) {
			for (int j=1; j<=Ky; j++) {
				yy(j-1,i)=ay+(j-1)*dy+((z(i)+1)*dy)/2;
				uE(j-1,i)=SlsqbcuE(yy(j-1,i));
				vE(j-1,i)=SlsqbcvE(yy(j-1,i));
				uW(j-1,i)=SlsqbcuW(yy(j-1,i));
				vW(j-1,i)=SlsqbcvW(yy(j-1,i));
			}
		}


		//Fixing hh to be smallest gap between nodes: (always at element edge)
		if(ishh) {
			if (Kx>Ky) {
				hh = xx(0,1)-xx(0,0);
			}
			else {
				hh = yy(0,1)-yy(0,0);
			}
			hh=2/(double)(N+Kx);
		}
		else {
			hh=1;
		}


		transint(Xu,Yu,uN,uE,uS,uW); //Transfinite Interpolation (sets basis functions for Dim=0,...,3.)
		transint(Xv,Yv,vN,vE,vS,vW);

	}

	Arr ru(N+1,Kx), ru2(N+1,Kx), su(N+1,Ky), su2(N+1,Ky);
	Arr rv(N+1,Kx), rv2(N+1,Kx), sv(N+1,Ky), sv2(N+1,Ky);
	Arr rw(N+1,Kx), rw2(N+1,Kx), sw(N+1,Ky), sw2(N+1,Ky);
	Arr rp(N+1,Kx), rp2(N+1,Kx), sp(N+1,Ky), sp2(N+1,Ky);

	Arr Xuk(J,N+1), Yuk(J,N+1);
	Arr Xvk(J,N+1), Yvk(J,N+1);
	Arr Xwk(J,N+1), Ywk(J,N+1);
	Arr Xpk(J,N+1), Ypk(J,N+1);

	Arr rsuk(N+1), rsvk(N+1), rswk(N+1), rspk(N+1);

	Arr rspk2(N+1);

	Arr A(N+1,N+1), B(N+1,N+1), C(N+1,N+1), E(N+1,N+1), F(N+1,N+1), G(N+1,N+1), H(N+1,N+1), L(N+1,N+1);

	Arr a1(N+1), a2(N+1), a3(N+1);
	Arr b1(N+1), b2(N+1), b3(N+1);
	Arr c1(N+1), c2(N+1), c3(N+1), c4(N+1);
	Arr d1(N+1), d2(N+1);

	Arr f1(N+1), f2(N+1);

	Arr fx1(N*Kx+1), fx2(N*Kx+1), fx3(N*Kx+1), fx4(N*Kx+1);
	Arr fy1(N*Ky+1), fy2(N*Ky+1), fy3(N*Ky+1), fy4(N*Ky+1);

	Arr Ax(N*Kx+1,N*Kx+1), Bx(N*Kx+1,N*Kx+1), Cx(N*Kx+1,N*Kx+1), Ex(N*Kx+1,N*Kx+1), Fx(N*Kx+1,N*Kx+1), Gx(N*Kx+1,N*Kx+1), Hx(N*Kx+1,N*Kx+1), Lx(N*Kx+1,N*Kx+1);
	Arr Ay(N*Ky+1,N*Ky+1), By(N*Ky+1,N*Ky+1), Cy(N*Ky+1,N*Ky+1), Ey(N*Ky+1,N*Ky+1), Fy(N*Ky+1,N*Ky+1), Gy(N*Ky+1,N*Ky+1), Hy(N*Ky+1,N*Ky+1), Ly(N*Ky+1,N*Ky+1);

	Arr rusol(N*Kx+1), rvsol(N*Kx+1), rwsol(N*Kx+1), rpsol(N*Kx+1);
	Arr susol(N*Ky+1), svsol(N*Ky+1), swsol(N*Ky+1), spsol(N*Ky+1);

	Arr tenA(N+1,N+1,N+1,N+1), tenB(N+1,N+1,N+1,N+1), tenC(N+1,N+1,N+1,N+1), tenE(N+1,N+1,N+1,N+1);
	Arr tenF(N+1,N+1,N+1,N+1), tenG(N+1,N+1,N+1,N+1), tenH(N+1,N+1,N+1,N+1), tenL(N+1,N+1,N+1,N+1);

	Arr tenL0(N+1,N+1,N+1,N+1);

	Arr g1(N+1,N+1,Kx,Ky), g2(N+1,N+1,Kx,Ky);

	//Populating tensors:
	Slsqtensors(tenA, tenB, tenC, tenE, tenF, tenG, tenH, tenL, tenL0);
	SlsqRHS(g1,g2);




	//Main code starts here-------------------

	for (Dim=4; Dim<J; Dim++) {

		ru=1; //Initial 'guess'
		rv=1;
		rw=1;
		rp=1;


		ru2=1; //Just so the convergence criterion makes sense on first iteration
		su2=1;
		rv2=1;
		sv2=1;
		rw2=1;
		sw2=1;
		rp2=1;
		sp2=1;

		ru(0,0)=0; // Homogenous b.c.s
		ru(N,Kx-1)=0;
		rv(0,0)=0;
		rv(N,Kx-1)=0;

		count = 0;

		while(true) { // ADFPA iteration

			/*if(count > 8) {
				break;
			}*/

			count++;

			xory=0;

			for (int ky=1; ky<=Ky; ky++) {
				for(int kx=1; kx<=Kx; kx++) {


					for(int i=0; i<N+1; i++) {
						rsuk(i)=ru(i,kx-1);
						rsvk(i)=rv(i,kx-1);
						rswk(i)=rw(i,kx-1);
						rspk(i)=rp(i,kx-1);
						for(int j=0; j<Dim; j++) {
							Xuk(j,i)=Xu(j,i,kx-1);
							Yuk(j,i)=Yu(j,i,ky-1);
							Xvk(j,i)=Xv(j,i,kx-1);
							Yvk(j,i)=Yv(j,i,ky-1);
							Xwk(j,i)=Xw(j,i,kx-1);
							Ywk(j,i)=Yw(j,i,ky-1);
							Xpk(j,i)=Xp(j,i,kx-1);
							Ypk(j,i)=Yp(j,i,ky-1);
						}
					}

					setr(tenA,rsuk,Xuk,Yuk,A,a1);
					setr(tenB,rsuk,rsvk,Xvk,Yvk,B,a2);
					setr(tenC,rsuk,rswk,Xwk,Ywk,C,a3);

					setvecr(tenB,rsvk,Xuk,Yuk,b1);
					setr(tenE,rsvk,Xvk,Yvk,E,b2);
					setr(tenF,rsvk,rswk,Xwk,Ywk,F,b3);

					setvecr(tenC,rswk,Xuk,Yuk,c1);
					setvecr(tenF,rswk,Xvk,Yvk,c2);
					setr(tenG,rswk,Xwk,Ywk,G,c3);
					setr(tenH,rswk,rspk,Xpk,Ypk,H,c4);

					setvecr(tenH,rspk,Xwk,Ywk,d1);

					setr(tenL,rspk,Xpk,Ypk,L,d2);



					f1=0;
					f2=0;
					//Contribution from RHS:
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							f1(n) += rswk(i)*g1(i,n,kx-1,ky-1);
							f2(n) += rspk(i)*g2(i,n,kx-1,ky-1);
						}
					}


					//Constructing global system:
					for(int i=0; i<N+1; i++) {
						fy1(N*(ky-1)+i) += -a1(i)-a2(i)-a3(i);
						fy2(N*(ky-1)+i) += -b1(i)-b2(i)-b3(i);
						fy3(N*(ky-1)+i) += f1(i)-c1(i)-c2(i)-c3(i)-c4(i);
						fy4(N*(ky-1)+i) += f2(i)-d1(i)-d2(i);
						for(int j=0; j<N+1; j++) {
							Ay(N*(ky-1)+i,N*(ky-1)+j) += A(i,j);
							By(N*(ky-1)+i,N*(ky-1)+j) += B(i,j);
							Cy(N*(ky-1)+i,N*(ky-1)+j) += C(i,j);
							Ey(N*(ky-1)+i,N*(ky-1)+j) += E(i,j);
							Fy(N*(ky-1)+i,N*(ky-1)+j) += F(i,j);
							Gy(N*(ky-1)+i,N*(ky-1)+j) += G(i,j);
							Hy(N*(ky-1)+i,N*(ky-1)+j) += H(i,j);
							Ly(N*(ky-1)+i,N*(ky-1)+j) += L(i,j);
						}
					}

					//Zero Mean Pressure Stuff:
					for (int kx2=1; kx2<=Kx; kx2++) {
						for (int ky2=1; ky2<=Ky; ky2++) {

							for(int i=0; i<N+1; i++) {
								rspk2(i) = rp(i,kx2-1);
							}

							setr(tenL0,rspk2,rspk,Xpk,Ypk,A,f1);

							for(int i=0; i<N+1; i++) {
								fy4(N*(ky2-1)+i) -= f1(i); //Global RHS
								for(int j=0; j<N+1; j++) {
									Ly(N*(ky2-1)+i,N*(ky-1)+j) += A(i,j); //Global matrix
								}
							}



						}
					}


				}
			}

			Slsqsolve(Ay,By,Cy,Ey,Fy,Gy,Hy,Ly,susol,svsol,swsol,spsol,fy1,fy2,fy3,fy4);

			susol.norm();
			svsol.norm();
			swsol.norm();
			spsol.norm();


			for(int i=0; i<N+1; i++) {
				for(int k=1; k<=Ky; k++) {
					su(i,k-1)=susol(N*(k-1)+i); //Writing su, sv, sw, sp to more easily readable array
					sv(i,k-1)=svsol(N*(k-1)+i);
					sw(i,k-1)=swsol(N*(k-1)+i);
					sp(i,k-1)=spsol(N*(k-1)+i);
				}
			}

			Ay=0;
			By=0;
			Cy=0;
			Ey=0;
			Fy=0;
			Gy=0;
			Hy=0;
			Ly=0;
			fy1=0;
			fy2=0;
			fy3=0;
			fy4=0;

			//Checking convergence :
			Eu=error(ru,su,ru2,su2);
			Ev=error(rv,sv,rv2,sv2);
			Ew=error(rw,sw,rw2,sw2);
			Ep=error(rp,sp,rp2,sp2);

			if ((Eu < tol) && (Ev < tol) && (Ew < tol) && (Ep < tol)) {
				break;
			}
			ru2=ru;
			rv2=rv;
			rw2=rw;
			rp2=rp;


			//Second part of ADFPA:

			xory = 1;

			for (int ky=1; ky<=Ky; ky++) {
				for(int kx=1; kx<=Kx; kx++) {


					for(int i=0; i<N+1; i++) {
						rsuk(i)=su(i,ky-1);
						rsvk(i)=sv(i,ky-1);
						rswk(i)=sw(i,ky-1);
						rspk(i)=sp(i,ky-1);
						for(int j=0; j<Dim; j++) {
							Xuk(j,i)=Xu(j,i,kx-1);
							Yuk(j,i)=Yu(j,i,ky-1);
							Xvk(j,i)=Xv(j,i,kx-1);
							Yvk(j,i)=Yv(j,i,ky-1);
							Xwk(j,i)=Xw(j,i,kx-1);
							Ywk(j,i)=Yw(j,i,ky-1);
							Xpk(j,i)=Xp(j,i,kx-1);
							Ypk(j,i)=Yp(j,i,ky-1);
						}
					}

					sets(tenA,rsuk,Xuk,Yuk,A,a1);
					sets(tenB,rsuk,rsvk,Xvk,Yvk,B,a2);
					sets(tenC,rsuk,rswk,Xwk,Ywk,C,a3);

					setvecs(tenB,rsvk,Xuk,Yuk,b1);
					sets(tenE,rsvk,Xvk,Yvk,E,b2);
					sets(tenF,rsvk,rswk,Xwk,Ywk,F,b3);

					setvecs(tenC,rswk,Xuk,Yuk,c1);
					setvecs(tenF,rswk,Xvk,Yvk,c2);
					sets(tenG,rswk,Xwk,Ywk,G,c3);
					sets(tenH,rswk,rspk,Xpk,Ypk,H,c4);

					setvecs(tenH,rspk,Xwk,Ywk,d1);

					sets(tenL,rspk,Xpk,Ypk,L,d2);


					f1=0;
					f2=0;
					//Contribution from RHS:
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							f1(i) += rswk(n)*g1(i,n,kx-1,ky-1);
							f2(i) += rspk(n)*g2(i,n,kx-1,ky-1);
						}
					}


					//Constructing global system:
					for(int i=0; i<N+1; i++) {
						fx1(N*(kx-1)+i) += -a1(i)-a2(i)-a3(i);
						fx2(N*(kx-1)+i) += -b1(i)-b2(i)-b3(i);
						fx3(N*(kx-1)+i) += f1(i)-c1(i)-c2(i)-c3(i)-c4(i);
						fx4(N*(kx-1)+i) += f2(i)-d1(i)-d2(i);
						for(int j=0; j<N+1; j++) {
							Ax(N*(kx-1)+i,N*(kx-1)+j) += A(i,j);
							Bx(N*(kx-1)+i,N*(kx-1)+j) += B(i,j);
							Cx(N*(kx-1)+i,N*(kx-1)+j) += C(i,j);
							Ex(N*(kx-1)+i,N*(kx-1)+j) += E(i,j);
							Fx(N*(kx-1)+i,N*(kx-1)+j) += F(i,j);
							Gx(N*(kx-1)+i,N*(kx-1)+j) += G(i,j);
							Hx(N*(kx-1)+i,N*(kx-1)+j) += H(i,j);
							Lx(N*(kx-1)+i,N*(kx-1)+j) += L(i,j);
						}
					}


					//Zero Mean Pressure Stuff:
					for (int kx2=1; kx2<=Kx; kx2++) {
						for (int ky2=1; ky2<=Ky; ky2++) {

							for(int i=0; i<N+1; i++) {
								rspk2(i) = sp(i,ky2-1);
							}

							sets(tenL0,rspk2,rspk,Xpk,Ypk,A,f1);

							for(int i=0; i<N+1; i++) {
								fx4(N*(kx2-1)+i) -= f1(i); //Global RHS
								for(int j=0; j<N+1; j++) {
									Lx(N*(kx2-1)+i,N*(kx-1)+j) += A(i,j); //Global matrix
								}
							}



						}
					}


				}
			}

			Slsqsolve(Ax,Bx,Cx,Ex,Fx,Gx,Hx,Lx,rusol,rvsol,rwsol,rpsol,fx1,fx2,fx3,fx4);

			for(int i=0; i<N+1; i++) {
				for(int k=1; k<=Kx; k++) {
					ru(i,k-1)=rusol(N*(k-1)+i); //Writing su, sv, sw, sp to more easily readable array
					rv(i,k-1)=rvsol(N*(k-1)+i);
					rw(i,k-1)=rwsol(N*(k-1)+i);
					rp(i,k-1)=rpsol(N*(k-1)+i);
				}
			}

			Ax=0;
			Bx=0;
			Cx=0;
			Ex=0;
			Fx=0;
			Gx=0;
			Hx=0;
			Lx=0;
			fx1=0;
			fx2=0;
			fx3=0;
			fx4=0;

			//Checking convergence :
			Eu=error(ru,su,ru2,su2);
			Ev=error(rv,sv,rv2,sv2);
			Ew=error(rw,sw,rw2,sw2);
			Ep=error(rp,sp,rp2,sp2);

			if ((Eu < tol) && (Ev < tol) && (Ew < tol) && (Ep < tol)) {
				break;
			}

			cout << Eu << " " << Ev << " " << Ew << " " << Ep << endl;


			su2=su;
			sv2=sv;
			sw2=sw;
			sp2=sp;

		}//End of while loop

		// Fixing the converged values of r,s:

		fix=0;

		for (int k=1; k<=Kx; k++) {
			for (int l=1; l<=Ky; l++) {
				for (int i=0; i<N+1; i++) {
					for (int n=0; n<N+1; n++) {
						fix += (dx*dy/4)*w(i)*w(n)*rp(i,k-1)*sp(n,l-1);
					}
				}
			}
		}

		cout << fix << endl;

		fix=0; //DONT FORGET TO REMOVE THIS IF IMPLICIT ZMP DOSNT WORK


		for(int k=1; k<=Kx; k++) {
			for (int i=0; i<N+1; i++) {
				Xu(Dim,i,k-1)=ru(i,k-1);
				Xv(Dim,i,k-1)=rv(i,k-1);
				Xw(Dim,i,k-1)=rw(i,k-1);
				Xp(Dim,i,k-1)=rp(i,k-1);
				Xp(0,i,k-1)-=fix/area;
			}
		}

		for(int k=1; k<=Ky; k++) {
			for (int i=0; i<N+1; i++) {
				Yu(Dim,i,k-1)=su(i,k-1);
				Yv(Dim,i,k-1)=sv(i,k-1);
				Yw(Dim,i,k-1)=sw(i,k-1);
				Yp(Dim,i,k-1)=sp(i,k-1);
				Yp(0,i,k-1)=1;
			}
		}

		time2 = clock()-time;

		fprintf(CPUtime,"%15.16d %15.16e\n", Dim-3, ((float)time2)/CLOCKS_PER_SEC);

	}
	cout << "BAM" << endl;
	return;

}

//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------

void PGDLSQStokesX(Arr& Xu, Arr& Yu, Arr& Xv, Arr& Yv, Arr& Xp, Arr& Yp, Arr& XV1, Arr& YV1, Arr& XV2, Arr& YV2, Arr& XV3, Arr& YV3, Arr& XV4, Arr& YV4) {


	double tol = 1e-6;

	clock_t time, time2;

	time = clock();

	double fix;

	double area;

	area = (bx-ax)*(by-ay);


	double Eu, Ev, Ep, EV1, EV2, EV3, EV4; //Errors

	dx = (bx-ax)/(double)Kx;
	dy = (by-ay)/(double)Ky; //Size of elements (fixed length)

	D.resize(N+1,N+1);
	z.resize(N+1);
	w.resize(N+1);

	xx.resize(Kx,N+1);
	yy.resize(Ky,N+1);

	{
		Arr Leg(N+1);

		DzwL(D,z,w,Leg);

	}


	//Generating physical points in x and y (and boundary conditions for u and v) :
	{

		Arr uN(Kx,N+1), uE(Ky,N+1), uS(Kx,N+1), uW(Ky,N+1);
		Arr vN(Kx,N+1), vE(Ky,N+1), vS(Kx,N+1), vW(Ky,N+1);
		Arr V1N(Kx,N+1), V1E(Ky,N+1), V1S(Kx,N+1), V1W(Ky,N+1);
		Arr V2N(Kx,N+1), V2E(Ky,N+1), V2S(Kx,N+1), V2W(Ky,N+1);
		Arr V3N(Kx,N+1), V3E(Ky,N+1), V3S(Kx,N+1), V3W(Ky,N+1);
		Arr V4N(Kx,N+1), V4E(Ky,N+1), V4S(Kx,N+1), V4W(Ky,N+1);

		for (int i=0; i<N+1; i++) {
			for (int j=1; j<=Kx; j++) {
				xx(j-1,i)=ax+(j-1)*dx+((z(i)+1)*dx)/2;
				uN(j-1,i)=SlsqbcuN(xx(j-1,i));
				vN(j-1,i)=SlsqbcvN(xx(j-1,i));
				V1N(j-1,i)=XSlsqbcV1N(xx(j-1,i));
				V2N(j-1,i)=XSlsqbcV2N(xx(j-1,i));
				V3N(j-1,i)=XSlsqbcV3N(xx(j-1,i));
				V4N(j-1,i)=XSlsqbcV4N(xx(j-1,i));
				uS(j-1,i)=SlsqbcuS(xx(j-1,i));
				vS(j-1,i)=SlsqbcvS(xx(j-1,i));
				V1S(j-1,i)=XSlsqbcV1S(xx(j-1,i));
				V2S(j-1,i)=XSlsqbcV2S(xx(j-1,i));
				V3S(j-1,i)=XSlsqbcV3S(xx(j-1,i));
				V4S(j-1,i)=XSlsqbcV4S(xx(j-1,i));

			}
		}

		for (int i=0; i<N+1; i++) {
			for (int j=1; j<=Ky; j++) {
				yy(j-1,i)=ay+(j-1)*dy+((z(i)+1)*dy)/2;
				uE(j-1,i)=SlsqbcuE(yy(j-1,i));
				vE(j-1,i)=SlsqbcvE(yy(j-1,i));
				V1E(j-1,i)=XSlsqbcV1E(yy(j-1,i));
				V2E(j-1,i)=XSlsqbcV2E(yy(j-1,i));
				V3E(j-1,i)=XSlsqbcV3E(yy(j-1,i));
				V4E(j-1,i)=XSlsqbcV4E(yy(j-1,i));
				uW(j-1,i)=SlsqbcuW(yy(j-1,i));
				vW(j-1,i)=SlsqbcvW(yy(j-1,i));
				V1W(j-1,i)=XSlsqbcV1W(yy(j-1,i));
				V2W(j-1,i)=XSlsqbcV2W(yy(j-1,i));
				V3W(j-1,i)=XSlsqbcV3W(yy(j-1,i));
				V4W(j-1,i)=XSlsqbcV4W(yy(j-1,i));
			}
		}


		//Fixing hh to be smallest gap between nodes: (always at element edge)
		if (Kx>Ky) {
			hh = xx(0,1)-xx(0,0);
		}
		else {
			hh = yy(0,1)-yy(0,0);
		}

		hh=1;

		//hh=hh/(double)J;

		transint(Xu,Yu,uN,uE,uS,uW); //Transfinite Interpolation (sets basis functions for Dim=0,...,3.)
		transint(Xv,Yv,vN,vE,vS,vW);
		transint(XV1,YV1,V1N,V1E,V1S,V1W);
		transint(XV2,YV2,V2N,V2E,V2S,V2W);
		transint(XV3,YV3,V3N,V3E,V3S,V3W);
		transint(XV4,YV4,V4N,V4E,V4S,V4W);


	}

	Arr ru(N+1,Kx), ru2(N+1,Kx), su(N+1,Ky), su2(N+1,Ky);
	Arr rv(N+1,Kx), rv2(N+1,Kx), sv(N+1,Ky), sv2(N+1,Ky);
	Arr rp(N+1,Kx), rp2(N+1,Kx), sp(N+1,Ky), sp2(N+1,Ky);
	Arr rV1(N+1,Kx), rV12(N+1,Kx), sV1(N+1,Ky), sV12(N+1,Ky);
	Arr rV2(N+1,Kx), rV22(N+1,Kx), sV2(N+1,Ky), sV22(N+1,Ky);
	Arr rV3(N+1,Kx), rV32(N+1,Kx), sV3(N+1,Ky), sV32(N+1,Ky);
	Arr rV4(N+1,Kx), rV42(N+1,Kx), sV4(N+1,Ky), sV42(N+1,Ky);


	Arr Xuk(J,N+1), Yuk(J,N+1);
	Arr Xvk(J,N+1), Yvk(J,N+1);
	Arr Xpk(J,N+1), Ypk(J,N+1);
	Arr XV1k(J,N+1), YV1k(J,N+1);
	Arr XV2k(J,N+1), YV2k(J,N+1);
	Arr XV3k(J,N+1), YV3k(J,N+1);
	Arr XV4k(J,N+1), YV4k(J,N+1);

	Arr rsuk(N+1), rsvk(N+1), rspk(N+1), rsV1k(N+1), rsV2k(N+1), rsV3k(N+1), rsV4k(N+1);

	Arr rspk2(N+1);

	Arr A(N+1,N+1), B(N+1,N+1), C(N+1,N+1), E(N+1,N+1), F(N+1,N+1), G(N+1,N+1), H(N+1,N+1), KK(N+1,N+1), L(N+1,N+1), M(N+1,N+1), NN(N+1,N+1), P(N+1,N+1), Q(N+1,N+1), R(N+1,N+1), S(N+1,N+1), T(N+1,N+1), U(N+1,N+1), V(N+1,N+1), W(N+1,N+1);

	Arr a1(N+1), a2(N+1), a3(N+1), a4(N+1);
	Arr b1(N+1), b2(N+1), b3(N+1), b4(N+1);
	Arr c1(N+1), c2(N+1), c3(N+1), c4(N+1), c5(N+1);
	Arr d1(N+1), d2(N+1), d3(N+1), d4(N+1), d5(N+1);
	Arr e1(N+1), e2(N+1), e3(N+1), e4(N+1);
	Arr f1(N+1), f2(N+1), f3(N+1), f4(N+1);
	Arr g1(N+1), g2(N+1), g3(N+1), g4(N+1), g5(N+1);

	Arr ff1(N+1), ff2(N+1), ff3(N+1), ff4(N+1), ff5(N+1);

	Arr fx1(N*Kx+1), fx2(N*Kx+1), fx3(N*Kx+1), fx4(N*Kx+1), fx5(N*Kx+1), fx6(N*Kx+1), fx7(N*Kx+1);
	Arr fy1(N*Ky+1), fy2(N*Ky+1), fy3(N*Ky+1), fy4(N*Ky+1), fy5(N*Ky+1), fy6(N*Ky+1), fy7(N*Ky+1);

	Arr Ax(N*Kx+1,N*Kx+1), Bx(N*Kx+1,N*Kx+1), Cx(N*Kx+1,N*Kx+1), Ex(N*Kx+1,N*Kx+1), Fx(N*Kx+1,N*Kx+1), Gx(N*Kx+1,N*Kx+1), Hx(N*Kx+1,N*Kx+1), KKx(N*Kx+1,N*Kx+1), Lx(N*Kx+1,N*Kx+1), Mx(N*Kx+1,N*Kx+1), NNx(N*Kx+1,N*Kx+1), Px(N*Kx+1,N*Kx+1), Qx(N*Kx+1,N*Kx+1), Rx(N*Kx+1,N*Kx+1), Sx(N*Kx+1,N*Kx+1), Tx(N*Kx+1,N*Kx+1), Ux(N*Kx+1,N*Kx+1), Vx(N*Kx+1,N*Kx+1), Wx(N*Kx+1,N*Kx+1);
	Arr Ay(N*Ky+1,N*Ky+1), By(N*Ky+1,N*Ky+1), Cy(N*Ky+1,N*Ky+1), Ey(N*Ky+1,N*Ky+1), Fy(N*Ky+1,N*Ky+1), Gy(N*Ky+1,N*Ky+1), Hy(N*Ky+1,N*Ky+1), KKy(N*Ky+1,N*Ky+1), Ly(N*Ky+1,N*Ky+1), My(N*Ky+1,N*Ky+1), NNy(N*Ky+1,N*Ky+1), Py(N*Ky+1,N*Ky+1), Qy(N*Ky+1,N*Ky+1), Ry(N*Ky+1,N*Ky+1), Sy(N*Ky+1,N*Ky+1), Ty(N*Ky+1,N*Ky+1), Uy(N*Ky+1,N*Ky+1), Vy(N*Ky+1,N*Ky+1), Wy(N*Ky+1,N*Ky+1);

	Arr rusol(N*Kx+1), rvsol(N*Kx+1), rpsol(N*Kx+1), rV1sol(N*Kx+1), rV2sol(N*Kx+1), rV3sol(N*Kx+1), rV4sol(N*Kx+1);
	Arr susol(N*Ky+1), svsol(N*Ky+1), spsol(N*Ky+1), sV1sol(N*Ky+1), sV2sol(N*Ky+1), sV3sol(N*Ky+1), sV4sol(N*Ky+1);

	Arr tenA(N+1,N+1,N+1,N+1), tenB(N+1,N+1,N+1,N+1), tenCG(N+1,N+1,N+1,N+1), tenEH(N+1,N+1,N+1,N+1);
	Arr tenF(N+1,N+1,N+1,N+1), tenK(N+1,N+1,N+1,N+1), tenL(N+1,N+1,N+1,N+1), tenM(N+1,N+1,N+1,N+1);
	Arr tenN(N+1,N+1,N+1,N+1), tenP(N+1,N+1,N+1,N+1), tenQW(N+1,N+1,N+1,N+1), tenRV(N+1,N+1,N+1,N+1);
	Arr tenTU(N+1,N+1,N+1,N+1), tenS(N+1,N+1,N+1,N+1), tenK0(N+1,N+1,N+1,N+1);

	Arr gg1(N+1,N+1,Kx,Ky), gg2(N+1,N+1,Kx,Ky), gg3(N+1,N+1,Kx,Ky), gg4(N+1,N+1,Kx,Ky), gg5(N+1,N+1,Kx,Ky);

	//Populating tensors:
	SXlsqtensors(tenA, tenB, tenCG, tenEH, tenF, tenK, tenL, tenM, tenN, tenP, tenQW, tenRV, tenS, tenTU, tenK0);
	SXlsqRHS(gg1,gg2,gg3,gg4,gg5);




	//Main code starts here-------------------

	for (Dim=4; Dim<J; Dim++) {

		ru=1; //Initial 'guess'
		rv=1;
		rp=1;
		rV1=1;
		rV2=1;
		rV3=1;
		rV4=1;


		ru2=1; //Just so the convergence criterion makes sense on first iteration
		su2=1;
		rv2=1;
		sv2=1;
		rp2=1;
		sp2=1;
		rV12=1;
		sV12=1;
		rV22=1;
		sV22=1;
		rV32=1;
		sV32=1;
		rV42=1;
		sV42=1;

		rp(0,0)=1;
		sp(0,0)=1;

		ru(0,0)=0; // Homogenous b.c.s
		ru(N,Kx-1)=0;
		rv(0,0)=0;
		rv(N,Kx-1)=0;

		sV1(0,0)=0; //nxV bc
		sV3(0,0)=0;
		sV1(N,Ky-1)=0;
		sV3(N,Ky-1)=0;
		rV2(0,0)=0;
		rV4(0,0)=0;
		rV2(N,Kx-1)=0;
		rV4(N,Kx-1)=0;


		while(true) { // ADFPA iteration

			xory = 1;


			for (int ky=1; ky<=Ky; ky++) {
				for(int kx=1; kx<=Kx; kx++) {


					for(int i=0; i<N+1; i++) {
						rsuk(i)=ru(i,kx-1);
						rsvk(i)=rv(i,kx-1);
						rspk(i)=rp(i,kx-1);
						rsV1k(i)=rV1(i,kx-1);
						rsV2k(i)=rV2(i,kx-1);
						rsV3k(i)=rV3(i,kx-1);
						rsV4k(i)=rV4(i,kx-1);
						for(int j=0; j<Dim; j++) {
							Xuk(j,i)=Xu(j,i,kx-1);
							Yuk(j,i)=Yu(j,i,ky-1);
							Xvk(j,i)=Xv(j,i,kx-1);
							Yvk(j,i)=Yv(j,i,ky-1);
							Xpk(j,i)=Xp(j,i,kx-1);
							Ypk(j,i)=Yp(j,i,ky-1);
							XV1k(j,i)=XV1(j,i,kx-1);
							YV1k(j,i)=YV1(j,i,ky-1);
							XV2k(j,i)=XV2(j,i,kx-1);
							YV2k(j,i)=YV2(j,i,ky-1);
							XV3k(j,i)=XV3(j,i,kx-1);
							YV3k(j,i)=YV3(j,i,ky-1);
							XV4k(j,i)=XV4(j,i,kx-1);
							YV4k(j,i)=YV4(j,i,ky-1);
						}
					}


					setr(tenA,rsuk,Xuk,Yuk,A,a1);
					setr(tenB,rsuk,rsvk,Xvk,Yvk,B,a2);
					setr(tenCG,rsuk,rsV1k,XV1k,YV1k,C,a3);
					setr(tenEH,rsuk,rsV2k,XV2k,YV2k,E,a4);

					setvecr(tenB,rsvk,Xuk,Yuk,b1);
					setr(tenF,rsvk,Xvk,Yvk,F,b2);
					setr(tenCG,rsvk,rsV3k,XV3k,YV3k,G,b3);
					setr(tenEH,rsvk,rsV4k,XV4k,YV4k,H,b4);

					setr(tenK,rspk,Xpk,Ypk,KK,c1);
					setr(tenL,rspk,rsV1k,XV1k,YV1k,L,c2);
					setr(tenM,rspk,rsV2k,XV2k,YV2k,M,c3);
					setr(tenN,rspk,rsV3k,XV3k,YV3k,NN,c4);
					setr(tenP,rspk,rsV4k,XV4k,YV4k,P,c5);

					setvecr(tenCG,rsV1k,Xuk,Yuk,d1);
					setvecr(tenL,rsV1k,Xpk,Ypk,d2);
					setr(tenQW,rsV1k,XV1k,YV1k,Q,d3);
					setr(tenRV,rsV1k,rsV2k,XV2k,YV2k,R,d4);
					setr(tenS,rsV1k,rsV4k,XV4k,YV4k,S,d5);

					setvecr(tenEH,rsV2k,Xuk,Yuk,e1);
					setvecr(tenM,rsV2k,Xpk,Ypk,e2);
					setvecr(tenRV,rsV2k,XV1k,YV1k,e3);
					setr(tenTU,rsV2k,XV2k,YV2k,T,e4);

					setvecr(tenCG,rsV3k,Xvk,Yvk,f1);
					setvecr(tenN,rsV3k,Xpk,Ypk,f2);
					setr(tenTU,rsV3k,XV3k,YV3k,U,f3);
					setr(tenRV,rsV3k,rsV4k,XV4k,YV4k,V,f4);

					setvecr(tenEH,rsV4k,Xvk,Yvk,g1);
					setvecr(tenP,rsV4k,Xpk,Ypk,g2);
					setvecr(tenS,rsV4k,XV1k,YV1k,g3);
					setvecr(tenRV,rsV4k,XV3k,YV3k,g4);
					setr(tenQW,rsV4k,XV4k,YV4k,W,g5);



					ff1=0;
					ff2=0;
					ff3=0;
					ff4=0;
					ff5=0;
					//Contribution from RHS:
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							ff1(n) += rspk(i)*gg1(i,n,kx-1,ky-1);
							ff2(n) += rsV1k(i)*gg2(i,n,kx-1,ky-1);
							ff3(n) += rsV2k(i)*gg3(i,n,kx-1,ky-1);
							ff4(n) += rsV3k(i)*gg4(i,n,kx-1,ky-1);
							ff5(n) += rsV4k(i)*gg5(i,n,kx-1,ky-1);
						}
					}


					//Constructing global system:
					for(int i=0; i<N+1; i++) {
						fy1(N*(ky-1)+i) += -a1(i)-a2(i)-a3(i)-a4(i);
						fy2(N*(ky-1)+i) += -b1(i)-b2(i)-b3(i)-b4(i);
						fy3(N*(ky-1)+i) += ff1(i)-c1(i)-c2(i)-c3(i)-c4(i)-c5(i);
						fy4(N*(ky-1)+i) += ff2(i)-d1(i)-d2(i)-d3(i)-d4(i)-d5(i);
						fy5(N*(ky-1)+i) += ff3(i)-e1(i)-e2(i)-e3(i)-e4(i);
						fy6(N*(ky-1)+i) += ff4(i)-f1(i)-f2(i)-f3(i)-f4(i);
						fy7(N*(ky-1)+i) += ff5(i)-g1(i)-g2(i)-g3(i)-g4(i)-g5(i);
						for(int j=0; j<N+1; j++) {
							Ay(N*(ky-1)+i,N*(ky-1)+j) += A(i,j);
							By(N*(ky-1)+i,N*(ky-1)+j) += B(i,j);
							Cy(N*(ky-1)+i,N*(ky-1)+j) += C(i,j);
							Ey(N*(ky-1)+i,N*(ky-1)+j) += E(i,j);
							Fy(N*(ky-1)+i,N*(ky-1)+j) += F(i,j);
							Gy(N*(ky-1)+i,N*(ky-1)+j) += G(i,j);
							Hy(N*(ky-1)+i,N*(ky-1)+j) += H(i,j);
							KKy(N*(ky-1)+i,N*(ky-1)+j) += KK(i,j);
							Ly(N*(ky-1)+i,N*(ky-1)+j) += L(i,j);
							My(N*(ky-1)+i,N*(ky-1)+j) += M(i,j);
							NNy(N*(ky-1)+i,N*(ky-1)+j) += NN(i,j);
							Py(N*(ky-1)+i,N*(ky-1)+j) += P(i,j);
							Qy(N*(ky-1)+i,N*(ky-1)+j) += Q(i,j);
							Ry(N*(ky-1)+i,N*(ky-1)+j) += R(i,j);
							Sy(N*(ky-1)+i,N*(ky-1)+j) += S(i,j);
							Ty(N*(ky-1)+i,N*(ky-1)+j) += T(i,j);
							Uy(N*(ky-1)+i,N*(ky-1)+j) += U(i,j);
							Vy(N*(ky-1)+i,N*(ky-1)+j) += V(i,j);
							Wy(N*(ky-1)+i,N*(ky-1)+j) += W(i,j);
						}
					}

					//Zero Mean Pressure Stuff:
					for (int kx2=1; kx2<=Kx; kx2++) {
						for (int ky2=1; ky2<=Ky; ky2++) {

							for(int i=0; i<N+1; i++) {
								rspk2(i) = rp(i,kx2-1);
							}

							setr(tenK0,rspk2,rspk,Xpk,Ypk,A,f1);

							for(int i=0; i<N+1; i++) {
								//fy3(N*(ky2-1)+i) -= f1(i); //Global RHS
								for(int j=0; j<N+1; j++) {
									KKy(N*(ky2-1)+i,N*(ky-1)+j) += A(i,j); //Global matrix
								}
							}



						}
					}


				}
			}

			SXlsqsolve(Ay,By,Cy,Ey,Fy,Gy,Hy,KKy,Ly,My,NNy,Py,Qy,Ry,Sy,Ty,Uy,Vy,Wy,susol,svsol,spsol,sV1sol,sV2sol,sV3sol,sV4sol,fy1,fy2,fy3,fy4,fy5,fy6,fy7);

			susol.norm();
			svsol.norm();
			spsol.norm();
			sV1sol.norm();
			sV2sol.norm();
			sV3sol.norm();
			sV4sol.norm();


			for(int i=0; i<N+1; i++) {
				for(int k=1; k<=Ky; k++) {
					su(i,k-1)=susol(N*(k-1)+i); //Writing su, sv, sw, sp to more easily readable array
					sv(i,k-1)=svsol(N*(k-1)+i);
					sp(i,k-1)=spsol(N*(k-1)+i);
					sV1(i,k-1)=sV1sol(N*(k-1)+i);
					sV2(i,k-1)=sV2sol(N*(k-1)+i);
					sV3(i,k-1)=sV3sol(N*(k-1)+i);
					sV4(i,k-1)=sV4sol(N*(k-1)+i);
				}
			}

			Ay=0;
			By=0;
			Cy=0;
			Ey=0;
			Fy=0;
			Gy=0;
			Hy=0;
			KKy=0;
			Ly=0;
			My=0;
			NNy=0;
			Py=0;
			Qy=0;
			Ry=0;
			Sy=0;
			Ty=0;
			Uy=0;
			Vy=0;
			Wy=0;
			fy1=0;
			fy2=0;
			fy3=0;
			fy4=0;
			fy5=0;
			fy6=0;
			fy7=0;

			//Checking convergence :
			Eu=error(ru,su,ru2,su2);
			Ev=error(rv,sv,rv2,sv2);
			Ep=error(rp,sp,rp2,sp2);
			EV1=error(rV1,sV1,rV12,sV12);
			EV2=error(rV2,sV2,rV22,sV22);
			EV3=error(rV3,sV3,rV32,sV32);
			EV4=error(rV4,sV4,rV42,sV42);

			cout << Eu << " " << Ev << " " << Ep << " " << EV1 << " " << EV2 << " " << EV3 << " " << EV4 << endl;

			if ((Eu < tol) && (Ev < tol) && (Ep < tol) && (EV1 < tol) && (EV2 < tol) && (EV3 < tol) && (EV4 < tol)) {
				break;
			}

			ru2=ru;
			rv2=rv;
			rp2=rp;
			rV12=rV1;
			rV22=rV2;
			rV32=rV3;
			rV42=rV4;


			//Second part of ADFPA:

			xory = 0;

			for (int ky=1; ky<=Ky; ky++) {
				for(int kx=1; kx<=Kx; kx++) {


					for(int i=0; i<N+1; i++) {
						rsuk(i)=su(i,ky-1);
						rsvk(i)=sv(i,ky-1);
						rspk(i)=sp(i,ky-1);
						rsV1k(i)=sV1(i,ky-1);
						rsV2k(i)=sV2(i,ky-1);
						rsV3k(i)=sV3(i,ky-1);
						rsV4k(i)=sV4(i,ky-1);
						for(int j=0; j<Dim; j++) {
							Xuk(j,i)=Xu(j,i,kx-1);
							Yuk(j,i)=Yu(j,i,ky-1);
							Xvk(j,i)=Xv(j,i,kx-1);
							Yvk(j,i)=Yv(j,i,ky-1);
							Xpk(j,i)=Xp(j,i,kx-1);
							Ypk(j,i)=Yp(j,i,ky-1);
							XV1k(j,i)=XV1(j,i,kx-1);
							YV1k(j,i)=YV1(j,i,ky-1);
							XV2k(j,i)=XV2(j,i,kx-1);
							YV2k(j,i)=YV2(j,i,ky-1);
							XV3k(j,i)=XV3(j,i,kx-1);
							YV3k(j,i)=YV3(j,i,ky-1);
							XV4k(j,i)=XV4(j,i,kx-1);
							YV4k(j,i)=YV4(j,i,ky-1);
						}
					}


					sets(tenA,rsuk,Xuk,Yuk,A,a1);
					sets(tenB,rsuk,rsvk,Xvk,Yvk,B,a2);
					sets(tenCG,rsuk,rsV1k,XV1k,YV1k,C,a3);
					sets(tenEH,rsuk,rsV2k,XV2k,YV2k,E,a4);

					setvecs(tenB,rsvk,Xuk,Yuk,b1);
					sets(tenF,rsvk,Xvk,Yvk,F,b2);
					sets(tenCG,rsvk,rsV3k,XV3k,YV3k,G,b3);
					sets(tenEH,rsvk,rsV4k,XV4k,YV4k,H,b4);

					sets(tenK,rspk,Xpk,Ypk,KK,c1);
					sets(tenL,rspk,rsV1k,XV1k,YV1k,L,c2);
					sets(tenM,rspk,rsV2k,XV2k,YV2k,M,c3);
					sets(tenN,rspk,rsV3k,XV3k,YV3k,NN,c4);
					sets(tenP,rspk,rsV4k,XV4k,YV4k,P,c5);

					setvecs(tenCG,rsV1k,Xuk,Yuk,d1);
					setvecs(tenL,rsV1k,Xpk,Ypk,d2);
					sets(tenQW,rsV1k,XV1k,YV1k,Q,d3);
					sets(tenRV,rsV1k,rsV2k,XV2k,YV2k,R,d4);
					sets(tenS,rsV1k,rsV4k,XV4k,YV4k,S,d5);

					setvecs(tenEH,rsV2k,Xuk,Yuk,e1);
					setvecs(tenM,rsV2k,Xpk,Ypk,e2);
					setvecs(tenRV,rsV2k,XV1k,YV1k,e3);
					sets(tenTU,rsV2k,XV2k,YV2k,T,e4);

					setvecs(tenCG,rsV3k,Xvk,Yvk,f1);
					setvecs(tenN,rsV3k,Xpk,Ypk,f2);
					sets(tenTU,rsV3k,XV3k,YV3k,U,f3);
					sets(tenRV,rsV3k,rsV4k,XV4k,YV4k,V,f4);

					setvecs(tenEH,rsV4k,Xvk,Yvk,g1);
					setvecs(tenP,rsV4k,Xpk,Ypk,g2);
					setvecs(tenS,rsV4k,XV1k,YV1k,g3);
					setvecs(tenRV,rsV4k,XV3k,YV3k,g4);
					sets(tenQW,rsV4k,XV4k,YV4k,W,g5);



					ff1=0;
					ff2=0;
					ff3=0;
					ff4=0;
					ff5=0;
					//Contribution from RHS:
					for (int i=0; i<N+1; i++) {
						for (int n=0; n<N+1; n++) {
							ff1(i) += rspk(n)*gg1(i,n,kx-1,ky-1);
							ff2(i) += rsV1k(n)*gg2(i,n,kx-1,ky-1);
							ff3(i) += rsV2k(n)*gg3(i,n,kx-1,ky-1);
							ff4(i) += rsV3k(n)*gg4(i,n,kx-1,ky-1);
							ff5(i) += rsV4k(n)*gg5(i,n,kx-1,ky-1);
						}
					}


					//Constructing global system:
					for(int i=0; i<N+1; i++) {
						fx1(N*(kx-1)+i) += -a1(i)-a2(i)-a3(i)-a4(i);
						fx2(N*(kx-1)+i) += -b1(i)-b2(i)-b3(i)-b4(i);
						fx3(N*(kx-1)+i) += ff1(i)-c1(i)-c2(i)-c3(i)-c4(i)-c5(i);
						fx4(N*(kx-1)+i) += ff2(i)-d1(i)-d2(i)-d3(i)-d4(i)-d5(i);
						fx5(N*(kx-1)+i) += ff3(i)-e1(i)-e2(i)-e3(i)-e4(i);
						fx6(N*(kx-1)+i) += ff4(i)-f1(i)-f2(i)-f3(i)-f4(i);
						fx7(N*(kx-1)+i) += ff5(i)-g1(i)-g2(i)-g3(i)-g4(i)-g5(i);
						for(int j=0; j<N+1; j++) {
							Ax(N*(kx-1)+i,N*(kx-1)+j) += A(i,j);
							Bx(N*(kx-1)+i,N*(kx-1)+j) += B(i,j);
							Cx(N*(kx-1)+i,N*(kx-1)+j) += C(i,j);
							Ex(N*(kx-1)+i,N*(kx-1)+j)+= E(i,j);
							Fx(N*(kx-1)+i,N*(kx-1)+j) += F(i,j);
							Gx(N*(kx-1)+i,N*(kx-1)+j) += G(i,j);
							Hx(N*(kx-1)+i,N*(kx-1)+j) += H(i,j);
							KKx(N*(kx-1)+i,N*(kx-1)+j) += KK(i,j);
							Lx(N*(kx-1)+i,N*(kx-1)+j) += L(i,j);
							Mx(N*(kx-1)+i,N*(kx-1)+j) += M(i,j);
							NNx(N*(kx-1)+i,N*(kx-1)+j) += NN(i,j);
							Px(N*(kx-1)+i,N*(kx-1)+j) += P(i,j);
							Qx(N*(kx-1)+i,N*(kx-1)+j) += Q(i,j);
							Rx(N*(kx-1)+i,N*(kx-1)+j) += R(i,j);
							Sx(N*(kx-1)+i,N*(kx-1)+j) += S(i,j);
							Tx(N*(kx-1)+i,N*(kx-1)+j) += T(i,j);
							Ux(N*(kx-1)+i,N*(kx-1)+j) += U(i,j);
							Vx(N*(kx-1)+i,N*(kx-1)+j) += V(i,j);
							Wx(N*(kx-1)+i,N*(kx-1)+j) += W(i,j);
						}
					}

					//Zero Mean Pressure Stuff:
					for (int kx2=1; kx2<=Kx; kx2++) {
						for (int ky2=1; ky2<=Ky; ky2++) {

							for(int i=0; i<N+1; i++) {
								rspk2(i) = sp(i,ky2-1);
							}

							sets(tenK0,rspk2,rspk,Xpk,Ypk,A,f1);

							for(int i=0; i<N+1; i++) {
								//fx3(N*(kx2-1)+i) -= f1(i); //Global RHS
								for(int j=0; j<N+1; j++) {
									KKx(N*(kx2-1)+i,N*(kx-1)+j) += A(i,j); //Global matrix
								}
							}



						}
					}

				}
			}

			SXlsqsolve(Ax,Bx,Cx,Ex,Fx,Gx,Hx,KKx,Lx,Mx,NNx,Px,Qx,Rx,Sx,Tx,Ux,Vx,Wx,rusol,rvsol,rpsol,rV1sol,rV2sol,rV3sol,rV4sol,fx1,fx2,fx3,fx4,fx5,fx6,fx7);



			for(int i=0; i<N+1; i++) {
				for(int k=1; k<=Kx; k++) {
					ru(i,k-1)=rusol(N*(k-1)+i); //Writing su, sv, sw, sp to more easily readable array
					rv(i,k-1)=rvsol(N*(k-1)+i);
					rp(i,k-1)=rpsol(N*(k-1)+i);
					rV1(i,k-1)=rV1sol(N*(k-1)+i);
					rV2(i,k-1)=rV2sol(N*(k-1)+i);
					rV3(i,k-1)=rV3sol(N*(k-1)+i);
					rV4(i,k-1)=rV4sol(N*(k-1)+i);
				}
			}

			Ax=0;
			Bx=0;
			Cx=0;
			Ex=0;
			Fx=0;
			Gx=0;
			Hx=0;
			KKx=0;
			Lx=0;
			Mx=0;
			NNx=0;
			Px=0;
			Qx=0;
			Rx=0;
			Sx=0;
			Tx=0;
			Ux=0;
			Vx=0;
			Wx=0;
			fx1=0;
			fx2=0;
			fx3=0;
			fx4=0;
			fx5=0;
			fx6=0;
			fx7=0;

			//Checking convergence :
			Eu=error(ru,su,ru2,su2);
			Ev=error(rv,sv,rv2,sv2);
			Ep=error(rp,sp,rp2,sp2);
			EV1=error(rV1,sV1,rV12,sV12);
			EV2=error(rV2,sV2,rV22,sV22);
			EV3=error(rV3,sV3,rV32,sV32);
			EV4=error(rV4,sV4,rV42,sV42);

			if ((Eu < tol) && (Ev < tol) && (Ep < tol) && (EV1 < tol) && (EV2 < tol) && (EV3 < tol) && (EV4 < tol)) {
				break;
			}

			su2=su;
			sv2=sv;
			sp2=sp;
			sV12=sV1;
			sV22=sV2;
			sV32=sV3;
			sV42=sV4;


		}//End of while loop

		// Fixing the converged values of r,s:


		fix=0;

		for (int k=1; k<=Kx; k++) {
			for (int l=1; l<=Ky; l++) {
				for (int i=0; i<N+1; i++) {
					for (int n=0; n<N+1; n++) {
						fix += (dx*dy/4)*w(i)*w(n)*rp(i,k-1)*sp(n,l-1);
					}
				}
			}
		}

		cout << fix << endl;

		fix=0; //DONT FORGET TO REMOVE THIS IF IMPLICIT ZMP DOSNT WORK


		for(int k=1; k<=Kx; k++) {
			for (int i=0; i<N+1; i++) {
				Xu(Dim,i,k-1)=ru(i,k-1);
				Xv(Dim,i,k-1)=rv(i,k-1);
				Xp(Dim,i,k-1)=rp(i,k-1);
				XV1(Dim,i,k-1)=rV1(i,k-1);
				XV2(Dim,i,k-1)=rV2(i,k-1);
				XV3(Dim,i,k-1)=rV3(i,k-1);
				XV4(Dim,i,k-1)=rV4(i,k-1);
				Xp(0,i,k-1)-=fix/area;
			}
		}

		for(int k=1; k<=Ky; k++) {
			for (int i=0; i<N+1; i++) {
				Yu(Dim,i,k-1)=su(i,k-1);
				Yv(Dim,i,k-1)=sv(i,k-1);
				Yp(Dim,i,k-1)=sp(i,k-1);
				YV1(Dim,i,k-1)=sV1(i,k-1);
				YV2(Dim,i,k-1)=sV2(i,k-1);
				YV3(Dim,i,k-1)=sV3(i,k-1);
				YV4(Dim,i,k-1)=sV4(i,k-1);
				Yp(0,i,k-1)=1;
			}
		}

		time2 = clock()-time;

		fprintf(CPUtime,"%15.16d %15.16e\n", Dim-3, ((float)time2)/CLOCKS_PER_SEC);

	}

	return;

}


#endif /* PGDLSQ2_H_ */
